"""Register (or update) the project webhook on the GitLab target project.

Local prerequisite: a public tunnel to the orchestrator (cloudflared / ngrok),
because GitLab cannot reach localhost. In AgentCore this is replaced by
API Gateway + Lambda and this script is not used.

    # 1. start the orchestrator:    uvicorn orchestrator.webhook:get_app --factory --port 8077
    # 2. start a tunnel:            cloudflared tunnel --url http://localhost:8077
    #                               (or: ngrok http 8077)
    # 3. register the webhook:
    python scripts/register_webhook.py --url https://<your-tunnel-host>/webhook

Events enabled: Comments (note) + Merge request events. Secret = WEBHOOK_SECRET.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from orchestrator.config import load_settings


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", required=True, help="public webhook URL ending in /webhook")
    args = parser.parse_args(argv if argv is not None else sys.argv[1:])

    from orchestrator.gitlab_client import GitLabClient

    settings = load_settings()
    hook = GitLabClient.from_settings(settings).ensure_webhook(args.url, settings.webhook_secret)
    print(f"webhook ensured #{getattr(hook, 'id', '?')} -> {args.url}")
    print("events: note + merge_request | secret: WEBHOOK_SECRET")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
