"""Live integration check: exercise EVERY GitLab-facing function against the
real configured project, assert each works, then clean up.

    .venv/Scripts/python scripts/gitlab_live_check.py

Proves the plumbing the build plan depends on actually works against real GitLab:
clone/branch/commit/push, draft MR + assignee, MR diff fetch, top-level comments
(MR + issue), and THREADED discussion replies. Creates a throwaway branch + MR
and deletes/closes them at the end.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path
from tempfile import mkdtemp
from urllib.parse import quote

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import httpx

from orchestrator.config import load_settings
from orchestrator.git_repo import GitRepo
from orchestrator.gitlab_client import GitLabClient
from orchestrator.workspace import authenticated_url

results: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    results.append((name, ok, detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" — {detail}" if detail else ""))


def main() -> int:
    s = load_settings()
    host = "https://gitlab.com"
    api = f"{s.gitlab_url}/api/v4"
    H = {"PRIVATE-TOKEN": s.gitlab_token}
    pid = s.gitlab_project_id
    ts = int(time.time())
    branch = f"codebot/live-check-{ts}"
    mr_iid = None

    gl = GitLabClient.from_settings(s)

    try:
        # 1. current_user_id (auth)
        uid = gl.current_user_id()
        check("current_user_id (auth)", isinstance(uid, int), f"uid={uid}")

        # 2. clone (authenticated, host-gated) + branch + commit + push
        repo_url = f"{s.gitlab_url.rstrip('/')}/{s.gitlab_project}.git"
        url = authenticated_url(repo_url, s.gitlab_token, allowed_host="gitlab.com")
        cred_gated = url.startswith("https://oauth2:")
        check("token host-gating (authenticated_url)", cred_gated, "token embedded for configured host")
        dest = Path(mkdtemp(prefix="livecheck-"))
        gitrepo = GitRepo.clone(url, dest, s.gitlab_default_branch)
        fname = f"live_check_{ts}.txt"
        (gitrepo.path / fname).write_text(f"live check {ts}\n")
        check("clone + workspace write", (gitrepo.path / fname).exists())
        gitrepo.checkout_new_branch(branch)
        gitrepo.commit("codebot: live check", "codebot", "codebot@example.com")
        gitrepo.push(branch)
        br = httpx.get(f"{api}/projects/{pid}/repository/branches/{quote(branch, safe='')}", headers=H, timeout=30)
        check("branch/commit/push (branch on remote)", br.status_code == 200, branch)

        # 3. create_draft_mr (+ assignee)
        mr = gl.create_draft_mr(branch, s.gitlab_default_branch, "Live check", "automated live check", assignee_ids=[uid])
        mr_iid = mr.iid
        detail = httpx.get(f"{api}/projects/{pid}/merge_requests/{mr_iid}", headers=H, timeout=30).json()
        check("create_draft_mr (draft flag)", detail.get("draft") is True, f"!{mr_iid}")
        check("create_draft_mr (assignee set)", uid in [a["id"] for a in detail.get("assignees", [])])

        # 4. get_mr_changes (MR diff)
        changes = gl.get_mr_changes(mr_iid)
        paths = [c.get("new_path") for c in changes]
        check("get_mr_changes (diff fetch)", fname in paths, f"files={paths}")

        # 5. post_comment on MR (top-level)
        gl.post_comment("mr", mr_iid, "live-check top-level note")
        notes = httpx.get(f"{api}/projects/{pid}/merge_requests/{mr_iid}/notes", headers=H, timeout=30).json()
        check("post_comment MR top-level", any("top-level note" in n["body"] for n in notes))

        # 6. THREADED discussion reply (post_comment with discussion_id)
        disc = httpx.post(
            f"{api}/projects/{pid}/merge_requests/{mr_iid}/discussions",
            headers=H, data={"body": "live-check thread root"}, timeout=30,
        ).json()
        disc_id = disc["id"]
        gl.post_comment("mr", mr_iid, "live-check threaded reply", discussion_id=disc_id)
        after = httpx.get(f"{api}/projects/{pid}/merge_requests/{mr_iid}/discussions/{disc_id}", headers=H, timeout=30).json()
        n_notes = len(after.get("notes", []))
        check("post_comment threaded reply (discussion_id)", n_notes == 2, f"{n_notes} notes in thread")

        # 7. post_comment on issue (top-level) — reuse issue !1 if present, else create one
        issue = httpx.get(f"{api}/projects/{pid}/issues", headers=H, params={"per_page": 1}, timeout=30).json()
        if issue:
            issue_iid = issue[0]["iid"]
        else:
            issue_iid = httpx.post(f"{api}/projects/{pid}/issues", headers=H, data={"title": "live-check issue"}, timeout=30).json()["iid"]
        gl.post_comment("issue", issue_iid, f"live-check issue note {ts}")
        inotes = httpx.get(f"{api}/projects/{pid}/issues/{issue_iid}/notes", headers=H, timeout=30).json()
        check("post_comment issue", any(f"issue note {ts}" in n["body"] for n in inotes))

    finally:
        # cleanup: close MR + delete the throwaway branch
        if mr_iid is not None:
            httpx.put(f"{api}/projects/{pid}/merge_requests/{mr_iid}", headers=H, data={"state_event": "close"}, timeout=30)
        httpx.delete(f"{api}/projects/{pid}/repository/branches/{quote(branch, safe='')}", headers=H, timeout=30)
        print("\n[cleanup] closed MR + deleted live-check branch")

    passed = sum(1 for _, ok, _ in results if ok)
    print(f"\n=== {passed}/{len(results)} GitLab functions verified live ===")
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
