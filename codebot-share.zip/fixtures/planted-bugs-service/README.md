# orders (sample service)

A tiny FastAPI service used as the target codebase for the code assistant.

## Run

```bash
pip install -r requirements.txt
uvicorn app:app --reload
pytest -q
```

## Endpoints

- `GET /users/{name}` — look up a user by name
- `GET /orders/total?unit_price=&quantity=&discount_percent=` — order line total
