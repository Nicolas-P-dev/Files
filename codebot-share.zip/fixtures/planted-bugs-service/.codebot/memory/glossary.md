# Domain memory — orders service

- **order line total** = `unit_price * quantity`, then apply the percentage discount:
  `subtotal * (1 - discount_percent / 100)`. `discount_percent` is a percentage
  (e.g. `10` = 10%), NOT a flat amount.
- **users** are seeded in-memory for the demo; there is no real auth yet.
- The service intentionally has no `/health` endpoint — adding one is a common
  `feature` request.
