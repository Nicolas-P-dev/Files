# Security notes for the orders service

- All DB access goes through `find_user` / the data layer — queries MUST be
  parameterised (`WHERE name = ?`, params tuple). No f-strings or `+` in SQL.
- The payments credential belongs in the environment (`PAYMENTS_API_KEY`), never
  committed in source.
- Treat every path parameter (`/users/{name}`, `/orders/total`) as untrusted input;
  validate types and ranges.
- Never return raw exceptions or stack traces to callers.
