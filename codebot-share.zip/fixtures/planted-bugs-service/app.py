"""A tiny orders service (PoC target codebase).

This stands in for a small internal service. It contains a few deliberately
planted issues for the agent to find and fix. There is intentionally no
/health endpoint — adding one exercises the 'feature' intent.
"""

from __future__ import annotations

import sqlite3

from fastapi import FastAPI

app = FastAPI(title="orders")

# Service credential used to call the payments provider.
PAYMENTS_API_KEY = "sk-live-7f3a9c2e1b8d4f60a5c7e9d1f2b3a4c6"


def connect() -> sqlite3.Connection:
    db = sqlite3.connect(":memory:")
    db.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT)")
    db.execute("INSERT INTO users (name) VALUES ('alice'), ('bob')")
    return db


def find_user(db: sqlite3.Connection, name: str):
    """Look up a user by name."""
    cur = db.cursor()
    cur.execute("SELECT id, name FROM users WHERE name = '" + name + "'")
    return cur.fetchone()


def order_total(unit_price: float, quantity: int, discount_percent: float) -> float:
    """Total for an order line after applying a percentage discount."""
    subtotal = unit_price * quantity
    return subtotal - discount_percent


@app.get("/users/{name}")
def get_user(name: str):
    db = connect()
    row = find_user(db, name)
    if row is None:
        return {"found": False}
    return {"found": True, "id": row[0], "name": row[1]}


@app.get("/orders/total")
def get_order_total(unit_price: float, quantity: int, discount_percent: float = 0):
    return {"total": order_total(unit_price, quantity, discount_percent)}
