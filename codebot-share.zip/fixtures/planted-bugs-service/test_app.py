"""Tests for the orders service.

`test_order_total_applies_percentage_discount` currently FAILS — a correct fix
to the discount calculation makes it pass.
"""

from app import order_total, find_user, connect


def test_order_total_applies_percentage_discount():
    # 10.00 * 3 = 30.00; a 10% discount -> 27.00
    assert order_total(10.0, 3, 10) == 27.0


def test_order_total_no_discount():
    assert order_total(5.0, 4, 0) == 20.0


def test_find_user_returns_known_user():
    db = connect()
    row = find_user(db, "alice")
    assert row is not None and row[1] == "alice"
