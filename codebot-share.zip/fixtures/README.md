# Test fixtures

`planted-bugs-service/` is the **target codebase** the agent operates on. At DB,
the real Kiro reviews/fixes it; locally the stub proves the plumbing. Seed it into
the throwaway GitLab project to give the agent something real to work on:

```bash
# from a clone of the sandbox repo, copy the service in and push
cp -r fixtures/planted-bugs-service/* <sandbox-clone>/
```

## Planted issues (inventory — NOT shipped into the service so review stays fair)

| # | Type | Location | Expected finding / fix |
|---|------|----------|------------------------|
| 1 | **Security — hardcoded secret** | `app.py` `PAYMENTS_API_KEY = "sk-live-…"` | Move to an env var / secrets manager; never commit. `[blocker]` |
| 2 | **Security — SQL injection** | `app.py` `find_user` builds SQL by string concatenation | Use a parameterised query (`WHERE name = ?`, `(name,)`). `[blocker]` |
| 3 | **Logic error** | `app.py` `order_total` subtracts the percent value instead of applying a percentage | `subtotal * (1 - discount_percent/100)`. `[major]` |

## Deliberately failing test (a correct fix makes it pass)

`test_app.py::test_order_total_applies_percentage_discount` — asserts
`order_total(10.0, 3, 10) == 27.0`. The planted logic bug returns `20.0`, so it
fails until issue #3 is fixed.

## Canned @-mention instructions (one per intent)

| Intent | Mention on | Instruction |
|--------|-----------|-------------|
| review | an MR | `@codebot review` |
| fix    | an MR | `@codebot fix the failing tests` |
| improve| an MR | `@codebot improve error handling in find_user` |
| feature| an issue | `@codebot add a /health endpoint` |
