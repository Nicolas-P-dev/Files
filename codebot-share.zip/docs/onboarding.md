# Onboarding a repository to codebot

The **minimal bridge**: the smallest thing that lets someone connect their repo today,
designed to evaporate into a GitLab-native flow once a shared bot user exists.

## For a repo owner (the 3-step flow)

1. **Create a Project Access Token** in your repo — Settings → Access Tokens, scopes
   `api`, `read_repository`, `write_repository` (this auto-creates a non-licensed bot
   user that authors codebot's MRs/comments).
2. **Open the onboarding page** (`/onboard`), paste your **project path** (`group/project`)
   and the token, and click **Connect**.
3. Done. codebot registers the webhook, stores your credential (encrypted), and opens a
   **draft MR adding a starter `.codebot/config.yml`**. From then on, mention
   `@codebot review` / `fix` / `improve` / `add …` / `init` on a merge request or issue.

Webhook health is visible in GitLab's own **Settings → Webhooks → Recent events**; the
`/status` page lists connected repos.

## What happens under the hood

`POST /onboard` → [`onboarding.onboard`](../orchestrator/onboarding.py):
1. validates the token by resolving the project,
2. `GitLabClient.ensure_webhook` registers a hook (Comments + MR events) with a
   generated **per-repo secret**,
3. the registry stores `project_id → {token (Fernet-encrypted), secret}`
   ([registry.py](../orchestrator/registry.py)),
4. the orchestrator runs the **`init`** flow to open the scaffold MR.

Per event, the webhook verifies `X-Gitlab-Token` against that repo's **own** secret and
the orchestrator clones/acts with that repo's **own** token
([credentials.py](../orchestrator/credentials.py)) — falling back to the `.env`
`GITLAB_TOKEN`/`WEBHOOK_SECRET` for the original single-project setup.

## Operator setup (hosting the bridge)

```
PUBLIC_BASE_URL="https://<your-host>"   # where GitLab webhooks point
ADMIN_TOKEN="<strong-password>"          # gates /onboard + /status (HTTP Basic)
CODEBOT_ENC_KEY="<fernet-key>"           # python -c "from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())"
CODEBOT_DB_PATH="codebot.db"
```
Run `uvicorn orchestrator.webhook:get_app --factory` behind HTTPS. The `/onboard` +
`/status` routes mount automatically when `CODEBOT_ENC_KEY` + `ADMIN_TOKEN` are set.
The form accepts tokens, so it **must** be served over HTTPS and stay admin-gated.

### Security & operations (read before going live)

- **HTTPS is required, not optional.** `/onboard` and `/status` carry a Project Access
  Token and the `ADMIN_TOKEN` over HTTP Basic — both travel in cleartext over plain HTTP.
  `PUBLIC_BASE_URL` **must** be `https://…` and the service must sit behind a
  TLS-terminating proxy/tunnel. Never expose these routes over plain HTTP.
- **Back up `CODEBOT_ENC_KEY`; it is not rotatable in place.** It encrypts every stored
  token at rest. If it is **lost or changed**, those tokens can't be decrypted — affected
  repos are flagged `needs_reonboard` (the webhook degrades gracefully and falls back to
  the global `GITLAB_TOKEN` rather than erroring) and each owner must re-onboard to store a
  fresh token. If it is **unset**, the onboarding UI and per-repo credential store are
  silently disabled (only the `.env` single-project path works). Treat the key as a secret
  with its own backup.

## Evolution to the shared bot (no rework)

When a shared bot user is provisioned: [`credentials.token_for`](../orchestrator/credentials.py)
returns the central bot token (the registry token becomes optional), the token field
disappears from onboarding (or the page is retired in favor of "invite the bot" + a
**group webhook**), and `@codebot init`, the registry, and `/status` are unchanged. The
custom UI shrinks to near-zero; the GitLab-native surface remains.
