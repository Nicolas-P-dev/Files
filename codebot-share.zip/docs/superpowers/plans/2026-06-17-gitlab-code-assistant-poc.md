# Agentic GitLab Code Assistant (Kiro) — Local PoC Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans (inline) or superpowers:subagent-driven-development to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a containerised orchestrator that, triggered from GitLab via `@`-mention, drives a headless coding agent (Kiro CLI — stubbed locally behind a clean seam) to review MRs, push fixes, and implement features, landing every change as a draft MR with full workflow observability.

**Architecture:** Python + FastAPI orchestrator owns all VCS/GitLab plumbing (clone, branch, commit, push, draft MR, reply comment) and observability (OTel → Langfuse). The *coding agent* is a swappable seam (`AGENT_BACKEND=stub|kiro`) responsible only for transforming code in a prepared workspace. Locally the **stub** makes a real, deterministic edit so the whole pipeline genuinely executes; the **kiro** backend (`kiro-cli chat --no-interactive`) is config-only swap, validated at DB. Superpowers disciplines are ported into `.kiro/steering/*.md` to drive the runtime agent.

**Tech Stack:** Python 3.13, FastAPI, python-gitlab, git (subprocess), OpenTelemetry SDK + OTLP HTTP exporter → Langfuse Cloud, pytest. Container: slim Debian base.

**Build location:** `C:\Users\nicol\Documents\Coding\coding-agent` (this repo = the orchestrator/PoC; the *target* repo it operates on is the throwaway `poc-agent/poc-agent-sandbox`).

---

## Design decisions (locked)

- **The orchestrator owns git + GitLab API** in BOTH backends (the doc's "orchestrator-driven git/glab" path). The agent seam only mutates files in the workspace and returns a summary. This makes the stub path exercise branch/push/draft-MR/comment for real, and keeps the seam trivially testable. (At DB we can *additionally* let Kiro use the GitLab MCP; not required for the local pass.)
- **Personal token reality:** the provided `GITLAB_TOKEN` is a *personal* PAT (user `01082002nic`), not a project bot token. MRs/comments are therefore authored by that user. Acceptance criteria that say "authored by the bot" are read as "authored by the token identity". Swapping to a project bot token at DB is config-only.
- **Offline-testable VCS:** integration tests use a local **bare git repo as the remote** (`file://`) so clone/branch/push run for real with no network; GitLab API calls (MR/comment) are faked. A separate **live acceptance** CLI run hits the real sandbox.
- **Data model is shared** across all phases (`Task`, `Intent`, `AgentResult`) — defined once in Task 2.

### File structure (target)
```
orchestrator/
  __init__.py
  config.py          # Settings (pydantic-settings) <- .env
  models.py          # Intent, Task, AgentResult
  intent.py          # parse instruction text -> Intent  (Phase 4 uses it; defined Phase 1)
  git_repo.py        # GitRepo: clone/branch/commit/push (subprocess)
  gitlab_client.py   # GitLabClient: draft MR, comments, MR diff (python-gitlab)
  workspace.py       # prepare_workspace: clone target + copy .kiro/steering in
  agents/
    __init__.py
    base.py          # CodingAgent ABC: run(task, workspace) -> AgentResult
    stub.py          # StubAgent: deterministic real edit per intent
    kiro.py          # KiroAgent: kiro-cli chat --no-interactive (config-only at DB)
    factory.py       # make_agent(settings) -> CodingAgent
  observability.py   # OTel tracer -> OTLP HTTP -> Langfuse (Phase 3)
  orchestrator.py    # Orchestrator.run(task) -> AgentResult  (the core flow)
  webhook.py         # FastAPI app /webhook (Phase 4)
  cli.py             # python -m orchestrator.cli ...  (CLI mode)
tests/
  conftest.py
  test_config.py test_models.py test_intent.py
  test_stub_agent.py test_factory.py
  test_git_repo.py test_gitlab_client.py
  test_orchestrator_flow.py
.kiro/steering/*.md  # Phase 2
fixtures/planted-bugs-service/  # Phase 8 (built alongside)
Dockerfile           # Phase 5
```

---

## PHASE 1 — Bare spine (local, stub)  ← detailed

**Acceptance:** a CLI run produces a real **draft** MR on `poc-agent/poc-agent-sandbox`, authored by the token identity, with a reply comment, driven by the stub agent's real edit.

### Task 1: Settings / config loader

**Files:** Create `orchestrator/__init__.py`, `orchestrator/config.py`; Test `tests/test_config.py`

- [ ] **Step 1: Failing test** — `tests/test_config.py`
```python
from orchestrator.config import Settings

def test_settings_load_from_env(monkeypatch):
    monkeypatch.setenv("GITLAB_PROJECT", "g/p")
    monkeypatch.setenv("GITLAB_PROJECT_ID", "123")
    monkeypatch.setenv("GITLAB_TOKEN", "glpat-x")
    s = Settings(_env_file=None)
    assert s.gitlab_project == "g/p"
    assert s.gitlab_project_id == "123"
    assert s.agent_backend == "stub"            # default
    assert s.gitlab_url == "https://gitlab.com" # default
```
- [ ] **Step 2:** Run `python -m pytest tests/test_config.py -v` → FAIL (no module).
- [ ] **Step 3:** Implement `Settings(BaseSettings)` with `model_config = SettingsConfigDict(env_file=".env", extra="ignore", case_sensitive=False)` and all fields from `.env.example` (sensible defaults; required: `gitlab_project`, `gitlab_project_id`, `gitlab_token`). Empty `orchestrator/__init__.py`.
- [ ] **Step 4:** Run test → PASS.
- [ ] **Step 5:** Commit `feat: settings loader`.

### Task 2: Data model (Intent, Task, AgentResult)

**Files:** Create `orchestrator/models.py`; Test `tests/test_models.py`

- [ ] **Step 1: Failing test**
```python
from orchestrator.models import Intent, Task, AgentResult

def test_task_and_result_defaults():
    t = Task(intent=Intent.FIX, instruction="fix tests", project_id="123",
             repo_url="https://x/y.git")
    assert t.default_branch == "main"
    assert t.source_kind == "cli"
    r = AgentResult(changed=True, summary="did a thing")
    assert r.assumptions == [] and r.review_comments == [] and r.exit_code == 0
```
- [ ] **Step 2:** Run → FAIL.
- [ ] **Step 3:** Implement dataclasses:
```python
from enum import Enum
from dataclasses import dataclass, field

class Intent(str, Enum):
    REVIEW="review"; FIX="fix"; IMPROVE="improve"; FEATURE="feature"; UNKNOWN="unknown"

@dataclass
class Task:
    intent: Intent
    instruction: str
    project_id: str
    repo_url: str
    default_branch: str = "main"
    source_kind: str = "cli"          # "mr" | "issue" | "cli"
    source_iid: int | None = None
    discussion_id: str | None = None
    author: str | None = None

@dataclass
class AgentResult:
    changed: bool
    summary: str
    assumptions: list[str] = field(default_factory=list)
    review_comments: list[str] = field(default_factory=list)
    branch: str | None = None
    raw_stdout: str = ""
    exit_code: int = 0
```
- [ ] **Step 4:** Run → PASS. **Step 5:** Commit `feat: core data model`.

### Task 3: Intent parser

**Files:** Create `orchestrator/intent.py`; Test `tests/test_intent.py`

- [ ] **Step 1: Failing test** — parametrised:
```python
import pytest
from orchestrator.intent import parse_intent
from orchestrator.models import Intent

@pytest.mark.parametrize("text,expected", [
    ("@codebot review", Intent.REVIEW),
    ("@codebot review this MR please", Intent.REVIEW),
    ("@codebot fix the failing tests", Intent.FIX),
    ("@codebot improve error handling here", Intent.IMPROVE),
    ("@codebot refactor this", Intent.IMPROVE),
    ("@codebot add a /health endpoint", Intent.FEATURE),
    ("@codebot implement pagination", Intent.FEATURE),
    ("@codebot do a barrel roll", Intent.UNKNOWN),
])
def test_parse_intent(text, expected):
    assert parse_intent(text) == expected
```
- [ ] **Step 2:** Run → FAIL. **Step 3:** Implement keyword precedence: review → fix → improve/refactor → add/implement/feature/endpoint → UNKNOWN (lowercase, word-boundary checks, strip the mention first). **Step 4:** PASS. **Step 5:** Commit `feat: intent parser`.

### Task 4: CodingAgent seam + StubAgent

**Files:** Create `orchestrator/agents/__init__.py`, `orchestrator/agents/base.py`, `orchestrator/agents/stub.py`; Test `tests/test_stub_agent.py`

- [ ] **Step 1: Failing test** — stub makes a REAL edit in a temp workspace and returns a sensible result per intent:
```python
import pathlib
from orchestrator.agents.stub import StubAgent
from orchestrator.models import Task, Intent

def _task(intent): return Task(intent=intent, instruction="x", project_id="1", repo_url="u")

def test_stub_fix_makes_real_edit(tmp_path):
    (tmp_path / "README.md").write_text("# hello\n")
    res = StubAgent().run(_task(Intent.FIX), tmp_path)
    assert res.changed is True
    note = tmp_path / "AGENT_NOTES.md"
    assert note.exists() and "fix" in note.read_text().lower()
    assert res.summary and res.assumptions

def test_stub_review_makes_no_edit_but_comments(tmp_path):
    (tmp_path / "README.md").write_text("# hello\n")
    res = StubAgent().run(_task(Intent.REVIEW), tmp_path)
    assert res.changed is False
    assert res.review_comments         # at least one review comment
```
- [ ] **Step 2:** Run → FAIL. **Step 3:** Implement `CodingAgent` ABC (`run(self, task, workspace: Path) -> AgentResult`) and `StubAgent`: for REVIEW → return `changed=False` with 1–2 deterministic `review_comments`; for FIX/IMPROVE/FEATURE → write/append a deterministic marker to `AGENT_NOTES.md` (and for FEATURE create `health.py` stub), set `changed=True`, `summary`, `assumptions=["No model available locally; stub edit.", ...]`. **Step 4:** PASS. **Step 5:** Commit `feat: coding-agent seam + stub`.

### Task 5: Agent factory

**Files:** Create `orchestrator/agents/factory.py`, `orchestrator/agents/kiro.py` (skeleton); Test `tests/test_factory.py`

- [ ] **Step 1: Failing test**
```python
from orchestrator.agents.factory import make_agent
from orchestrator.agents.stub import StubAgent

def test_factory_stub(): assert isinstance(make_agent("stub"), StubAgent)
def test_factory_unknown_raises():
    import pytest
    with pytest.raises(ValueError): make_agent("nope")
```
- [ ] **Step 2:** FAIL. **Step 3:** `make_agent(backend)` → `StubAgent()` for "stub", `KiroAgent()` for "kiro", else `ValueError`. `KiroAgent` skeleton: `run()` builds the `kiro-cli chat --no-interactive --trust-tools=...` command, but raises `NotImplementedError("kiro backend validated at DB")` if `KIRO_API_KEY` unset — fleshed out signature only here. **Step 4:** PASS. **Step 5:** Commit `feat: agent factory`.

### Task 6: GitRepo (git subprocess wrapper)

**Files:** Create `orchestrator/git_repo.py`; Test `tests/test_git_repo.py`

- [ ] **Step 1: Failing test** — uses a real local **bare** repo as remote (offline):
```python
import subprocess, pathlib
from orchestrator.git_repo import GitRepo

def _init_remote(tmp_path):
    remote = tmp_path / "remote.git"
    subprocess.run(["git","init","--bare",str(remote)], check=True)
    seed = tmp_path / "seed"
    subprocess.run(["git","clone",str(remote),str(seed)], check=True)
    (seed/"README.md").write_text("# seed\n")
    for c in (["git","add","-A"],["git","-c","user.email=a@b.c","-c","user.name=t","commit","-m","init"],
              ["git","branch","-M","main"],["git","push","origin","main"]):
        subprocess.run(c, cwd=seed, check=True)
    return remote

def test_clone_branch_commit_push(tmp_path):
    remote = _init_remote(tmp_path)
    repo = GitRepo.clone(f"file://{remote.as_posix()}", tmp_path/"ws", "main")
    (repo.path/"AGENT_NOTES.md").write_text("hi\n")
    assert repo.has_changes() is True
    repo.checkout_new_branch("codebot/test")
    repo.commit("codebot: change", "codebot", "codebot@example.com")
    repo.push("codebot/test")
    # remote now has the branch
    out = subprocess.run(["git","branch","--all"], cwd=tmp_path/"ws", capture_output=True, text=True)
    assert "codebot/test" in out.stdout
```
- [ ] **Step 2:** FAIL. **Step 3:** Implement `GitRepo` (subprocess `git`, `check=True`, capture). Methods: `clone(url, dest, branch)`, `path`, `has_changes()` (`git status --porcelain`), `checkout_new_branch(name)`, `commit(msg, name, email)` (`git -c user.name -c user.email commit`, `git add -A` first), `push(branch)` (`git push -u origin branch`). **Step 4:** PASS. **Step 5:** Commit `feat: git wrapper`.

### Task 7: GitLabClient (API: draft MR, comments)

**Files:** Create `orchestrator/gitlab_client.py`; Test `tests/test_gitlab_client.py`

- [ ] **Step 1: Failing test** — inject a fake python-gitlab `project`:
```python
from orchestrator.gitlab_client import GitLabClient

class FakeMRs:
    def __init__(self): self.created=None
    def create(self, payload): self.created=payload; 
    # return obj with .iid/.web_url/.notes
class FakeProject:
    def __init__(self): self.mergerequests=FakeMRs()

def test_create_draft_mr_prefixes_title_and_sets_draft():
    proj = FakeProject()
    c = GitLabClient(project=proj)
    c.create_draft_mr("codebot/x","main","Fix tests","desc", assignee_ids=[7])
    p = proj.mergerequests.created
    assert p["source_branch"]=="codebot/x" and p["target_branch"]=="main"
    assert p["title"].startswith("Draft:")
    assert p["assignee_ids"]==[7]
```
- [ ] **Step 2:** FAIL. **Step 3:** Implement `GitLabClient`: ctor takes `project=` (already-resolved) OR `from_settings(settings)` builds `gitlab.Gitlab(url, private_token).projects.get(id)`. `create_draft_mr(...)` → `project.mergerequests.create({...,"title":"Draft: "+title})` and returns the MR. `post_comment(kind, iid, body, discussion_id=None)` → MR/issue note or discussion reply. `get_mr_changes(iid)` → diff (Phase 4). **Step 4:** PASS. **Step 5:** Commit `feat: gitlab API client`.

### Task 8: Workspace prep

**Files:** Create `orchestrator/workspace.py`; Test `tests/test_workspace.py`

- [ ] **Step 1: Failing test** — clones via injected clone_fn and copies `.kiro/steering`:
```python
from orchestrator.workspace import prepare_workspace
# uses a fake clone_fn that just makes the dir, and a temp steering dir
```
Verify: returns workspace path; `.kiro/steering/*.md` present in workspace after prep (copied from repo's steering source).
- [ ] **Step 2:** FAIL. **Step 3:** `prepare_workspace(task, *, dest, steering_src, clone_fn)` → `clone_fn(authenticated_url, dest, branch)`, then copy `steering_src` → `dest/.kiro/steering`. Helper `authenticated_url(repo_url, token)` → inject `oauth2:<token>@`. **Step 4:** PASS. **Step 5:** Commit `feat: workspace prep`.

### Task 9: Orchestrator core flow

**Files:** Create `orchestrator/orchestrator.py`; Test `tests/test_orchestrator_flow.py`

- [ ] **Step 1: Failing integration test** — local bare remote + real StubAgent + real GitRepo + FakeGitLabClient recording MR/comment. Assert: branch pushed to remote, `create_draft_mr` called with `Draft:` title + assignee, `post_comment` called with summary. For REVIEW intent: no MR, comment contains review notes.
- [ ] **Step 2:** FAIL. **Step 3:** Implement `Orchestrator(settings, agent, gitlab_client, clone_fn, steering_src)` with `run(task) -> AgentResult`:
  1. `ws = prepare_workspace(...)`; `repo = GitRepo(ws)`
  2. `result = agent.run(task, ws)`
  3. if `result.changed`: branch name `codebot/{intent}-{short-slug}`; `repo.checkout_new_branch`; `repo.commit`; `repo.push`; `mr = gitlab_client.create_draft_mr(branch, default_branch, title, description_with_assumptions, assignee_ids)`; reply `post_comment` with summary + MR link.
  4. else (review): `post_comment` with joined `review_comments`.
  5. return result (with `branch`/mr metadata).
- [ ] **Step 4:** PASS. **Step 5:** Commit `feat: orchestrator core flow`.

### Task 10: CLI entrypoint

**Files:** Create `orchestrator/cli.py`; Test `tests/test_cli.py` (arg parsing only)

- [ ] **Step 1: Failing test** — `build_task_from_args([...])` maps flags → Task; `--intent fix --instruction "..."`.
- [ ] **Step 2:** FAIL. **Step 3:** `argparse` CLI: `--intent`, `--instruction`, optional `--mr`/`--issue`/`--discussion`; loads `Settings`, builds `Task`, constructs real `Orchestrator` (real GitLabClient.from_settings, real GitRepo.clone), runs, prints summary + MR URL. `main()` + `build_task_from_args()`. **Step 4:** PASS. **Step 5:** Commit `feat: CLI entrypoint`.

### Task 11: LIVE ACCEPTANCE (Phase 1 gate)

- [ ] Run against the real sandbox:
```
.venv/Scripts/python -m orchestrator.cli --intent fix --instruction "fix the failing tests"
```
- [ ] **Verify (evidence required):** a new **draft** MR exists on `poc-agent/poc-agent-sandbox` (check via API), source branch `codebot/...`, title starts `Draft:`, description lists assumptions, and a reply comment/MR note exists. Capture the MR web_url. → **Phase 1 done.**

---

## PHASE 2 — Methodology steering (authored locally; enforced at DB)  ← outline

Port Superpowers **discipline** skills into `.kiro/steering/` (NOT orchestration skills). Files:
- [ ] `00-disciplines-index.md` (`inclusion: always`) — tells Kiro: before any task, consult the relevant discipline below; land changes as draft MRs; never merge/approve; never touch CI/pipeline/branch-protection files.
- [ ] `test-driven-development.md`, `systematic-debugging.md`, `requesting-code-review.md`, `receiving-code-review.md`, `verification-before-completion.md` — condensed from the installed Superpowers skills, reframed for a headless single-prompt agent.
- [ ] `standards.md` — mock DB engineering standards.
- [ ] `.kiro/settings/mcp.json` — GitLab MCP server config (for the kiro backend at DB).
- [ ] Wire `steering_src` to `.kiro/steering` so `prepare_workspace` carries them into the workspace; test asserts they land. **Done (local):** files present, well-formed, carried into the stub workspace.

## PHASE 3 — Observability (local, stub)  ← outline

- [ ] `observability.py`: OTel `TracerProvider` + `OTLPSpanExporter` (HTTP) → Langfuse `${LANGFUSE_BASE_URL}/api/public/otel/v1/traces` with `Authorization: Basic base64(pk:sk)`. Factory `build_tracer(settings)`; test with `InMemorySpanExporter` (no network).
- [ ] Instrument `Orchestrator.run`: span tree `task.received` → `workspace.prepared` → `agent.invoke` (attrs: backend, prompt, exit_code, duration; event with captured stdout) → `gitlab.create_mr` / `gitlab.comment`. Test asserts span names/attrs via in-memory exporter.
- [ ] **Live:** a stub CLI run appears as a trace tree in Langfuse. **Done:** trace visible with spans + stdout + duration + outcome.

## PHASE 4 — Webhook `@`-mention trigger + intent routing (local, stub)  ← outline

- [ ] `webhook.py`: FastAPI `POST /webhook`; verify `X-Gitlab-Token == WEBHOOK_SECRET` (401 else); handle Note Hook events; filter for `BOT_MENTION` by the bot; parse `{project, mr/issue iid, discussion_id, instruction, author}`; `parse_intent`; build `Task`; run `Orchestrator` (background task); always ensure a reply comment. TestClient tests per intent + secret rejection + ignore non-mentions.
- [ ] Tunnel (`cloudflared`/`ngrok`) + register project webhook (Comments + MR events). **Done:** `@`-mentioning each intent triggers the correct stub behaviour end-to-end.

## PHASE 5 — Containerise (local)  ← outline

- [ ] `Dockerfile` (slim Debian): python, git, glab, app code, `.kiro/steering`, OTel libs; (Kiro CLI + GitLab MCP install lines present but guarded for DB). Secrets env-only. Healthcheck.
- [ ] `docker run` the stub flow end-to-end with env-injected secrets; passes Phase-4 tests inside the container. **Done:** dockerised stub passes; image is the AgentCore artifact.

## PHASE 8 — Fixtures (built alongside)  ← outline

- [ ] `fixtures/planted-bugs-service/`: small FastAPI service with ~3 planted issues (hardcoded secret, injection-style flaw, logic error) + one deliberately failing test a correct fix makes pass. Seed into the sandbox repo as the agent's target codebase for richer phases.
- [ ] `CODEOWNERS` (done), canned `@`-mention instructions per intent.

## PHASE 6 — DB handoff (cannot run locally; no Kiro key)

Documented handoff: set `AGENT_BACKEND=kiro` + `KIRO_API_KEY` + DB GitLab/OTel; run against planted-bug fixtures; validate steering enforcement + output quality. **Out of local scope.**

---

## Self-review notes
- Spec coverage: §6 components → Tasks 1–10 + Phases 2–5; §8 fixtures → Phase 8; §4 flow → Task 9 + Phase 4; observability §6 → Phase 3. Phase 6 explicitly out of local scope.
- Types consistent: `Task`/`AgentResult`/`Intent` defined once (Task 2), used unchanged downstream. `GitLabClient.create_draft_mr`, `post_comment`, `GitRepo.clone/checkout_new_branch/commit/push/has_changes` names fixed here.
- No placeholders: every Phase-1 task carries real test + impl sketch. Phases 2–5 are outlines to be expanded to bite-sized TDD when reached.
