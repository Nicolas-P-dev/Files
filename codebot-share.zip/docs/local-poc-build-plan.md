# Local PoC Build Plan — Agentic GitLab Code Assistant (Kiro)

**Goal:** prove that a single, containerised coding agent — **Kiro CLI, running headless** — triggered from GitLab via `@`-mention, can review merge requests, push fixes/improvements, and implement new features on request, following a strong engineering methodology (Superpowers disciplines, loaded as Kiro steering) with full workflow observability. The image built locally is the exact artifact later run on AWS Bedrock AgentCore; lifting it is a hosting + trigger change, nothing inside the container moves.

**Build strategy (important):** the entire system is **built and verified locally** using Claude Code + Superpowers as the *build tool*. Because there is **no Kiro API key available locally**, the Kiro invocation is built behind a clean interface with a **stub** that exercises the whole pipeline end-to-end now; the **real Kiro run is validated in the DB environment** once a key is available. Swapping stub → real is config-only.

**Out of scope for the PoC:** AgentCore hosting, ECR, production-scale webhooks, VPC/network controls, parallelism, real DB repos or real credentials on the local machine.

---

## 1. The two roles of "agents" here (read first)

- **Build tool = Claude Code + Superpowers (on your PC).** Writes the PoC — orchestrator, Dockerfile, steering files, fixtures — using Superpowers' plan→TDD methodology on its native harness. No compatibility issues.
- **Runtime agent = Kiro CLI headless (in the container).** What the finished image actually runs. Stubbed locally, real at DB.

Superpowers is therefore used twice: installed as a **Claude Code plugin** (drives how you build), and its **discipline skill files ported into `.kiro/steering`** (drive how Kiro behaves at runtime). Same source, two roles — don't conflate them.

---

## 2. What gets proven where

| Concern | Proven locally (stub) | Proven at DB (real Kiro) |
|---|---|---|
| Orchestrator, webhook, intent routing | ✅ | — |
| Clone → branch → push → **draft MR** → reply comment | ✅ | re-confirm on DB GitLab |
| Wrapper-level observability (OTel + stdout capture) | ✅ | re-confirm with DB backend |
| Containerisation (image = AgentCore artifact) | ✅ | re-confirm in DB runtime |
| **Steering reliably drives the methodology in headless** | ❌ (files authored only) | ✅ — the real spike |
| **Agent output quality (reviews/fixes/features)** | ❌ | ✅ — refine here |

The honest consequence of having no local key: the local build proves the **entire workflow skeleton**, but the two highest-risk unknowns — *is Kiro's output good* and *does steering enforce the methodology* — move to DB. This matches the "refine with Kiro once ported over" plan.

---

## 3. Target capability

| Trigger example | Intent | Action |
|---|---|---|
| `@codebot review` on an MR | Review | Read the diff, review against standards, post severity-tagged inline + summary comments |
| `@codebot fix the failing tests` on an MR | Fix | Reproduce, fix, run tests, push to the MR branch, comment a summary |
| `@codebot improve error handling here` | Improve | Refactor the targeted area following TDD, push, comment |
| `@codebot add a /health endpoint` on an issue | New feature | Assumptions → spec → plan → TDD implement → open a **draft MR** |

**Cross-cutting rules:** every change lands as a **draft MR** assigned to a human via CODEOWNERS (the agent never merges or approves); the agent always replies on the originating thread; the agent must not touch CI/pipeline or branch-protection files.

**Async-methodology nuance:** headless Kiro takes a single prompt with no mid-session input, and Kiro's interactive spec-approval steps don't apply in `--no-interactive`. So a run is **autonomous with documented assumptions** (written into the MR description). Stretch variant: post the spec/plan as an MR comment and wait for a 👍 before implementing.

---

## 4. Architecture & end-to-end flow

```
GitLab (test project)
  │  @-mention in MR/issue → Note Hook webhook
  ▼
[cloudflared / ngrok tunnel]            ← local only; in AgentCore this is API GW + Lambda
  ▼
Orchestrator service (Python / FastAPI)
  ├─ verify webhook secret, filter for bot @-mentions
  ├─ parse task {repo, MR/issue ref, instruction, author}
  ├─ clone repo / fetch MR diff → /workspace (with .kiro/steering present)
  ├─ start OTel span tree
  └─ invoke the AGENT SEAM ▼
Agent seam  (env-selected: stub | kiro)
  ├─ stub  → deterministic edit, exercises the full pipeline locally
  └─ kiro  → kiro-cli chat --no-interactive --trust-tools=... "<prompt>"
             ├─ steering: Superpowers disciplines + trigger file
             ├─ tools: GitLab MCP server (+ git, glab, fs)
             └─ model: Kiro-routed Claude;  stdout/exit code captured ▼
        ├─ GitLab MCP / glab: create branch, push, open draft MR, post comments
        └─ OTel backend (workflow spans + agent stdout artifact)
  ▼
Human reviewer (draft MR + CODEOWNERS)
```

Everything from the tunnel inward is one Docker image. Local `docker run` and the future AgentCore invocation run the identical image; only env values and the seam selection differ.

---

## 5. What YOU need to provide (manual prerequisites)

These are the things to set up by hand — the build can't create them. Split by environment.

### 5.1 For local build (do these to start)
- **Dev machine:** Python 3.x, Docker, a tunnel tool (`cloudflared` or `ngrok`), and **Claude Code with the Superpowers plugin** installed.
- **Throwaway GitLab project** (gitlab.com or a sandbox instance) to act as the test target. Create a blank project; note its URL and project path/ID.
- **GitLab project (or group) access token** on that project — scopes **`api`**, **`write_repository`**, **`read_repository`**. This auto-creates a non-licensed **bot user** (the MR/comment author). This is your local `GITLAB_TOKEN`.
- **Project webhook** (needed from Phase 4) pointing at your tunnel URL — events: **Comments** and **Merge request events** — with a **secret token** (your `WEBHOOK_SECRET`).
- **An OTel backend:** simplest is Langfuse Cloud (free tier) or run Phoenix/Langfuse locally via Docker; capture its OTLP **HTTP** endpoint + keys.
- **No Kiro key locally** — run with `AGENT_BACKEND=stub`; `KIRO_API_KEY` is left unset.

### 5.2 For DB validation (start the Kiro item NOW — it's the long pole)
- **DB-side Kiro API key (gating):** confirm the subscription tier (Pro / Pro+ / Pro Max / Power); have an **admin enable API-key generation**; and **confirm the org's IdP federation works** — orgs federating via **Entra ID / External IdP** have been reported unable to generate keys, which would block the headless approach entirely. This is a request to whoever administers DB's Kiro / IAM Identity Center, and it can take time — kick it off in parallel with building.
- **DB GitLab test project + access token** on DB's internal GitLab, same scopes as above.
- **DB OTel backend** endpoint (likely self-hosted/internal) + keys.
- **DB network/governance confirmation:** that egress lets Kiro reach its model endpoints, and that Kiro governance permits the GitLab MCP server in headless runs.
- **DB container runtime / registry** to build and run the image.

---

## 6. Component specification (build targets)

- **Orchestrator / trigger** — Python + FastAPI; a `/webhook` endpoint plus a `--cli` mode for early phases. Verifies the webhook secret, filters Note Hook events for bot `@`-mentions, parses intent + context, prepares the workspace (with `.kiro/steering` present), invokes the agent seam, ensures a reply comment, emits OTel spans.
- **Agent seam** — an interface (e.g. `CodingAgent.run(task, workspace) -> result`) with two implementations selected by `AGENT_BACKEND`: **`stub`** (deterministic edit that drives the whole pipeline end-to-end with no model) and **`kiro`** (`kiro-cli chat --no-interactive`, `KIRO_API_KEY`, `--trust-tools=read,grep,fs_write,...`, stdout/exit code captured). The stub must produce a *real* (if trivial) code change so branch/push/draft-MR/comment all genuinely execute locally.
- **Methodology — Superpowers disciplines as Kiro steering** — port TDD, systematic-debugging, requesting/receiving code review, and verification-before-completion into `.kiro/steering/*.md`, plus one `always` steering file telling Kiro to consult the relevant discipline before each task. (Do **not** port the orchestration skills — subagent/parallel/worktrees — which are harness mechanics and overlap Kiro's native spec flow.) These steering files are for the runtime agent.
- **GitLab integration** — a GitLab MCP server registered in Kiro's MCP config (`create_branch`, push/commit, `create_merge_request`, comments); `glab` + `git` as fallback. Auth via the project/group access token.
- **Model & data residency** — Kiro routes its own model, so "stays in AWS" is **not** automatic. Confirm separately whether DB's Kiro can route via our Bedrock; a security-review item for DB, not a PoC blocker.
- **Observability** — OpenTelemetry in the orchestrator emits a span tree (`task.received` → `workspace.prepared` → `agent.invoke` with prompt/exit-code/duration/stdout → `gitlab.*`), exported via OTLP HTTP. Gives the full workflow trace + agent log; not per-token detail from inside Kiro.
- **Container image** — slim Debian/Ubuntu base; contains Kiro CLI, the FastAPI orchestrator, the GitLab MCP server, `git`, `glab`, the `.kiro/steering` files, the fixture runtime + test runner, and OTel libs. Secrets are env-only.

---

## 7. Build phases & acceptance criteria

**Phase 0 — Prerequisites (local) + start the DB Kiro-key clearance**
Provision §5.1 locally; kick off §5.2's Kiro-key request in parallel.
*Done when:* repo opens in Claude Code with Superpowers installed, and the throwaway GitLab project + token + OTel backend exist.

**Phase 1 — Bare spine (local, stub)**
Orchestrator (CLI mode) clones a repo → invokes the seam in **stub** mode → opens a draft MR via GitLab MCP/glab.
*Done when:* a CLI run produces a real draft MR on the throwaway project, authored by the bot.

**Phase 2 — Methodology steering authored (local); validated at DB**
Port the Superpowers disciplines into `.kiro/steering`; add the trigger file and a `standards` steering doc.
*Done when (local):* steering files are present and well-formed and the stub run carries them into the workspace. **Real enforcement is validated in Phase 6.**

**Phase 3 — Observability (local, stub)**
Add OTel span emission + agent stdout capture; export to the backend.
*Done when:* a stub run appears as a trace tree (workflow spans + captured stdout, duration, outcome).

**Phase 4 — GitLab `@`-mention trigger & intent routing (local, stub)**
Add the webhook endpoint + tunnel; register on the project; route review/fix/improve/feature; always post a reply.
*Done when:* `@`-mentioning the bot with each intent triggers the correct stub behaviour end to end.

**Phase 5 — Containerise (local)**
Package everything into the single image; run the whole flow via `docker run` (stub) with env-injected secrets.
*Done when:* the dockerised stub passes the Phase-4 tests; the image is ECR-ready. **This image is the AgentCore artifact.**

**Phase 6 — DB handoff & real-Kiro validation (the Kiro spike)**
Move the repo/image to the DB environment; plug in the real `KIRO_API_KEY` + DB GitLab URL/token + DB OTel endpoint; set `AGENT_BACKEND=kiro`; run against the planted-bug fixtures and a DB test project.
*Done when:* the real Kiro run follows the methodology (steering enforced) and produces mergeable fixes/features; refine steering/prompts as needed. This is where agent quality and steering enforcement are actually proven.

---

## 8. Test fixtures (build alongside)
- A small DB-style FastAPI/Node service with ~3 planted issues (hardcoded secret, injection-style flaw, logic error) plus one deliberately failing test a correct fix makes pass.
- The `.kiro/steering/` methodology files (ported disciplines + trigger/index) and a `standards` doc (mock DB standards).
- A `CODEOWNERS` file routing the draft MR to a human.
- Canned `@`-mention instructions exercising each intent.

---

## 9. Risks & open questions
- **Kiro API-key gate / Entra-IdP block (highest, gating):** confirm DB-side early; blocks the real-Kiro step if unresolved.
- **Steering enforcement in headless (Phase 6 spike):** if steering doesn't reliably drive the methodology, fall back to a more prescriptive prompt + Kiro's native spec mode.
- **Stub fidelity:** the stub proves plumbing, not intelligence — keep it honest (real edit, real MR) so the local pass is meaningful.
- **Model routing / data residency:** Kiro routes its own model; confirm whether DB's Kiro can route via our Bedrock — a security-review item.
- **GitLab MCP under headless Kiro / DB governance:** confirm Kiro can use the GitLab MCP non-interactively and that governance permits it; fallback is orchestrator-driven git/glab.
- **DB network egress:** confirm Kiro can reach its model endpoints from DB's (often proxied/allowlisted) network.
- **Webhooks to localhost:** require a tunnel locally (replaced by API GW + Lambda on AgentCore).

---

## 10. The AgentCore lift (after the PoC)
Kept deliberately small — the container is identical; only its surroundings change: secrets move to **AgentCore Identity / Token Vault** (`KIRO_API_KEY`, GitLab token via Secrets Manager); the image is pushed to **ECR** and invoked by **AgentCore Runtime** (one microVM per job); the trigger becomes **GitLab webhook → API Gateway → Lambda/Step Functions**; the network gains **VPC egress controls** (allowlist GitLab, the OTel backend, and **wherever Kiro routes its model**); observability fans out to CloudWatch/CloudTrail alongside the wrapper traces. **Inside the image — Kiro CLI, steering, GitLab logic, OTel wrapper — nothing changes.**

---

## 11. How to build it (Claude Code runbook)
1. `mkdir poc && cd poc && git init`; drop this plan in as `docs/local-poc-build-plan.md`.
2. Open the folder in Claude Code; install Superpowers: `/plugin install superpowers@claude-plugins-official`.
3. Paste the kickoff prompt below; approve its Phase-1 plan; let it TDD. Build **phase by phase** (new prompt per phase). Phases 1,3,4,5 run locally on the stub; Phase 6 is the DB step.

**Kickoff prompt:**
```
I'm building a PoC: an agentic GitLab code assistant. The full design is in
docs/local-poc-build-plan.md — read it first and treat it as the approved design.

Constraints for how YOU build this:
- You are the BUILD tool. The PoC's RUNTIME agent is Kiro CLI headless
  (kiro-cli chat --no-interactive, auth via KIRO_API_KEY, --trust-tools=...).
  I have NO Kiro key locally, so build the Kiro invocation behind a clean
  interface: a stub implementation that runs the whole pipeline end-to-end now,
  and a real kiro-cli implementation selected by env var (AGENT_BACKEND). The
  stub must make a real (if trivial) code change so branch/push/draft-MR/comment
  all genuinely execute. Swapping to the real key later must be config-only.
- Stack: Python + FastAPI orchestrator. GitLab via a GitLab MCP server with
  glab/git fallback. Wrapper-level OpenTelemetry: instrument the orchestrator
  and capture the agent's stdout — do NOT try to instrument inside the agent.
- Port the relevant Superpowers DISCIPLINE skills (TDD, systematic-debugging,
  requesting/receiving code review, verification-before-completion) into
  .kiro/steering/*.md for the Kiro runtime, plus one always-on steering file
  telling Kiro to consult them. These steering files are for the runtime agent,
  not for you.
- Everything containerized; the image is the eventual AgentCore artifact.

Use the Superpowers methodology. The design is already specified, so skip
brainstorming and go straight to an implementation plan. Produce a bite-sized
task plan for PHASE 1 ONLY (orchestrator in CLI mode clones a repo → invokes
the agent seam in stub mode → opens a draft MR on a throwaway GitLab project).
Show me the plan and wait for my go before writing code. Then build it test-first.
```

## 12. Immediate next steps
1. Provision the local prerequisites (§5.1) and **start the DB-side Kiro-key clearance now** (§5.2) — the long pole.
2. Set up the repo, install Superpowers, paste the kickoff prompt, approve the Phase-1 plan.
3. Build Phases 1→5 locally on the stub, gating on each acceptance criterion.
4. Hand off to DB, plug in the real key, and run Phase 6 to validate and refine the agent.