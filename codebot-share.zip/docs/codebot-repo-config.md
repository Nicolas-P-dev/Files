# Per-repo customization: the `.codebot/` folder

A target repository customizes how codebot works inside it by adding a `.codebot/`
folder at its root. This is the **human-authored, version-controlled source of truth**;
the orchestrator reads it and compiles it into (a) its own behavior and (b) the runtime
agent's context. It is tool-agnostic — swap the runtime agent (Kiro today) and only the
projection step changes.

```
.codebot/
├── config.yml      # how codebot behaves here (schema below)
├── steering/*.md   # repo-specific agent guidance (compiled into the agent context)
├── memory/*.md     # durable repo knowledge the agent should always have
└── prompts/        # (reserved) canned per-intent prompt templates
```

Everything is optional. A repo with no `.codebot/` behaves with safe defaults.

## Boundary: `.codebot/` (ours) vs `.kiro/` (Kiro's)

| Concern | Home |
|---|---|
| Product config, standards, **memory** | **`.codebot/`** — tool-agnostic, version-controlled; the orchestrator compiles it into agent context. |
| Runtime **skills**, steering, specs, hooks | **`.kiro/`** — Kiro's native space. We respect a repo's own `.kiro/` and never touch it. |

Memory is the orchestrator's domain; skills are Kiro's. We do not build a parallel
skills runtime. Org-wide baseline guidance ships as **standard packs** (below) and the
baseline disciplines ship as global Kiro steering in the image.

## `config.yml` schema

| Key | Type | Default | Effect |
|---|---|---|---|
| `enabled` | bool | `true` | Master on/off. `false` → codebot declines and explains. |
| `goal` | str | `""` | The agent's mandate here. Surfaced in the agent context + MR description. |
| `intents.allow` | list | all five | Allow-list of intents (`review`/`audit`/`fix`/`improve`/`feature`). A disallowed intent is declined. |
| `branching.prefix` | str | `codebot` | Branch prefix for newly-created branches. |
| `branching.target_branch` | str | `main` | Target branch for newly-created MRs. |
| `branching.reuse_mr_branch` | bool | `true` | On an **MR** trigger, push to that MR's own source branch (no second MR). On an **issue/standalone** trigger, a fresh branch + draft MR is created. |
| `review.focus` | list | `[]` | Emphasis dimensions for reviews (e.g. `[security]`). |
| `review.reviewers` | list | `[]` | GitLab usernames assigned to the draft MR (resolved to ids). Falls back to the bot identity if empty. |
| `review.labels` | list | `[]` | Labels added to the draft MR. |
| `review.apply_fixes` | bool | `true` | Whether `@codebot review` **applies confident fixes** to the MR's branch. `false` → review is comment-only. `@codebot audit` is always read-only regardless. |
| `triggers.review_on_open` | bool | `false` | Auto-post a **read-only** review when a merge request opens/reopens (no @-mention needed). |
| `protected_paths` | list | `[]` | Extra globs the agent may never modify, merged with the built-in CI/pipeline/ownership guard. Stripped pre-commit and disclosed in the MR. |
| `standards.packs` | list | `[]` | Baseline packs to inline (`security`, `general`). Shipped with codebot. |
| `standards.rules` | list | `[]` | Repo-specific standards added to the agent context. |
| `standards.ref` | list | `[]` | Paths (under `.codebot/`) to steering files to inline. |
| `commands` | map | `{}` | Build/test/lint commands the agent should use (e.g. `test: "pytest -q"`). |
| `connected_systems` | list | `[]` | 🔜 External scanners to run + fold into reviews (e.g. gitleaks). Parsed now; execution is a follow-up. |
| `agent.model` / `agent.effort` / `agent.trust_tools` | — | — | Runtime tuning passed to the kiro CLI (`--model` / `--effort` / `--trust-tools`). Choose which model Kiro uses per repo. |
| `safety.draft_only` | bool | `true` | 🔜 Always-on today: every MR is a draft and the agent never merges/approves. Setting `false` has no effect yet. |
| `safety.max_changed_files` | int | `50` | Cap; if exceeded, no MR is opened and codebot explains. |
| `safety.require_plan_approval` | bool | `false` | 🔜 Post a spec/plan and await 👍 before implementing. |

## Commands (@-mentions on an MR or issue)

| Mention | Does |
|---|---|
| `@codebot review` | Reviews the change **and applies fixes it's confident about** to the MR's branch (gated by `review.apply_fixes`). |
| `@codebot audit` | **Read-only** review — comments findings, never modifies code. |
| `@codebot fix …` | Reproduce + fix; pushes to the MR's branch (MR trigger) or opens a draft MR (issue). |
| `@codebot improve …` | Refactor under the disciplines. |
| `@codebot add …` | New feature → draft MR. |
| `@codebot init` | Scaffold a starter `.codebot/config.yml` (onboarding). |

Auto-review (no mention) fires on MR-open when `triggers.review_on_open: true` — always read-only.

## Cross-repo memory (future extension)

Memory is per-repo today (`.codebot/memory/*.md`, inlined by `compiled_context` in
[repo_config.py](../orchestrator/repo_config.py)). To add **shared/org-wide** memory
later, extend `compiled_context` to also pull from a shared source (a global memory dir
in the image, or the onboarding registry) — the memory dir convention and the
`compiled_context` seam are the only touch points. No re-architecture needed.

## Flagship use case: automatic security review

```yaml
intents: { allow: [review, fix] }
review:   { focus: [security], reviewers: [secteam] }
standards:
  packs: [security]
  ref:   [steering/security.md]
connected_systems:
  - { name: gitleaks, run: "gitleaks detect --no-git", on: [review] }
```

On `@codebot review`, the compiled agent context = the baseline **security pack** +
the repo's `standards`/`.codebot/steering/security.md` + `.codebot/memory/*`, so the
agent is grounded in what is/isn't acceptable before it reviews the MR diff and posts
severity-tagged findings.

See [`fixtures/planted-bugs-service/.codebot/`](../fixtures/planted-bugs-service/.codebot)
for a worked example.
