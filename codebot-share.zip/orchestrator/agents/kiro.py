"""Real Kiro CLI backend — headless.

The command/prompt construction, configure(), auth-failure and non-zero-exit
detection, and the timeout guard are real and tested, so the DB swap is
config-only: set AGENT_BACKEND=kiro + KIRO_API_KEY. Locally the stub backend is
the default; selecting kiro without the CLI installed fails fast ('not found on
PATH') when a task runs, and without a key it times out on interactive SSO login
rather than hanging. What can only be validated at DB is real Kiro's *output
quality* and whether headless Kiro honours .kiro/steering.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

from orchestrator.agents.base import CodingAgent
from orchestrator.models import AgentResult, Intent, Task
from orchestrator.redact import redact

# kiro-cli exits 0 even on auth failure, so a silent auth failure must be detected
# from its output — otherwise a read-only run (no workspace changes) looks "clean".
_AUTH_FAILURE_MARKERS = ("authentication failed. your api key", "awsapps.com/start")

# Tools Kiro is trusted to use non-interactively. fs_write lets it edit code;
# execute_bash lets it run the test runner per the methodology steering.
DEFAULT_TRUST_TOOLS = ("fs_read", "fs_write", "execute_bash")


class KiroAgent(CodingAgent):
    def __init__(
        self,
        api_key: str = "",
        *,
        trust_tools: tuple[str, ...] | None = None,
        binary: str = "kiro-cli",
        model: str | None = None,
        effort: str | None = None,
        timeout: int = 900,
    ) -> None:
        self.api_key = api_key
        self.trust_tools = tuple(trust_tools) if trust_tools else DEFAULT_TRUST_TOOLS
        self.binary = binary
        self.model = model
        self.effort = effort
        # Bound the run: an UNauthenticated `kiro-cli chat --no-interactive` does not
        # fail — it blocks forever on interactive SSO device-login. The timeout turns
        # that (and any hang) into a fast, clear failure instead of a stuck job.
        self.timeout = timeout

    def configure(self, agent_cfg) -> None:
        """Apply per-repo `.codebot` agent tuning (only when explicitly set)."""
        if getattr(agent_cfg, "model", None):
            self.model = agent_cfg.model
        if getattr(agent_cfg, "effort", None):
            self.effort = agent_cfg.effort
        if getattr(agent_cfg, "trust_tools", None):
            self.trust_tools = tuple(agent_cfg.trust_tools)

    def build_command(self, prompt: str) -> list[str]:
        cmd = [
            self.binary,
            "chat",
            "--no-interactive",
            f"--trust-tools={','.join(self.trust_tools)}",
        ]
        if self.model:
            cmd += ["--model", self.model]
        if self.effort:
            cmd += ["--effort", self.effort]
        cmd.append(prompt)
        return cmd

    def build_prompt(self, task: Task) -> str:
        if task.intent == Intent.AUDIT:
            mode = "This is a READ-ONLY review: comment your findings; do NOT modify any files.\n"
        elif task.intent == Intent.REVIEW:
            mode = ("Review the change: apply fixes you are confident are correct, and "
                    "comment on anything uncertain.\n")
        else:
            mode = ""
        return (
            "You are a headless coding agent operating on a single GitLab task.\n"
            "Before doing anything, consult the steering in .kiro/steering/ — both the "
            "baseline engineering disciplines (plan-then-act, TDD, systematic debugging, "
            "verification before completion) and this repository's own compiled guidance "
            "(its goal, standards, review focus, and memory) — and follow them.\n"
            f"Intent: {task.intent.value}\n"
            f"Instruction: {task.instruction}\n"
            f"{mode}"
            "Make any change in the current workspace. Document your assumptions (there is "
            "no opportunity for mid-run clarification). Do not touch CI/pipeline or "
            "branch-protection files."
        )

    def run(self, task: Task, workspace: Path) -> AgentResult:
        prompt = self.build_prompt(task)
        cmd = self.build_command(prompt)

        # Headless auth: a KIRO_API_KEY (ksk_...) if provided, otherwise rely on an
        # existing `kiro-cli login` session (Builder ID / Identity Center). The key
        # is the right path for containers/CI; the session for an already-logged-in box.
        env = dict(os.environ)
        if self.api_key:
            env["KIRO_API_KEY"] = self.api_key

        try:
            proc = subprocess.run(
                cmd,
                cwd=str(workspace),
                env=env,
                capture_output=True,
                text=True,
                timeout=self.timeout,
                stdin=subprocess.DEVNULL,
            )
        except FileNotFoundError as exc:
            raise RuntimeError(
                f"{self.binary!r} not found on PATH. Install the Kiro CLI "
                "(curl -fsSL https://cli.kiro.dev/install | bash) or use AGENT_BACKEND=stub."
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise RuntimeError(
                f"kiro-cli timed out after {self.timeout}s. An unauthenticated headless "
                "run blocks on interactive SSO device-login — set KIRO_API_KEY (ksk_...) "
                "or run `kiro-cli login` first."
            ) from exc

        stdout = proc.stdout or ""
        stderr = proc.stderr or ""

        # Auth failure is invisible in the exit code (kiro-cli exits 0) and, on a
        # read-only intent, invisible in the workspace too — so a silent auth failure
        # would be reported as a clean "no issues" review. Detect it from the output.
        combined = f"{stdout}\n{stderr}".lower()
        if any(m in combined for m in _AUTH_FAILURE_MARKERS):
            raise RuntimeError(
                "kiro-cli authentication failed — set a valid KIRO_API_KEY (ksk_...) or "
                "run `kiro-cli login`. (Detected from CLI output; kiro-cli exits 0 on "
                "auth failure.)"
            )
        # A non-zero exit is a genuine crash / bad args — never land a partial change.
        if proc.returncode != 0:
            raise RuntimeError(
                redact(f"kiro-cli failed (exit {proc.returncode}): "
                       f"{stderr.strip() or stdout.strip() or '(no output)'}")
            )

        # The orchestrator inspects the workspace for changes; Kiro reports via stdout.
        changed = _workspace_dirty(workspace)
        return AgentResult(
            changed=changed,
            summary=stdout.strip()[-2000:] or "Kiro run completed.",
            raw_stdout=stdout,
            exit_code=proc.returncode,
        )


def _workspace_dirty(workspace: Path) -> bool:
    out = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=str(workspace),
        capture_output=True,
        text=True,
    )
    return bool(out.stdout.strip())
