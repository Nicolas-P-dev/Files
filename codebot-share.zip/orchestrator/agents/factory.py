"""Select the coding agent by backend name (env-driven)."""

from __future__ import annotations

from orchestrator.agents.base import CodingAgent
from orchestrator.agents.kiro import KiroAgent
from orchestrator.agents.stub import StubAgent


def make_agent(backend: str, *, kiro_api_key: str = "") -> CodingAgent:
    backend = (backend or "").strip().lower()
    if backend == "stub":
        return StubAgent()
    if backend == "kiro":
        return KiroAgent(api_key=kiro_api_key)
    raise ValueError(f"Unknown AGENT_BACKEND: {backend!r} (expected 'stub' or 'kiro')")
