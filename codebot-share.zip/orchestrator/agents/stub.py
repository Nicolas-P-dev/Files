"""Deterministic stub agent.

No model, but it makes a *real* edit so branch/push/draft-MR/comment all
genuinely execute locally. This proves the plumbing, not the intelligence —
kept honest exactly as the build plan demands (real edit, real MR).
"""

from __future__ import annotations

from pathlib import Path

from orchestrator.agents.base import CodingAgent
from orchestrator.models import AgentResult, Intent, Task

_NOTES = "AGENT_NOTES.md"

_STUB_ASSUMPTIONS = [
    "No model is available locally; this is a deterministic stub edit.",
    "The real Kiro run performs the actual change at DB (config-only swap).",
]


class StubAgent(CodingAgent):
    def run(self, task: Task, workspace: Path) -> AgentResult:
        ws = Path(workspace)

        if task.intent in (Intent.REVIEW, Intent.AUDIT):
            return AgentResult(
                changed=False,
                summary="Stub review: scanned the workspace against the standards steering.",
                review_comments=[
                    "[stub][minor] Public functions should carry a short docstring.",
                    "[stub][info] No blocking issues found by the stub reviewer.",
                ],
            )

        # Mutating intents: fix / improve / feature / unknown -> a real edit.
        note = ws / _NOTES
        line = f"- [{task.intent.value}] stub edit: {task.instruction}\n"
        if note.exists():
            note.write_text(note.read_text() + line)
        else:
            note.write_text("# Agent Notes\n\n" + line)

        created: list[str] = [_NOTES]
        if task.intent == Intent.FEATURE:
            health = ws / "health.py"
            health.write_text(
                '"""Stub health endpoint added by the agent."""\n\n\n'
                "def health():\n"
                '    return {"status": "ok"}\n'
            )
            created.append("health.py")

        return AgentResult(
            changed=True,
            summary=f"Stub {task.intent.value}: updated {', '.join(created)} for "
            f"instruction {task.instruction!r}.",
            assumptions=list(_STUB_ASSUMPTIONS),
        )
