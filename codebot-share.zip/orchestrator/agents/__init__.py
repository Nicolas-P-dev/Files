"""Coding-agent seam: stub (local) and kiro (DB) implementations."""
