"""The coding-agent seam.

A CodingAgent only transforms code inside a prepared workspace and reports what
it did. It does NOT touch git or GitLab — the orchestrator owns all VCS and API
plumbing so the seam stays trivial and the stub path exercises the real pipeline.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

from orchestrator.models import AgentResult, Task


class CodingAgent(ABC):
    @abstractmethod
    def run(self, task: Task, workspace: Path) -> AgentResult:
        """Perform the task inside ``workspace`` and return what happened."""
        raise NotImplementedError

    def configure(self, agent_cfg) -> None:
        """Apply per-repo runtime tuning (model/effort/trust_tools). No-op by default."""
        return None
