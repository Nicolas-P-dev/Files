# Security review standards (baseline pack)

Apply these when reviewing or changing code. Flag violations with a severity tag
(`[blocker]` / `[major]` / `[minor]` / `[info]`).

## Secrets & credentials
- **No hardcoded secrets** — API keys, passwords, tokens, private keys, or connection
  strings must never appear in source. Use env vars / a secrets manager. `[blocker]`
- Never log secrets, tokens, or full credentials. Redact before logging. `[major]`
- Do not commit `.env`, key files, or credential dumps.

## Injection & untrusted input
- **No injection.** Never build SQL, shell commands, file paths, HTML, or LDAP queries
  by string-concatenating untrusted input. Use parameterised queries / safe APIs /
  proper escaping. `[blocker]`
- Validate and normalise input at the trust boundary; reject malformed input early.
- Avoid `eval`, `exec`, `pickle.load`, `os.system`, and shell=True on untrusted data.

## AuthN / AuthZ
- Enforce authentication and authorization on every privileged operation; never trust
  client-supplied identity/role claims without server-side checks. `[blocker]`
- Apply least privilege to tokens, DB users, and network access. Don't broaden scopes
  to make something work.

## Crypto & transport
- Use vetted libraries; never roll your own crypto. Use TLS for data in transit.
- Use strong, salted password hashing (argon2/bcrypt/scrypt) — never MD5/SHA1 for
  passwords. `[major]`

## Data handling & dependencies
- Don't expose stack traces, internal paths, or sensitive data in error responses.
- Avoid known-vulnerable or unpinned dependencies; flag risky additions.
- Be careful with deserialization, SSRF (server-side request forgery), path traversal,
  and open redirects.

## What "good" looks like
Parameterised queries, secrets from the environment, input validated at the edge,
authz checked server-side, least-privilege tokens, dependencies pinned, errors logged
with context but without secrets.
