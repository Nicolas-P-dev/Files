# General engineering standards (baseline pack)

## Correctness & tests
- Every change has a test. Bug fixes start with a failing test that reproduces the bug.
- Tests assert real behaviour, not mocks. No skipped/commented-out tests left behind.
- Pristine output: no errors or warnings.

## Code quality
- DRY / YAGNI — no duplication, no speculative generality. Build what the task needs.
- Small, focused units with clear names and one responsibility.
- Match the surrounding code's style, naming, and error-handling idioms.
- Handle errors explicitly — no bare `except` / swallowed errors; surface with context.
- Public functions carry a short docstring describing intent.

## Process
- Conventional, scoped commits — one logical change per commit.
- Draft MRs only, assigned to a human; the agent never merges or approves.
- Never modify CI/pipeline or branch-protection/ownership files.
- Document assumptions in the MR description (autonomous-with-documented-assumptions).
