"""Agentic GitLab code assistant — orchestrator package."""
