"""Resolve the access token / webhook secret for a project.

Registry value (the onboarded per-repo credential) first; falls back to the `.env`
``GITLAB_TOKEN`` / ``WEBHOOK_SECRET`` so the original single-project setup keeps working.
When the shared bot lands, ``token_for`` simply returns the central bot token and the
registry becomes optional.
"""

from __future__ import annotations


def token_for(project_id, settings, registry=None) -> str:
    if registry is not None:
        rec = registry.get(str(project_id))
        if rec and rec.token:
            return rec.token
    return getattr(settings, "gitlab_token", "")


def secret_for(project_id, settings, registry=None) -> str:
    if registry is not None:
        rec = registry.get(str(project_id))
        if rec and rec.webhook_secret:
            return rec.webhook_secret
    return getattr(settings, "webhook_secret", "")
