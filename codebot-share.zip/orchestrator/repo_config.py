"""Per-repo customization: the `.codebot/` convention.

`.codebot/` is the human-authored, version-controlled source of truth that lives in
the TARGET repo. The orchestrator reads it here and compiles it into (a) its own
behavior and (b) the agent's context. It is tool-agnostic: swap the runtime agent and
only the projection step changes. (Kiro's own `.kiro/` is a separate, respected space.)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml

from orchestrator.models import Intent

_PACKS_DIR = Path(__file__).parent / "standard_packs"
_DEFAULT_INTENTS = ["review", "audit", "fix", "improve", "feature"]


@dataclass
class Branching:
    prefix: str = "codebot"
    target_branch: str = "main"
    reuse_mr_branch: bool = True


@dataclass
class Review:
    focus: list[str] = field(default_factory=list)
    reviewers: list[str] = field(default_factory=list)
    labels: list[str] = field(default_factory=list)
    apply_fixes: bool = True  # `review` applies confident fixes; `audit` never does


@dataclass
class Standards:
    packs: list[str] = field(default_factory=list)
    rules: list[str] = field(default_factory=list)
    ref: list[str] = field(default_factory=list)


@dataclass
class AgentTuning:
    model: str | None = None
    effort: str | None = None
    trust_tools: list[str] = field(default_factory=list)


@dataclass
class Safety:
    draft_only: bool = True  # always-on today; setting false has no effect yet
    max_changed_files: int = 50
    require_plan_approval: bool = False  # parsed for forward-compat; not executed yet


@dataclass
class Triggers:
    review_on_open: bool = False  # auto-post a read-only review when an MR opens


@dataclass
class RepoConfig:
    enabled: bool = True
    goal: str = ""
    intents_allow: list[str] = field(default_factory=lambda: list(_DEFAULT_INTENTS))
    branching: Branching = field(default_factory=Branching)
    review: Review = field(default_factory=Review)
    protected_paths: list[str] = field(default_factory=list)
    standards: Standards = field(default_factory=Standards)
    commands: dict[str, str] = field(default_factory=dict)
    connected_systems: list[dict] = field(default_factory=list)  # parsed; scanners not run yet
    agent: AgentTuning = field(default_factory=AgentTuning)
    safety: Safety = field(default_factory=Safety)
    triggers: Triggers = field(default_factory=Triggers)

    @classmethod
    def default(cls) -> "RepoConfig":
        return cls()

    @classmethod
    def from_dict(cls, d: dict) -> "RepoConfig":
        d = d or {}
        intents = (d.get("intents") or {}).get("allow", list(_DEFAULT_INTENTS))
        br = d.get("branching") or {}
        rv = d.get("review") or {}
        st = d.get("standards") or {}
        ag = d.get("agent") or {}
        sf = d.get("safety") or {}
        return cls(
            enabled=bool(d.get("enabled", True)),
            goal=str(d.get("goal", "") or "").strip(),
            intents_allow=list(intents),
            branching=Branching(
                prefix=br.get("prefix", "codebot"),
                target_branch=br.get("target_branch", "main"),
                reuse_mr_branch=bool(br.get("reuse_mr_branch", True)),
            ),
            review=Review(
                focus=list(rv.get("focus", [])),
                reviewers=list(rv.get("reviewers", [])),
                labels=list(rv.get("labels", [])),
                apply_fixes=bool(rv.get("apply_fixes", True)),
            ),
            protected_paths=list(d.get("protected_paths", [])),
            standards=Standards(
                packs=list(st.get("packs", [])),
                rules=list(st.get("rules", [])),
                ref=list(st.get("ref", [])),
            ),
            commands=dict(d.get("commands", {})),
            connected_systems=list(d.get("connected_systems", [])),
            agent=AgentTuning(
                model=ag.get("model"),
                effort=ag.get("effort"),
                trust_tools=list(ag.get("trust_tools", [])),
            ),
            safety=Safety(
                draft_only=bool(sf.get("draft_only", True)),
                max_changed_files=int(sf.get("max_changed_files", 50)),
                require_plan_approval=bool(sf.get("require_plan_approval", False)),
            ),
            triggers=Triggers(
                review_on_open=bool((d.get("triggers") or {}).get("review_on_open", False)),
            ),
        )


def load_repo_config(workspace: Path | str) -> RepoConfig:
    """Load `<workspace>/.codebot/config.yml` (defaults if absent/malformed)."""
    base = Path(workspace) / ".codebot"
    path = next((base / n for n in ("config.yml", "config.yaml") if (base / n).exists()), None)
    if path is None:
        return RepoConfig.default()
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        if not isinstance(data, dict):
            return RepoConfig.default()
        return RepoConfig.from_dict(data)
    except Exception:
        return RepoConfig.default()


def is_intent_allowed(cfg: RepoConfig, intent: Intent) -> bool:
    return intent.value in cfg.intents_allow


def extra_protected_globs(cfg: RepoConfig) -> list[str]:
    return list(cfg.protected_paths)


def resolve_standard_packs(names: list[str]) -> list[str]:
    """Return the markdown body of each known baseline pack (unknown names ignored)."""
    out: list[str] = []
    for name in names or []:
        p = _PACKS_DIR / f"{name}.md"
        if p.exists():
            out.append(p.read_text(encoding="utf-8"))
    return out


def compiled_context(workspace: Path | str, cfg: RepoConfig) -> str:
    """Compile `.codebot/` (+ baseline packs) into one markdown block for the agent."""
    base = Path(workspace) / ".codebot"
    parts: list[str] = []

    if cfg.goal:
        parts.append(f"## Goal\n{cfg.goal}")
    if cfg.review.focus:
        parts.append("## Review focus\n" + ", ".join(cfg.review.focus))

    standards: list[str] = []
    standards += resolve_standard_packs(cfg.standards.packs)
    standards += [f"- {r}" for r in cfg.standards.rules]
    base_resolved = base.resolve()
    for ref in cfg.standards.ref:
        # `.codebot/config.yml` is untrusted (repo-owned). Confine refs to the
        # `.codebot/` folder: reject `../` traversal and absolute paths that would
        # otherwise read arbitrary host files into the agent context.
        p = (base / ref).resolve()
        if not p.is_relative_to(base_resolved):
            continue
        if p.exists():
            standards.append(p.read_text(encoding="utf-8"))
    if standards:
        parts.append("## Standards\n" + "\n".join(standards))

    if cfg.commands:
        parts.append("## Commands\n" + "\n".join(f"- {k}: `{v}`" for k, v in cfg.commands.items()))

    for sub in ("steering", "memory"):
        d = base / sub
        if d.exists():
            for f in sorted(d.glob("*.md")):
                parts.append(f"## {sub}/{f.name}\n{f.read_text(encoding='utf-8')}")

    return "\n\n".join(parts).strip()
