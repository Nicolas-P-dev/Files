"""Project registry — the per-repo credential store for onboarding.

Maps a GitLab ``project_id`` to the access token and webhook secret codebot uses for
that repo. The token is encrypted at rest (Fernet). This is the interim store until a
shared bot user exists; at DB it is replaced by Secrets Manager + a metadata table.
"""

from __future__ import annotations

import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path

from cryptography.fernet import Fernet, InvalidToken

_TOKEN_MASK = "***"


@dataclass
class RepoRecord:
    project_id: str
    project_path: str
    token: str  # decrypted by get(); masked by list()
    webhook_secret: str
    status: str
    updated_at: float


class Registry:
    def __init__(self, db_path: Path | str, enc_key: bytes | str) -> None:
        self.db_path = str(db_path)
        self._fernet = Fernet(enc_key)
        self._init_db()

    def _init_db(self) -> None:
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(self.db_path) as con:
            con.execute(
                "CREATE TABLE IF NOT EXISTS repos ("
                "project_id TEXT PRIMARY KEY, project_path TEXT, token_enc BLOB, "
                "webhook_secret TEXT, status TEXT, updated_at REAL)"
            )

    def register(
        self, project_id: str, project_path: str, token: str, webhook_secret: str,
        status: str = "active",
    ) -> None:
        token_enc = self._fernet.encrypt(token.encode())
        with sqlite3.connect(self.db_path) as con:
            con.execute(
                "INSERT INTO repos (project_id, project_path, token_enc, webhook_secret, "
                "status, updated_at) VALUES (?, ?, ?, ?, ?, ?) "
                "ON CONFLICT(project_id) DO UPDATE SET project_path=excluded.project_path, "
                "token_enc=excluded.token_enc, webhook_secret=excluded.webhook_secret, "
                "status=excluded.status, updated_at=excluded.updated_at",
                (str(project_id), project_path, token_enc, webhook_secret, status, time.time()),
            )

    def get(self, project_id: str) -> RepoRecord | None:
        with sqlite3.connect(self.db_path) as con:
            row = con.execute(
                "SELECT project_id, project_path, token_enc, webhook_secret, status, "
                "updated_at FROM repos WHERE project_id=?",
                (str(project_id),),
            ).fetchone()
        if row is None:
            return None
        try:
            token = self._fernet.decrypt(row[2]).decode()
            status = row[4]
        except InvalidToken:
            # The encryption key was lost or rotated — the token can't be recovered.
            # Degrade to a re-onboard signal instead of crashing the webhook; the
            # plaintext webhook secret is still usable for request auth, and an empty
            # token makes the resolver fall back to the global GITLAB_TOKEN.
            token = ""
            status = "needs_reonboard"
        return RepoRecord(
            project_id=row[0],
            project_path=row[1],
            token=token,
            webhook_secret=row[3],
            status=status,
            updated_at=row[5],
        )

    def list(self) -> list[RepoRecord]:
        with sqlite3.connect(self.db_path) as con:
            rows = con.execute(
                "SELECT project_id, project_path, webhook_secret, status, updated_at "
                "FROM repos ORDER BY updated_at DESC"
            ).fetchall()
        # The token is never exposed in a listing.
        return [
            RepoRecord(
                project_id=r[0], project_path=r[1], token=_TOKEN_MASK,
                webhook_secret=r[2], status=r[3], updated_at=r[4],
            )
            for r in rows
        ]

    def set_status(self, project_id: str, status: str) -> None:
        with sqlite3.connect(self.db_path) as con:
            con.execute(
                "UPDATE repos SET status=?, updated_at=? WHERE project_id=?",
                (status, time.time(), str(project_id)),
            )
