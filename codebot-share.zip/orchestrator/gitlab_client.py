"""GitLab API operations via python-gitlab.

Responsible for the non-git side of the pipeline: opening *draft* merge requests
and posting reply comments (top-level or threaded). Constructed with an injected
``project`` in tests; ``from_settings`` resolves the real project at runtime.

The agent never merges or approves — only draft MRs assigned to a human.
"""

from __future__ import annotations

from typing import Any


class GitLabClient:
    def __init__(self, project: Any = None, gl: Any = None) -> None:
        self.project = project
        self._gl = gl

    @classmethod
    def from_settings(
        cls, settings, project_id: str | int | None = None, token: str | None = None
    ) -> "GitLabClient":
        import gitlab

        gl = gitlab.Gitlab(settings.gitlab_url, private_token=token or settings.gitlab_token)
        project = gl.projects.get(project_id or settings.gitlab_project_id)
        return cls(project=project, gl=gl)

    def current_user_id(self) -> int | None:
        """The id of the token's user (for self-assigning the draft MR)."""
        if self._gl is None:
            return None
        self._gl.auth()
        return self._gl.user.id

    # --- merge requests -------------------------------------------------
    def create_draft_mr(
        self,
        source_branch: str,
        target_branch: str,
        title: str,
        description: str,
        assignee_ids: list[int] | None = None,
        labels: list[str] | None = None,
    ):
        if not title.lower().startswith("draft:"):
            title = f"Draft: {title}"
        payload: dict[str, Any] = {
            "source_branch": source_branch,
            "target_branch": target_branch,
            "title": title,
            "description": description,
        }
        if assignee_ids:
            payload["assignee_ids"] = assignee_ids
        if labels:
            payload["labels"] = labels
        return self.project.mergerequests.create(payload)

    def get_mr_changes(self, mr_iid: int) -> list:
        """Return the MR's changed-file entries (each has at least ``new_path``)."""
        mr = self.project.mergerequests.get(mr_iid)
        data = mr.changes()  # dict containing a 'changes' list
        if isinstance(data, dict):
            return data.get("changes", [])
        return list(data or [])

    def get_mr_source_branch(self, mr_iid: int) -> str:
        """The branch an MR is built from — so codebot can push to it directly."""
        return self.project.mergerequests.get(mr_iid).source_branch

    def ensure_webhook(self, url: str, secret: str):
        """Create-or-update the project webhook (Comments + MR events) for ``url``."""
        payload = {
            "url": url,
            "token": secret,
            "note_events": True,
            "merge_requests_events": True,
            "push_events": False,
            "enable_ssl_verification": True,
        }
        existing = next((h for h in self.project.hooks.list(get_all=True) if h.url == url), None)
        if existing is not None:
            for k, v in payload.items():
                setattr(existing, k, v)
            existing.save()
            return existing
        return self.project.hooks.create(payload)

    def resolve_user_ids(self, usernames: list[str]) -> list[int]:
        """Map GitLab usernames to user ids (skips unknowns)."""
        if not usernames or self._gl is None:
            return []
        ids: list[int] = []
        for name in usernames:
            found = self._gl.users.list(username=name)
            if found:
                ids.append(found[0].id)
        return ids

    # --- comments -------------------------------------------------------
    def post_comment(
        self, kind: str, iid: int, body: str, discussion_id: str | None = None
    ):
        if kind == "mr":
            target = self.project.mergerequests.get(iid)
        elif kind == "issue":
            target = self.project.issues.get(iid)
        else:
            raise ValueError(f"Unknown comment target kind: {kind!r} (expected 'mr'/'issue')")

        if discussion_id:
            discussion = target.discussions.get(discussion_id)
            return discussion.notes.create({"body": body})
        return target.notes.create({"body": body})
