"""Map a free-text instruction to an Intent.

Keyword based with a fixed precedence: a "review" request wins even when the
text also mentions fixing, because review is non-mutating and safest to default
to. Order below is the precedence order.
"""

from __future__ import annotations

import re

from orchestrator.models import Intent

# (Intent, list of word-boundary keywords). First matching group wins.
_RULES: list[tuple[Intent, tuple[str, ...]]] = [
    (Intent.INIT, ("init", "onboard")),
    (Intent.AUDIT, ("audit",)),
    (Intent.REVIEW, ("review",)),
    (Intent.FIX, ("fix", "repair", "failing")),
    (Intent.IMPROVE, ("improve", "refactor", "clean up", "cleanup", "optimi")),
    (Intent.FEATURE, ("add", "implement", "create", "feature", "endpoint", "build")),
]


def parse_intent(text: str) -> Intent:
    t = (text or "").lower()
    for intent, keywords in _RULES:
        for kw in keywords:
            # word-boundary match so "addendum" does not trigger "add"
            if re.search(r"\b" + re.escape(kw), t):
                return intent
    return Intent.UNKNOWN
