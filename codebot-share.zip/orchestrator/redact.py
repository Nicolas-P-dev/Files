"""Redact secrets from any text that leaves the process.

The agent runs with `execute_bash` trust and could echo a credential to stdout; that
stdout flows into MR descriptions, GitLab comments, and Langfuse traces. Git errors and
clone URLs can also carry the injected `oauth2:<token>@` userinfo. Everything crossing one
of those boundaries goes through `redact()` first.
"""

from __future__ import annotations

import re

# URL userinfo (e.g. oauth2:<token>@host) — the injected clone credential.
_USERINFO_RE = re.compile(r"://[^/@\s]+@")

# Known token shapes, masked wherever they appear (not just inside a URL).
_TOKEN_RES = (
    re.compile(r"glpat-[A-Za-z0-9_-]{8,}"),        # GitLab personal/project access token
    re.compile(r"glptt-[A-Za-z0-9_-]{8,}"),        # GitLab pipeline trigger token
    re.compile(r"ksk_[A-Za-z0-9_-]{8,}"),          # Kiro session key
    re.compile(r"(?:pk|sk)-lf-[A-Za-z0-9-]{8,}"),  # Langfuse public/secret key
)


def redact(text: str) -> str:
    """Mask credentials in `text` (URL userinfo + known token prefixes)."""
    out = _USERINFO_RE.sub("://***@", text or "")
    for pat in _TOKEN_RES:
        out = pat.sub("***", out)
    return out
