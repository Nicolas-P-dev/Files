"""CLI entrypoint — the early-phase trigger before the webhook exists.

    python -m orchestrator.cli --intent fix --instruction "fix the failing tests"
    python -m orchestrator.cli --instruction "add a /health endpoint" --issue 7

Builds a Task from flags + Settings, wires the real Orchestrator (real GitLab
client + git clone, env-selected agent backend), runs it, and prints the result.
"""

from __future__ import annotations

import argparse
import sys

from orchestrator.agents.factory import make_agent
from orchestrator.config import Settings, load_settings
from orchestrator.gitlab_client import GitLabClient
from orchestrator.intent import parse_intent
from orchestrator.models import Intent, Task
from orchestrator.observability import build_tracer_provider, get_tracer
from orchestrator.orchestrator import Orchestrator


def build_task_from_args(argv: list[str], settings: Settings) -> Task:
    parser = argparse.ArgumentParser(prog="orchestrator.cli")
    parser.add_argument("--intent", choices=[i.value for i in Intent], default=None)
    parser.add_argument("--instruction", required=True)
    parser.add_argument("--mr", type=int, default=None, help="merge request iid")
    parser.add_argument("--issue", type=int, default=None, help="issue iid")
    parser.add_argument("--discussion", default=None, help="discussion id to reply in")
    args = parser.parse_args(argv)

    intent = Intent(args.intent) if args.intent else parse_intent(args.instruction)
    if args.mr:
        source_kind, source_iid = "mr", args.mr
    elif args.issue:
        source_kind, source_iid = "issue", args.issue
    else:
        source_kind, source_iid = "cli", None

    repo_url = f"{settings.gitlab_url.rstrip('/')}/{settings.gitlab_project}.git"

    return Task(
        intent=intent,
        instruction=args.instruction,
        project_id=settings.gitlab_project_id,
        repo_url=repo_url,
        default_branch=settings.gitlab_default_branch,
        source_kind=source_kind,
        source_iid=source_iid,
        discussion_id=args.discussion,
    )


def main(argv: list[str] | None = None) -> int:
    settings = load_settings()
    task = build_task_from_args(argv if argv is not None else sys.argv[1:], settings)

    agent = make_agent(settings.agent_backend, kiro_api_key=settings.kiro_api_key)
    gitlab_client = GitLabClient.from_settings(settings)

    # Assign the draft MR to a human (here: the token user) so it never auto-merges.
    assignee = gitlab_client.current_user_id()
    assignee_ids = [assignee] if assignee else None

    provider = build_tracer_provider(settings)
    tracer = get_tracer(provider)

    orch = Orchestrator(
        settings,
        agent,
        gitlab_client,
        assignee_ids=assignee_ids,
        tracer=tracer,
    )

    print(f"[orchestrator] backend={settings.agent_backend} intent={task.intent.value} "
          f"project={settings.gitlab_project}")
    result = orch.run(task)
    provider.force_flush()  # ensure spans reach Langfuse before exit

    print("\n=== result ===")
    print(f"changed:  {result.changed}")
    if result.branch:
        print(f"branch:   {result.branch}")
    if result.mr_url:
        print(f"draft MR: {result.mr_url}")
    print(f"summary:  {result.summary}")
    if result.review_comments:
        print("review comments:")
        for c in result.review_comments:
            print(f"  - {c}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
