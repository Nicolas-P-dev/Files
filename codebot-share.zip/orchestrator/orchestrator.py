"""The core flow.

prepare workspace -> load the repo's .codebot/ config -> (gate) -> invoke the agent
seam -> land the change. MR-triggered changes push to the MR's own branch; issue/
standalone triggers open a fresh draft MR. Per-repo config customizes behavior; the
compiled .codebot/ context is delivered to the agent via git-excluded Kiro steering.

The orchestrator owns all VCS/GitLab plumbing so the stub path genuinely exercises it.
"""

from __future__ import annotations

import fnmatch
import os
import re
import secrets
import shutil
import stat
import tempfile
import time
from pathlib import Path
from urllib.parse import urlparse

from opentelemetry import trace

from orchestrator.git_repo import GitRepo
from orchestrator.models import AgentResult, Intent, Task
from orchestrator.redact import redact
from orchestrator.repo_config import (
    compiled_context,
    extra_protected_globs,
    is_intent_allowed,
    load_repo_config,
)
from orchestrator.scaffold import scaffold_codebot
from orchestrator.workspace import prepare_workspace, write_agent_context

_BOT_NAME = "codebot"
_BOT_EMAIL = "codebot@users.noreply.gitlab.com"

# Files the agent must never modify (CI / pipeline / branch-protection / ownership).
# Enforced deterministically at the orchestrator seam, not just via prose steering.
_FORBIDDEN_RE = re.compile(
    r"(^|/)(\.gitlab-ci\.yml|CODEOWNERS)$|(^|/)\.gitlab/|(^|/)\.github/",
    re.IGNORECASE,
)


def _is_forbidden(path: str, extra_globs: list[str] | tuple[str, ...] = ()) -> bool:
    p = path.replace("\\", "/")
    if _FORBIDDEN_RE.search(p):
        return True
    return any(fnmatch.fnmatch(p, g) for g in extra_globs)


def _slug(text: str, n: int = 32) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", (text or "").lower()).strip("-")
    return (s[:n].strip("-")) or "task"


def _force_rmtree(path: Path) -> None:
    """Remove a tree, clearing read-only bits (git pack files on Windows)."""

    def _onexc(func, p, _exc):
        try:
            os.chmod(p, stat.S_IWRITE)
            func(p)
        except OSError:
            pass

    shutil.rmtree(path, onexc=_onexc)


class Orchestrator:
    def __init__(
        self,
        settings,
        agent,
        gitlab_client,
        *,
        clone_fn=GitRepo.clone,
        assignee_ids: list[int] | None = None,
        bot_name: str = _BOT_NAME,
        bot_email: str = _BOT_EMAIL,
        gitlab_token: str | None = None,
        tracer=None,
    ) -> None:
        self.settings = settings
        self.agent = agent
        self.gitlab = gitlab_client
        self.clone_fn = clone_fn
        self.assignee_ids = assignee_ids  # default reviewer when the repo configures none
        self.bot_name = bot_name
        self.bot_email = bot_email
        # Per-repo clone token (onboarded credential); falls back to the env token.
        self.gitlab_token = gitlab_token or getattr(settings, "gitlab_token", "")
        self.tracer = tracer or trace.get_tracer("orchestrator")

    def run(self, task: Task, *, workspace_dir: Path | str | None = None) -> AgentResult:
        owns_workspace = workspace_dir is None
        dest = Path(workspace_dir) if workspace_dir else Path(tempfile.mkdtemp(prefix="ws-"))
        try:
            with self.tracer.start_as_current_span("task.received") as root:
                root.set_attribute("intent", task.intent.value)
                root.set_attribute("project_id", task.project_id)
                root.set_attribute("source_kind", task.source_kind)
                root.set_attribute("agent.backend", getattr(self.settings, "agent_backend", ""))
                if task.author:
                    root.set_attribute("author", task.author)

                with self.tracer.start_as_current_span("workspace.prepared") as wsp:
                    repo = prepare_workspace(
                        task,
                        dest=dest,
                        clone_fn=self.clone_fn,
                        token=self.gitlab_token,
                        allowed_host=urlparse(getattr(self.settings, "gitlab_url", "")).hostname,
                    )
                    wsp.set_attribute("workspace.path", str(dest))

                cfg = load_repo_config(repo.path)

                # Onboarding: scaffold .codebot/ and open a draft MR (bypasses the gate
                # and the agent seam — it bootstraps a repo that may have no config yet).
                if task.intent == Intent.INIT:
                    result = self._init_repo(task, repo, cfg)
                    root.set_attribute("outcome", "init")
                    if result.mr_url:
                        root.set_attribute("mr.url", result.mr_url)
                    return result

                # Auto-triggered (MR-open) runs only proceed if the repo opted in —
                # and silently, so repos that didn't opt in see no noise.
                if task.auto and not cfg.triggers.review_on_open:
                    root.set_attribute("outcome", "auto-disabled")
                    return AgentResult(changed=False, summary="auto-review not enabled for this repo")

                # Gate: respect the repo's on/off switch and intent allow-list.
                gate = self._gate_reason(task, cfg)
                if gate is not None:
                    with self.tracer.start_as_current_span("gitlab.comment"):
                        self._reply(task, gate)
                    root.set_attribute("outcome", "gated")
                    return AgentResult(changed=False, summary=gate)

                # `audit` is read-only; `review` mutates only when apply_fixes is on.
                mutating = self._is_mutating(task, cfg)

                # MR-triggered changes work on (and push to) the MR's own branch.
                reuse_branch = None
                if (
                    task.source_kind == "mr"
                    and task.source_iid
                    and cfg.branching.reuse_mr_branch
                    and mutating
                ):
                    with self.tracer.start_as_current_span("vcs.checkout_mr_branch") as s:
                        reuse_branch = self.gitlab.get_mr_source_branch(task.source_iid)
                        repo.checkout(reuse_branch)
                        s.set_attribute("branch", reuse_branch)

                # Apply per-repo runtime tuning (model/effort/trust_tools) to the agent.
                self.agent.configure(cfg.agent)

                # Compile the repo's .codebot/ guidance and deliver it to the agent
                # (git-excluded so it never lands in the MR).
                write_agent_context(repo.path, compiled_context(repo.path, cfg))

                with self.tracer.start_as_current_span("agent.invoke") as asp:
                    asp.set_attribute("agent.backend", getattr(self.settings, "agent_backend", ""))
                    t0 = time.perf_counter()
                    result = self.agent.run(task, repo.path)
                    # The agent runs with execute_bash trust and could echo a credential
                    # into its output. Redact every agent-derived field before it reaches
                    # an MR body, a GitLab comment, or a trace.
                    self._sanitize(result)
                    asp.set_attribute("agent.duration_ms", round((time.perf_counter() - t0) * 1000, 1))
                    asp.set_attribute("agent.changed", result.changed)
                    asp.set_attribute("agent.exit_code", result.exit_code)
                    if result.raw_stdout:
                        asp.add_event("agent.stdout", {"stdout": result.raw_stdout[:8000]})

                if result.changed and mutating:
                    self._land_change(task, repo, result, cfg, reuse_branch)
                else:
                    # read-only (audit / review-only) or the agent made no change
                    self._reply_review(task, result)

                root.set_attribute("outcome", "changed" if (result.changed and mutating) else "review")
                if result.mr_url:
                    root.set_attribute("mr.url", result.mr_url)

            return result
        except Exception as exc:
            self._reply_failure(task, exc)
            raise
        finally:
            if owns_workspace:
                try:
                    _force_rmtree(dest)
                except OSError:
                    pass

    # --- onboarding (init) ---------------------------------------------
    def _init_repo(self, task: Task, repo: GitRepo, cfg) -> AgentResult:
        if not scaffold_codebot(repo.path):
            with self.tracer.start_as_current_span("gitlab.comment"):
                self._reply(
                    task,
                    "codebot is already configured here (`.codebot/config.yml` exists). "
                    "Edit that file to customise how codebot works in this repo.",
                )
            return AgentResult(changed=False, summary="already configured")

        result = AgentResult(
            changed=True,
            summary="Added a starter `.codebot/config.yml` so you can customise codebot "
            "in this repository.",
            assumptions=["Generated from the codebot starter template — tune it to your repo."],
        )
        self._land_change(task, repo, result, cfg, reuse_branch=None)
        return result

    def _sanitize(self, result: AgentResult) -> None:
        """Redact credentials from every agent-derived field that may be surfaced
        in an MR body, a GitLab comment, or a trace."""
        result.summary = redact(result.summary)
        result.raw_stdout = redact(result.raw_stdout)
        result.review_comments = [redact(c) for c in result.review_comments]
        result.assumptions = [redact(a) for a in result.assumptions]

    def _is_mutating(self, task: Task, cfg) -> bool:
        """Whether this intent may change code. `audit` never does; `review` does
        only when the repo enables apply_fixes; fix/improve/feature always do.
        Explicit whitelist so an unexpected intent (e.g. UNKNOWN) never mutates."""
        if task.intent == Intent.REVIEW:
            return bool(cfg.review.apply_fixes)
        return task.intent in (Intent.FIX, Intent.IMPROVE, Intent.FEATURE)

    # --- gating ---------------------------------------------------------
    def _gate_reason(self, task: Task, cfg) -> str | None:
        if not cfg.enabled:
            return (
                "codebot is disabled in this repository "
                "(`.codebot/config.yml` `enabled: false`). No action taken."
            )
        if not is_intent_allowed(cfg, task.intent):
            return (
                f"The `{task.intent.value}` intent is not permitted in this repository "
                "(see `.codebot/config.yml` `intents.allow`). No action taken."
            )
        return None

    # --- landing a change ----------------------------------------------
    def _land_change(self, task: Task, repo: GitRepo, result: AgentResult, cfg, reuse_branch: str | None) -> None:
        skipped = self._strip_forbidden(repo, extra_protected_globs(cfg))
        if not repo.has_changes():
            with self.tracer.start_as_current_span("gitlab.comment"):
                self._reply(
                    task,
                    "I could not open an MR: the only changes were to protected files "
                    f"({', '.join(skipped)}), which I'm not allowed to modify. No changes pushed.",
                )
            result.changed = False
            return

        changed_count = len(repo.changed_paths())
        if changed_count > cfg.safety.max_changed_files:
            with self.tracer.start_as_current_span("gitlab.comment"):
                self._reply(
                    task,
                    f"This change touches {changed_count} files, above this repo's limit of "
                    f"{cfg.safety.max_changed_files} (too many). No MR opened — please narrow the request.",
                )
            result.changed = False
            return

        assignees = self.gitlab.resolve_user_ids(cfg.review.reviewers) or self.assignee_ids
        labels = cfg.review.labels or None
        commit_msg = f"codebot: {task.intent.value} — {task.instruction}"

        if reuse_branch:
            # Push onto the existing MR's branch; the MR updates in place (no new MR).
            with self.tracer.start_as_current_span("vcs.push") as s:
                repo.commit(commit_msg, self.bot_name, self.bot_email)
                repo.push(reuse_branch)
                s.set_attribute("branch", reuse_branch)
            result.branch = reuse_branch
            with self.tracer.start_as_current_span("gitlab.comment"):
                self._reply(
                    task,
                    f"Pushed **{task.intent.value}** commits to this MR's branch "
                    f"`{reuse_branch}`.\n\n{result.summary}",
                )
            return

        # Issue/standalone trigger: create a fresh branch + draft MR.
        branch = f"{cfg.branching.prefix}/{task.intent.value}-{_slug(task.instruction)}-{secrets.token_hex(3)}"
        with self.tracer.start_as_current_span("vcs.push") as s:
            repo.checkout_new_branch(branch)
            repo.commit(commit_msg, self.bot_name, self.bot_email)
            repo.push(branch)
            s.set_attribute("branch", branch)
        result.branch = branch

        title = f"{task.intent.value.capitalize()}: {task.instruction}"
        with self.tracer.start_as_current_span("gitlab.create_mr") as s:
            mr = self.gitlab.create_draft_mr(
                branch,
                cfg.branching.target_branch,
                title,
                self._mr_description(task, result, cfg, skipped),
                assignee_ids=assignees,
                labels=labels,
            )
            result.mr_url = getattr(mr, "web_url", None)
            result.mr_iid = getattr(mr, "iid", None)
            if result.mr_iid is not None:
                s.set_attribute("mr.iid", result.mr_iid)

        with self.tracer.start_as_current_span("gitlab.comment"):
            self._reply(task, self._change_reply(task, result))

    def _strip_forbidden(self, repo: GitRepo, extra_globs: list[str]) -> list[str]:
        skipped: list[str] = []
        for code, path in repo.changed_paths():
            if _is_forbidden(path, extra_globs):
                repo.discard_path(code, path)
                skipped.append(path)
        return skipped

    # --- review ---------------------------------------------------------
    def _reply_review(self, task: Task, result: AgentResult) -> None:
        files = self._changed_files(task)
        with self.tracer.start_as_current_span("gitlab.comment"):
            self._reply(task, self._review_reply(task, result, files))

    def _changed_files(self, task: Task) -> list[str]:
        if task.source_kind != "mr" or not task.source_iid:
            return []
        with self.tracer.start_as_current_span("gitlab.get_mr_changes") as s:
            try:
                changes = self.gitlab.get_mr_changes(task.source_iid) or []
            except Exception:  # diff fetch must never block the reply
                return []
            files = [c.get("new_path") for c in changes if c.get("new_path")]
            s.set_attribute("changed_files", len(files))
            return files

    # --- comments -------------------------------------------------------
    def _reply(self, task: Task, body: str) -> None:
        if task.source_kind in ("mr", "issue") and task.source_iid:
            self.gitlab.post_comment(task.source_kind, task.source_iid, body, task.discussion_id)

    def _reply_failure(self, task: Task, exc: Exception) -> None:
        body = (
            f"Sorry — I hit an error while handling this **{task.intent.value}** request and "
            f"could not complete it.\n\n`{redact(f'{type(exc).__name__}: {exc}')}`"
        )
        try:
            self._reply(task, body)
        except Exception:
            pass  # never let a reply failure mask the original error

    # --- message bodies -------------------------------------------------
    def _mr_description(self, task: Task, result: AgentResult, cfg, skipped: list[str] | None = None) -> str:
        lines = [
            f"_Opened by @{self.bot_name} in response to: {task.instruction}_",
            "",
            "## Summary",
            result.summary,
        ]
        assumptions = result.assumptions or [
            "Autonomous run; the agent did not flag explicit assumptions "
            "(see the Summary above and the agent log)."
        ]
        lines += ["", "## Assumptions"]
        lines += [f"- {a}" for a in assumptions]

        guidance = self._repo_guidance(cfg)
        if guidance:
            lines += ["", "## Repo guidance applied", guidance]

        if skipped:
            lines += [
                "",
                "## Skipped (protected files)",
                "Changes to these files were discarded — they are off-limits:",
            ]
            lines += [f"- `{p}`" for p in skipped]

        lines += [
            "",
            "---",
            "This is a **draft** MR assigned to a human via CODEOWNERS. "
            "The agent does not merge or approve.",
        ]
        return "\n".join(lines)

    def _repo_guidance(self, cfg) -> str:
        bits: list[str] = []
        if cfg.goal:
            bits.append(f"- **Goal:** {cfg.goal}")
        if cfg.review.focus:
            bits.append(f"- **Focus:** {', '.join(cfg.review.focus)}")
        n_packs, n_rules = len(cfg.standards.packs), len(cfg.standards.rules)
        if n_packs or n_rules:
            bits.append(f"- **Standards:** {n_packs} pack(s), {n_rules} rule(s)")
        return "\n".join(bits)

    def _change_reply(self, task: Task, result: AgentResult) -> str:
        link = f" — {result.mr_url}" if result.mr_url else ""
        return (
            f"Done. Opened a draft MR for **{task.intent.value}**{link}\n\n{result.summary}"
        )

    def _review_reply(self, task: Task, result: AgentResult, files: list[str] | None = None) -> str:
        body = ["**Review** — findings below:\n"]
        if files:
            body.append(f"Reviewed {len(files)} changed file(s): {', '.join(files)}\n")
        if result.review_comments:
            body += [f"- {c}" for c in result.review_comments]
        elif result.summary and result.summary.strip():
            # Agents that report findings as free-text (e.g. Kiro on stdout) rather than
            # structured review_comments — surface that text instead of a false "no issues".
            # (summary is already redacted by _sanitize before this runs.)
            body.append(result.summary.strip())
        else:
            body.append("- No issues found.")
        return "\n".join(body)
