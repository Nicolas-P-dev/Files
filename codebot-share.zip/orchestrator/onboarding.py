"""The onboarding service — the backend of the minimal bridge.

Given a project path + an access token: validate access, register the webhook with a
generated per-repo secret, store the credential in the registry, and open a draft MR
scaffolding `.codebot/config.yml` (via the `init` flow). Everything else is GitLab-native.
"""

from __future__ import annotations

import secrets
from dataclasses import dataclass

from orchestrator.gitlab_client import GitLabClient


@dataclass
class OnboardResult:
    project_id: str
    project_path: str
    webhook_url: str
    scaffold_mr_url: str | None
    status: str


def onboard(
    project_path: str,
    token: str,
    *,
    settings,
    registry,
    gitlab_client: GitLabClient | None = None,
    run_init=None,
) -> OnboardResult:
    # Resolving the project with the token validates access (raises if it can't).
    client = gitlab_client or GitLabClient.from_settings(settings, project_id=project_path, token=token)
    project_id = str(client.project.id)

    webhook_url = f"{settings.public_base_url.rstrip('/')}/webhook"
    secret = secrets.token_urlsafe(32)
    client.ensure_webhook(webhook_url, secret)

    registry.register(project_id, project_path, token, secret)

    runner = run_init if run_init is not None else default_run_init(settings)
    try:
        scaffold_mr_url = runner(project_id, project_path, token)
        status = "active"
    except Exception:
        # The webhook + credential (the parts that make codebot functional) are already
        # stored. Only the optional scaffold MR failed — report a partial "connected"
        # state rather than total failure and a confusing half-onboarded repo. The owner
        # can retry the scaffold with `@codebot init`.
        scaffold_mr_url = None
        status = "connected"
        registry.set_status(project_id, "connected")

    return OnboardResult(
        project_id=project_id,
        project_path=project_path,
        webhook_url=webhook_url,
        scaffold_mr_url=scaffold_mr_url,
        status=status,
    )


def default_run_init(settings):
    """Build a runner that scaffolds `.codebot/` via the orchestrator's init flow."""

    def _run(project_id: str, project_path: str, token: str) -> str | None:
        from orchestrator.agents.factory import make_agent
        from orchestrator.models import Intent, Task
        from orchestrator.orchestrator import Orchestrator

        gl = GitLabClient.from_settings(settings, project_id=project_id, token=token)
        agent = make_agent(settings.agent_backend, kiro_api_key=settings.kiro_api_key)
        assignee = gl.current_user_id()
        repo_url = f"{settings.gitlab_url.rstrip('/')}/{project_path}.git"
        task = Task(
            intent=Intent.INIT,
            instruction="onboarding: scaffold .codebot/config.yml",
            project_id=project_id,
            repo_url=repo_url,
            default_branch=settings.gitlab_default_branch,
            source_kind="cli",
        )
        orch = Orchestrator(
            settings, agent, gl,
            assignee_ids=[assignee] if assignee else None,
            gitlab_token=token,
        )
        return orch.run(task).mr_url

    return _run
