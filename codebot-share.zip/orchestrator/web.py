"""Onboarding web routes — the minimal bridge UI.

Server-rendered HTML (no React build): a one-page `/onboard` form and a read-only
`/status` list. Admin-gated (HTTP Basic vs ADMIN_TOKEN) since the form accepts tokens.
Once the shared bot lands, this surface shrinks to nothing — onboarding becomes
GitLab-native (invite the bot + group webhook).
"""

from __future__ import annotations

import html
import secrets as _secrets
import time

from fastapi import Depends, FastAPI, Form, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials

from orchestrator.onboarding import onboard as _onboard

_security = HTTPBasic(auto_error=True)

_PAGE = """<!doctype html><html><head><meta charset="utf-8">
<title>codebot — {title}</title>
<style>
 body{{font:15px system-ui,sans-serif;max-width:640px;margin:40px auto;padding:0 16px;color:#222}}
 h1{{font-size:20px}} label{{display:block;margin:14px 0 4px;font-weight:600}}
 input{{width:100%;padding:8px;border:1px solid #ccc;border-radius:6px;box-sizing:border-box}}
 button{{margin-top:18px;padding:10px 16px;border:0;border-radius:6px;background:#1f7a3d;color:#fff;font-weight:600;cursor:pointer}}
 .muted{{color:#666;font-size:13px}} a{{color:#1f7a3d}}
 table{{border-collapse:collapse;width:100%;margin-top:12px}} td,th{{text-align:left;padding:6px 8px;border-bottom:1px solid #eee;font-size:14px}}
 .ok{{color:#1f7a3d;font-weight:600}}
</style></head><body>{body}</body></html>"""


def _render(title: str, body: str) -> str:
    return _PAGE.format(title=title, body=body)


_FORM_BODY = """
<h1>Connect a repository to codebot</h1>
<p class="muted">Create a <b>Project Access Token</b> in your repo
(Settings → Access Tokens; scopes <code>api</code>, <code>read_repository</code>,
<code>write_repository</code>), then paste it below. We'll register the webhook and
open a draft MR adding a starter <code>.codebot/config.yml</code>.</p>
<form method="post" action="/onboard">
 <label>Project path</label>
 <input name="project_path" placeholder="group/project" required>
 <label>Project access token</label>
 <input name="token" type="password" placeholder="glpat-..." required>
 <button type="submit">Connect</button>
</form>
<p class="muted" style="margin-top:20px"><a href="/status">View onboarded repositories →</a></p>
"""


def _result_body(res) -> str:
    mr = (
        f'<p>Starter config: <a href="{html.escape(res.scaffold_mr_url)}">draft MR</a></p>'
        if res.scaffold_mr_url else ""
    )
    pending = (
        '<p class="muted">The starter <code>.codebot/config.yml</code> MR could not be opened '
        'automatically — mention <code>@codebot init</code> in the repo to retry it.</p>'
        if res.status == "connected" and not res.scaffold_mr_url else ""
    )
    return f"""
<h1 class="ok">Connected ✓</h1>
{pending}
<p><b>{html.escape(res.project_path)}</b> (id {html.escape(res.project_id)}) is now connected.</p>
<p>Webhook: <code>{html.escape(res.webhook_url)}</code> — check delivery under the repo's
Settings → Webhooks → Recent events.</p>
{mr}
<p>Now mention <code>@codebot review</code> / <code>fix</code> / <code>improve</code> /
<code>add …</code> on a merge request or issue.</p>
<p><a href="/onboard">Connect another →</a> &nbsp; <a href="/status">Status →</a></p>
"""


def _error_body(msg: str) -> str:
    return (
        f'<h1>Could not connect</h1><p>{html.escape(msg)}</p>'
        '<p><a href="/onboard">← Back</a></p>'
    )


def _status_body(rows) -> str:
    if not rows:
        return '<h1>Onboarded repositories</h1><p class="muted">None yet. <a href="/onboard">Connect one →</a></p>'
    trs = "".join(
        f"<tr><td>{html.escape(r.project_path)}</td><td>{html.escape(r.project_id)}</td>"
        f"<td>{html.escape(r.status)}</td>"
        f"<td>{time.strftime('%Y-%m-%d %H:%M', time.localtime(r.updated_at))}</td></tr>"
        for r in rows
    )
    return (
        "<h1>Onboarded repositories</h1>"
        "<table><tr><th>Repo</th><th>Project id</th><th>Status</th><th>Updated</th></tr>"
        f"{trs}</table><p><a href=\"/onboard\">Connect another →</a></p>"
    )


def add_onboarding_routes(app: FastAPI, settings, registry, onboard_fn=_onboard) -> None:
    def _guard(creds: HTTPBasicCredentials = Depends(_security)) -> bool:
        ok = bool(settings.admin_token) and _secrets.compare_digest(creds.password, settings.admin_token)
        if not ok:
            raise HTTPException(status_code=401, detail="unauthorized", headers={"WWW-Authenticate": "Basic"})
        return True

    @app.get("/onboard", response_class=HTMLResponse)
    def onboard_form(_: bool = Depends(_guard)):
        return _render("connect a repo", _FORM_BODY)

    @app.post("/onboard", response_class=HTMLResponse)
    def onboard_submit(project_path: str = Form(...), token: str = Form(...), _: bool = Depends(_guard)):
        try:
            res = onboard_fn(project_path.strip(), token.strip(), settings=settings, registry=registry)
        except Exception as exc:  # surface the failure to the operator
            return HTMLResponse(_render("error", _error_body(f"{type(exc).__name__}: {exc}")), status_code=400)
        return _render("connected", _result_body(res))

    @app.get("/status", response_class=HTMLResponse)
    def status_page(_: bool = Depends(_guard)):
        return _render("status", _status_body(registry.list()))
