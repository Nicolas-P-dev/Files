"""FastAPI webhook — the GitLab @-mention trigger.

Verifies the webhook secret, filters Note Hook events for bot @-mentions (and
drops the bot's own notes to avoid loops), parses the task, routes the intent,
and runs the orchestrator in the background (always replying on the thread).

In AgentCore this endpoint is replaced by API Gateway + Lambda; the parsing and
routing below move unchanged.
"""

from __future__ import annotations

import hmac
import re
from urllib.parse import urlparse

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request

from orchestrator.agents.factory import make_agent
from orchestrator.config import Settings, load_settings
from orchestrator.credentials import secret_for, token_for
from orchestrator.gitlab_client import GitLabClient
from orchestrator.intent import parse_intent
from orchestrator.models import Task
from orchestrator.observability import build_tracer_provider, get_tracer
from orchestrator.orchestrator import Orchestrator

_NOTEABLE_TO_KIND = {"MergeRequest": "mr", "Issue": "issue"}


def _strip_mention(body: str, mention: str) -> str:
    return re.sub(re.escape(mention), "", body, flags=re.IGNORECASE).strip()


def build_task_from_note(
    payload: dict, *, bot_mention: str, bot_username: str, allowed_host: str | None = None
) -> Task | None:
    """Parse a GitLab Note Hook payload into a Task, or None if it should be ignored."""
    if payload.get("object_kind") != "note":
        return None

    attrs = payload.get("object_attributes", {}) or {}
    body = attrs.get("note", "") or ""
    if bot_mention.lower() not in body.lower():
        return None

    user = payload.get("user", {}) or {}
    if bot_username and user.get("username") == bot_username:
        return None  # loop prevention: ignore the bot's own notes

    kind = _NOTEABLE_TO_KIND.get(attrs.get("noteable_type"))
    if kind is None:
        return None  # only MR and issue notes are actionable

    if kind == "mr":
        iid = (payload.get("merge_request", {}) or {}).get("iid")
    else:
        iid = (payload.get("issue", {}) or {}).get("iid")
    if iid is None:
        return None  # cannot reply without a target; treat as not actionable

    project = payload.get("project", {}) or {}
    repo_url = project.get("git_http_url", "")
    # Never act on (or clone, with our token) a repo on an unconfigured host.
    if allowed_host is not None and urlparse(repo_url).hostname != allowed_host:
        return None

    instruction = _strip_mention(body, bot_mention)

    return Task(
        intent=parse_intent(instruction),
        instruction=instruction,
        project_id=str(project.get("id", "")),
        repo_url=repo_url,
        default_branch=project.get("default_branch", "main"),
        source_kind=kind,
        source_iid=iid,
        discussion_id=attrs.get("discussion_id"),
        author=user.get("username"),
    )


def build_task_from_mr_event(payload: dict, *, bot_username: str, allowed_host: str | None = None) -> Task | None:
    """Parse a GitLab Merge Request hook into an auto read-only review on open/reopen."""
    if payload.get("object_kind") != "merge_request":
        return None
    attrs = payload.get("object_attributes", {}) or {}
    if attrs.get("action") not in ("open", "reopen"):
        return None
    user = payload.get("user", {}) or {}
    if bot_username and user.get("username") == bot_username:
        return None  # loop prevention: don't auto-review codebot's own MRs
    iid = attrs.get("iid")
    if iid is None:
        return None

    project = payload.get("project", {}) or {}
    repo_url = project.get("git_http_url", "")
    if allowed_host is not None and urlparse(repo_url).hostname != allowed_host:
        return None

    return Task(
        intent=parse_intent("audit"),  # read-only review
        instruction="automatic review on merge-request open",
        project_id=str(project.get("id", "")),
        repo_url=repo_url,
        default_branch=project.get("default_branch", "main"),
        source_kind="mr",
        source_iid=iid,
        author=user.get("username"),
        auto=True,
    )


def _run_task(factory, task: Task) -> None:
    orch = factory(task)
    orch.run(task)


def _registry_from_settings(settings):
    """Build the onboarding registry when an encryption key is configured."""
    if not settings.codebot_enc_key:
        return None
    from orchestrator.registry import Registry

    return Registry(settings.codebot_db_path, settings.codebot_enc_key.encode())


def create_app(settings: Settings | None = None, orchestrator_factory=None, registry=None) -> FastAPI:
    settings = settings or load_settings()
    allowed_host = urlparse(settings.gitlab_url).hostname
    registry = registry if registry is not None else _registry_from_settings(settings)

    # One tracer provider for the app lifetime (real factory only).
    provider = build_tracer_provider(settings)
    tracer = get_tracer(provider)

    def default_factory(task: Task) -> Orchestrator:
        token = token_for(task.project_id, settings, registry)
        gl = GitLabClient.from_settings(settings, project_id=task.project_id or None, token=token)
        agent = make_agent(settings.agent_backend, kiro_api_key=settings.kiro_api_key)
        assignee = gl.current_user_id()
        assignee_ids = [assignee] if assignee else None
        return Orchestrator(
            settings,
            agent,
            gl,
            assignee_ids=assignee_ids,
            gitlab_token=token,
            tracer=tracer,
        )

    factory = orchestrator_factory or default_factory

    app = FastAPI(title="GitLab Code Assistant")

    @app.post("/webhook")
    async def webhook(request: Request, background: BackgroundTasks):
        payload = await request.json()
        project_id = str((payload.get("project") or {}).get("id") or "")
        # Verify against this project's own secret (registry), falling back to the
        # global env secret. Fail closed when none is configured.
        expected = secret_for(project_id, settings, registry)
        if not expected:
            raise HTTPException(status_code=503, detail="no webhook secret configured")
        token = request.headers.get("X-Gitlab-Token", "")
        if not hmac.compare_digest(token, expected):
            raise HTTPException(status_code=401, detail="invalid webhook token")

        task = build_task_from_note(
            payload,
            bot_mention=settings.bot_mention,
            bot_username=settings.bot_username,
            allowed_host=allowed_host,
        )
        if task is None:
            # MR-open events become an auto review (gated per-repo in the orchestrator).
            task = build_task_from_mr_event(
                payload, bot_username=settings.bot_username, allowed_host=allowed_host
            )
        if task is None:
            return {"status": "ignored"}

        background.add_task(_run_task, factory, task)
        return {"status": "accepted", "intent": task.intent.value, "source": task.source_kind}

    @app.get("/healthz")
    def healthz():
        return {"status": "ok"}

    # Onboarding bridge UI (only when a registry + admin token are configured).
    if registry is not None and settings.admin_token:
        from orchestrator.web import add_onboarding_routes

        add_onboarding_routes(app, settings, registry)

    return app


# Module-level app for `uvicorn orchestrator.webhook:app`.
# Built lazily so importing the module (e.g. in tests) never requires real config.
app = None


def get_app() -> FastAPI:
    global app
    if app is None:
        app = create_app()
    return app
