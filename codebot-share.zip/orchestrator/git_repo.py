"""Thin git wrapper (subprocess).

The orchestrator owns VCS plumbing in both backends. Subprocess git (rather than
GitPython) keeps behaviour identical to what runs in the container and is easy to
test against a local bare repo with no network.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

# Shared redaction so the GitLab token can never reach an error message, log, or trace.
from orchestrator.redact import redact as _redact


class GitError(RuntimeError):
    pass


def _git(args: list[str], cwd: Path | str) -> str:
    proc = subprocess.run(
        ["git", *args],
        cwd=str(cwd),
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        raise GitError(_redact(f"git {' '.join(args)} failed: {proc.stderr.strip()}"))
    return proc.stdout


class GitRepo:
    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)

    @classmethod
    def clone(cls, url: str, dest: Path | str, branch: str = "main") -> "GitRepo":
        dest = Path(dest)
        proc = subprocess.run(
            ["git", "clone", "--branch", branch, url, str(dest)],
            capture_output=True,
            text=True,
        )
        if proc.returncode != 0:
            # Fall back to a default-branch clone if the named branch is absent.
            proc = subprocess.run(
                ["git", "clone", url, str(dest)],
                capture_output=True,
                text=True,
            )
            if proc.returncode != 0:
                raise GitError(_redact(f"git clone failed: {proc.stderr.strip()}"))
        return cls(dest)

    def has_changes(self) -> bool:
        return bool(_git(["status", "--porcelain"], self.path).strip())

    def changed_paths(self) -> list[tuple[str, str]]:
        """Return (status_code, path) for each changed entry (porcelain)."""
        entries: list[tuple[str, str]] = []
        for line in _git(["status", "--porcelain"], self.path).splitlines():
            if not line:
                continue
            code, rest = line[:2], line[3:]
            # rename/copy lines look like "orig -> new"; keep the new path.
            path = rest.split(" -> ")[-1].strip().strip('"')
            entries.append((code, path))
        return entries

    def discard_path(self, code: str, path: str) -> None:
        """Undo a single change so it never reaches the commit. Robust to added/
        renamed paths that have no version in HEAD (a plain `checkout HEAD --`
        would fail with 'pathspec did not match' and crash the whole task)."""
        full = self.path / path
        if "?" in code or code.strip()[:1] in ("A", "R", "C"):
            # Untracked, added, or a rename/copy TARGET: nothing in HEAD to restore.
            # Remove the working-tree file and drop it from the index.
            if full.exists():
                full.unlink()
            subprocess.run(
                ["git", "rm", "-f", "--cached", "--ignore-unmatch", "--", path],
                cwd=str(self.path), capture_output=True, text=True,
            )
        else:  # tracked modification/deletion -> restore the committed version
            _git(["checkout", "HEAD", "--", path], self.path)

    def current_branch(self) -> str:
        return _git(["rev-parse", "--abbrev-ref", "HEAD"], self.path).strip()

    def checkout_new_branch(self, name: str) -> None:
        _git(["checkout", "-b", name], self.path)

    def checkout(self, name: str) -> None:
        """Check out an existing branch (e.g. an MR's source branch)."""
        _git(["checkout", name], self.path)

    def commit(self, message: str, author_name: str, author_email: str) -> None:
        _git(["add", "-A"], self.path)
        _git(
            [
                "-c",
                f"user.name={author_name}",
                "-c",
                f"user.email={author_email}",
                "commit",
                "-m",
                message,
            ],
            self.path,
        )

    def push(self, branch: str, remote: str = "origin") -> None:
        _git(["push", "-u", remote, branch], self.path)
