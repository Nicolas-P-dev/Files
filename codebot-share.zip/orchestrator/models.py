"""Core data model shared across the whole pipeline.

Defined once; used unchanged by the agent seam, the orchestrator, the webhook
and the CLI. Keeping these as plain dataclasses keeps the seam trivial to test.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Intent(str, Enum):
    """What the human asked the bot to do."""

    REVIEW = "review"
    AUDIT = "audit"
    FIX = "fix"
    IMPROVE = "improve"
    FEATURE = "feature"
    INIT = "init"
    UNKNOWN = "unknown"


@dataclass
class Task:
    """A single unit of work parsed from a CLI invocation or an @-mention."""

    intent: Intent
    instruction: str
    project_id: str
    repo_url: str
    default_branch: str = "main"
    source_kind: str = "cli"  # "mr" | "issue" | "cli"
    source_iid: int | None = None
    discussion_id: str | None = None
    author: str | None = None
    auto: bool = False  # triggered automatically (e.g. MR-open), not by an @-mention


@dataclass
class AgentResult:
    """What a coding agent (stub or kiro) did inside the workspace."""

    changed: bool
    summary: str
    assumptions: list[str] = field(default_factory=list)
    review_comments: list[str] = field(default_factory=list)
    branch: str | None = None
    mr_url: str | None = None
    mr_iid: int | None = None
    raw_stdout: str = ""
    exit_code: int = 0
