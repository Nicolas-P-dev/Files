"""Wrapper-level OpenTelemetry.

We instrument the *orchestrator* and capture the agent's stdout — we do NOT try
to instrument inside the agent (Kiro is a black box). Spans export via OTLP HTTP
to Langfuse, which accepts OpenTelemetry traces at /api/public/otel.
"""

from __future__ import annotations

import base64

from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SimpleSpanProcessor


def langfuse_otlp_endpoint(settings) -> str:
    return f"{settings.langfuse_base_url.rstrip('/')}/api/public/otel/v1/traces"


def langfuse_auth_header(settings) -> str:
    raw = f"{settings.langfuse_public_key}:{settings.langfuse_secret_key}".encode()
    return "Basic " + base64.b64encode(raw).decode()


def build_tracer_provider(settings, *, exporter=None) -> TracerProvider:
    """Build a TracerProvider.

    - ``exporter`` given (tests) -> SimpleSpanProcessor around it (sync, no network).
    - else, if Langfuse keys are set -> BatchSpanProcessor around an OTLP HTTP
      exporter pointed at Langfuse.
    - else -> a provider with no exporter (spans are created but dropped).
    """
    resource = Resource.create({"service.name": settings.otel_service_name})
    provider = TracerProvider(resource=resource)

    if exporter is not None:
        provider.add_span_processor(SimpleSpanProcessor(exporter))
    elif settings.langfuse_public_key and settings.langfuse_secret_key:
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

        otlp = OTLPSpanExporter(
            endpoint=langfuse_otlp_endpoint(settings),
            headers={"Authorization": langfuse_auth_header(settings)},
        )
        provider.add_span_processor(BatchSpanProcessor(otlp))

    return provider


def get_tracer(provider: TracerProvider, name: str = "orchestrator"):
    return provider.get_tracer(name)
