"""Scaffold a starter `.codebot/config.yml` into a workspace (the `init` flow)."""

from __future__ import annotations

import shutil
from pathlib import Path

_TEMPLATE = Path(__file__).parent / "templates" / "codebot-config.yml"


def scaffold_codebot(workspace: Path | str) -> bool:
    """Write a starter `.codebot/config.yml` if absent. Returns True if it wrote one."""
    dest = Path(workspace) / ".codebot" / "config.yml"
    if dest.exists():
        return False
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy(_TEMPLATE, dest)
    return True
