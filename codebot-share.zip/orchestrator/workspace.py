"""Prepare a workspace for the agent.

Clone the target repo, then compile the repo's `.codebot/` config + the baseline
standard packs into a single, git-excluded steering file the runtime agent (Kiro)
reads. We never copy our own files over the repo's tracked content, and we leave the
repo's own `.kiro/` / `AGENTS.md` untouched — so per-repo customization composes
cleanly. The orchestrator's baseline disciplines live in the image's GLOBAL Kiro
steering, not in the workspace.
"""

from __future__ import annotations

from pathlib import Path
from urllib.parse import urlparse

from orchestrator.git_repo import GitRepo
from orchestrator.models import Task

# Reserved name (the "zzz-" prefix keeps it last and collision-free).
_CONTEXT_FILE = "zzz-codebot-context.md"


def authenticated_url(repo_url: str, token: str, allowed_host: str | None = None) -> str:
    """Inject a token into an https GitLab clone URL (no-op otherwise).

    The token is ONLY embedded when the URL host matches ``allowed_host`` (when
    given). This prevents leaking the GitLab credential to an attacker-controlled
    host supplied via an untrusted webhook payload.
    """
    if not (token and repo_url.startswith("https://")):
        return repo_url
    if allowed_host is not None and urlparse(repo_url).hostname != allowed_host:
        return repo_url  # refuse to attach the credential to a foreign host
    return repo_url.replace("https://", f"https://oauth2:{token}@", 1)


def prepare_workspace(
    task: Task,
    *,
    dest: Path | str,
    clone_fn=GitRepo.clone,
    token: str = "",
    allowed_host: str | None = None,
) -> GitRepo:
    url = authenticated_url(task.repo_url, token, allowed_host)
    return clone_fn(url, dest, task.default_branch)


def write_agent_context(workspace: Path | str, context: str) -> Path | None:
    """Write the compiled `.codebot/` context where Kiro reads steering, but exclude
    it from commits so it never lands in the target repo's MR. No-op for empty context.
    """
    if not context or not context.strip():
        return None
    target = Path(workspace) / ".kiro" / "steering"
    target.mkdir(parents=True, exist_ok=True)
    path = target / _CONTEXT_FILE
    path.write_text(context, encoding="utf-8")
    _git_exclude(Path(workspace), f"/.kiro/steering/{_CONTEXT_FILE}")
    return path


def _git_exclude(repo_path: Path, pattern: str) -> None:
    """Append a pattern to the repo's local .git/info/exclude (untracked)."""
    info = repo_path / ".git" / "info"
    if not info.exists():
        return  # not a real git clone (e.g. a fake clone_fn in tests)
    exclude = info / "exclude"
    existing = exclude.read_text() if exclude.exists() else ""
    if pattern in existing:
        return
    sep = "" if (not existing or existing.endswith("\n")) else "\n"
    exclude.write_text(existing + sep + pattern + "\n")
