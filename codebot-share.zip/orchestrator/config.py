"""Runtime configuration loaded from environment / .env.

All knobs live here so the container is configured purely by env vars — the
only thing that differs between the local stub run and the DB real-Kiro run.
"""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # --- Agent seam ---
    agent_backend: str = "stub"  # "stub" | "kiro"

    # --- GitLab target ---
    gitlab_url: str = "https://gitlab.com"
    gitlab_project: str = ""
    gitlab_project_id: str = ""
    gitlab_token: str = ""
    gitlab_default_branch: str = "main"

    # --- Webhook (Phase 4) ---
    webhook_secret: str = ""
    bot_username: str = ""
    bot_mention: str = "@codebot"

    # --- Observability: Langfuse via OTLP HTTP ---
    langfuse_secret_key: str = ""
    langfuse_public_key: str = ""
    langfuse_base_url: str = "https://cloud.langfuse.com"
    otel_service_name: str = "gitlab-code-assistant"

    # --- Kiro (DB only) ---
    kiro_api_key: str = ""

    # --- Onboarding (the minimal bridge) ---
    codebot_db_path: str = "codebot.db"  # project registry (SQLite)
    codebot_enc_key: str = ""  # Fernet key for token-at-rest encryption
    admin_token: str = ""  # gates /onboard + /status
    public_base_url: str = ""  # public URL GitLab webhooks point at


def load_settings() -> Settings:
    """Load settings from the real environment / .env file."""
    return Settings()
