# Agentic GitLab Code Assistant (Kiro) — Local PoC

A containerised orchestrator that, triggered from GitLab via `@`-mention, drives a
headless coding agent (**Kiro CLI** — stubbed locally behind a clean seam) to
**review** MRs, push **fixes**, **improve** code, and implement **features** —
landing every change as a **draft MR** assigned to a human, with full workflow
observability (OpenTelemetry → Langfuse).

The image built locally is the exact artifact later run on AWS Bedrock AgentCore;
lifting it is a hosting + trigger change, nothing inside the container moves.

> Full design: [`docs/local-poc-build-plan.md`](docs/local-poc-build-plan.md).
> Implementation plan: [`docs/superpowers/plans/2026-06-17-gitlab-code-assistant-poc.md`](docs/superpowers/plans/2026-06-17-gitlab-code-assistant-poc.md).

## The agent seam (why a stub)

There is no Kiro API key locally, so the agent invocation sits behind an interface
selected by `AGENT_BACKEND`:

- **`stub`** — a deterministic agent that makes a *real* (if trivial) code change so
  branch/push/draft-MR/comment all genuinely execute. Proves the whole pipeline.
- **`kiro`** — `kiro-cli chat --no-interactive`, validated at DB. Swapping to it is
  **config-only**: set `AGENT_BACKEND=kiro` + `KIRO_API_KEY`.

The orchestrator owns all git + GitLab plumbing in both backends; the agent only
transforms files in a prepared workspace.

## Architecture

```
GitLab (@-mention in MR/issue → Note Hook webhook)
  → tunnel (local only)
  → Orchestrator (FastAPI): verify secret, parse intent, prepare /workspace (+ .kiro/steering)
  → Agent seam (stub | kiro)
  → git branch/commit/push + draft MR + reply comment (orchestrator-driven)
  → OTel span tree → Langfuse
  → Human reviewer (draft MR + CODEOWNERS)
```

## Layout

| Path | Responsibility |
|------|----------------|
| `orchestrator/config.py` | env/.env settings |
| `orchestrator/models.py` | `Intent`, `Task`, `AgentResult` |
| `orchestrator/intent.py` | instruction text → `Intent` |
| `orchestrator/agents/` | `CodingAgent` seam: `stub`, `kiro`, `factory` |
| `orchestrator/git_repo.py` | clone/branch/commit/push (subprocess git) |
| `orchestrator/gitlab_client.py` | draft MR + comments (python-gitlab) |
| `orchestrator/workspace.py` | clone target + carry steering in |
| `orchestrator/orchestrator.py` | the core flow |
| `orchestrator/cli.py` | CLI trigger (pre-webhook) |
| `.kiro/steering/` | Superpowers disciplines for the runtime agent (Phase 2) |
| `fixtures/` | planted-bug target service (Phase 8) |

## Setup

```bash
python -m venv .venv
.venv/Scripts/python -m pip install -r requirements-dev.txt   # Windows
# cp .env.example .env  and fill in GitLab token, Langfuse keys
```

## Run (CLI mode, stub)

```bash
.venv/Scripts/python -m orchestrator.cli --intent fix --instruction "fix the failing tests"
.venv/Scripts/python -m orchestrator.cli --instruction "add a /health endpoint" --issue 7
```

A draft MR is opened on the configured `GITLAB_PROJECT`, assigned to a human.

## Run (webhook mode)

```bash
# 1. start the orchestrator
.venv/Scripts/python -m uvicorn orchestrator.webhook:get_app --factory --port 8077
# 2. expose it (GitLab cannot reach localhost) — install one of:
cloudflared tunnel --url http://localhost:8077      # or: ngrok http 8077
# 3. register the project webhook (Comments + MR events, secret = WEBHOOK_SECRET)
.venv/Scripts/python scripts/register_webhook.py --url https://<tunnel-host>/webhook
```

Then `@codebot review` / `fix` / `improve` / `add …` on an MR or issue triggers the
matching action. `POST /webhook` verifies `X-Gitlab-Token`, ignores non-mentions and
the bot's own notes (loop prevention), routes the intent, and always replies.
`GET /healthz` is a liveness probe.

## Test

```bash
.venv/Scripts/python -m pytest -q
```

All VCS tests run offline against a local bare git repo; GitLab API calls are faked.

## Onboarding a repository

A repo owner connects their repo via the **minimal bridge**: create a Project Access
Token, paste it (+ the project path) into the `/onboard` page, and codebot registers the
webhook, stores the credential (encrypted, per-repo secret), and opens a draft MR
scaffolding `.codebot/config.yml`. `@codebot init` does the same GitLab-natively. Full
flow + operator setup: [docs/onboarding.md](docs/onboarding.md). (This custom UI is an
interim bridge that collapses to GitLab-native once a shared bot user exists.)

## Per-repo customization (`.codebot/`)

A target repo customizes how codebot behaves by adding a `.codebot/` folder (config,
agent steering, memory). The orchestrator compiles it into its own behavior (intent
allow-list, branch/target, reviewers, labels, extra protected paths, safety caps) and
into the agent's context (goal, standards packs, focus, memory). See
[docs/codebot-repo-config.md](docs/codebot-repo-config.md) and the worked
[security-review example](fixtures/planted-bugs-service/.codebot).

## Design decisions & known limitations

- **MR trigger vs issue trigger.** A change triggered **on an MR** pushes to that MR's
  own source branch (the MR updates in place; no second MR). A change triggered **on an
  issue / standalone** creates a fresh `codebot/…` branch and opens a draft MR. Branch
  prefix and target are configurable per repo via `.codebot/`.
- **Review posts a summary comment, not inline diff-anchored comments.** The plan's
  "severity-tagged inline" half needs position-anchored discussion notes and
  structured findings (file/line) — a DB/Kiro-phase feature. The orchestrator does
  fetch the MR diff (`get_mr_changes`) and lists the reviewed files.
- **Single target project.** The webhook acts on the configured GitLab host/project;
  multi-project routing is out of PoC scope.
- **Kiro backend is config-only.** `AGENT_BACKEND=kiro` + `KIRO_API_KEY` selects the real
  agent; without the CLI/key it fails fast (clear "not found" / timeout) rather than
  silently — the stub backend is the default.

## Status

- [x] **Phase 1** — bare spine (stub): CLI → clone → stub edit → real draft MR. ✅ verified (MR !1)
- [x] **Phase 2** — methodology steering (`.kiro/steering`), carried into the workspace, excluded from the MR. ✅
- [x] **Phase 3** — observability (OTel → Langfuse). ✅ verified (trace tree visible)
- [x] **Phase 4** — webhook `@`-mention trigger + intent routing. ✅ verified (review on MR !1, feature → draft MR !2)
- [x] **Phase 5** — containerise. ✅ verified (80 tests pass in-image; runtime boots, `/healthz` ok, HEALTHCHECK healthy; 276MB)

All GitLab functions are verified live against the sandbox via
[`scripts/gitlab_live_check.py`](scripts/gitlab_live_check.py) (10/10).
