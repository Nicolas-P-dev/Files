---
inclusion: always
---
# Systematic Debugging (Kiro steering)

You run headless: one prompt, no human in the loop. When the original discipline says "ask your human partner," you instead **document the assumption in the MR description and proceed.** Never block waiting for input that cannot arrive.

## The Iron Law

```
NO FIXES WITHOUT ROOT CAUSE INVESTIGATION FIRST
```

If you have not completed Phase 1, you may not propose or write a fix. Symptom fixes are failure. Violating the letter of this process violates its spirit.

## When to apply

Any bug, test failure, unexpected behavior, performance problem, build failure, or integration issue — before proposing fixes.

Apply ESPECIALLY when: under time pressure, "just one quick fix" seems obvious, you have already tried fixes, a previous fix didn't work, or you don't fully understand the issue. Do NOT skip because the bug "looks simple" — simple bugs have root causes too.

## The Four Phases — complete each before the next

### Phase 1: Root Cause Investigation (before ANY fix)
1. **Read errors carefully.** Read full stack traces, line numbers, file paths, error codes. The message often contains the solution. Don't skip warnings.
2. **Reproduce consistently.** Find exact steps; confirm it happens reliably. If not reproducible, gather more data — do not guess.
3. **Check recent changes.** `git diff`, recent commits, new dependencies, config/env differences.
4. **Instrument multi-component systems.** When the system has boundaries (CI -> build -> sign, API -> service -> DB): before fixing, log what data enters and exits each component, verify env/config propagation, check state at each layer. Run once to gather evidence showing WHERE it breaks, then investigate that specific component.
5. **Trace data flow backward.** When the error is deep in the call stack: find where the bad value originates, what called it with the bad value, keep tracing up to the source. Fix at the source, not the symptom.

### Phase 2: Pattern Analysis
1. **Find working examples** of similar code in the same codebase.
2. **Read references completely.** If applying a pattern, read the reference implementation line by line — do not skim.
3. **Identify every difference** between working and broken, however small. Don't assume "that can't matter."
4. **Understand dependencies** — required components, config, environment, assumptions.

### Phase 3: Hypothesis and Testing
1. **Form a single hypothesis.** State it: "I think X is the root cause because Y." Be specific.
2. **Test minimally.** Smallest possible change, one variable at a time. Never fix multiple things at once.
3. **Verify before continuing.** Worked -> Phase 4. Didn't work -> form a NEW hypothesis; do not stack fixes.
4. **When you don't know, say so.** Don't pretend. Investigate further; in your reasoning state "I don't understand X" and document the open question in the MR description rather than guessing silently.

### Phase 4: Implementation
1. **Create a failing test first.** Simplest reproduction; automated if a framework exists, else a one-off script. Required before fixing. Use test-driven-development for proper failing tests.
2. **Implement a single fix** at the root cause. One change. No "while I'm here" improvements or bundled refactoring.
3. **Verify the fix.** Test passes now? No other tests broken? Issue actually resolved?
4. **If the fix doesn't work: STOP and count attempts.** If < 3, return to Phase 1 with the new information. If >= 3, do not attempt fix #4 — question the architecture (below).
5. **If 3+ fixes failed: question the architecture.** Signs: each fix reveals new coupling/shared state elsewhere; fixes need "massive refactoring"; each fix creates new symptoms. This is a wrong architecture, not a failed hypothesis. **Document the architectural concern and your recommended direction in the MR description, implement the most defensible option as a draft, and flag it clearly for human review** rather than thrashing on more symptom fixes.

## Red Flags — STOP and return to Phase 1

If you catch yourself thinking any of these:
- "Quick fix for now, investigate later"
- "Just try changing X and see if it works"
- "Add multiple changes, run tests"
- "Skip the test, I'll manually verify"
- "It's probably X, let me fix that"
- "I don't fully understand but this might work"
- "Pattern says X but I'll adapt it differently"
- Listing fixes before tracing data flow
- "One more fix attempt" (when already tried 2+)
- Each fix reveals a new problem in a different place

All of these mean: STOP. Return to Phase 1. If 3+ fixes failed, question the architecture.

## Rationalization -> Reality

| Excuse | Reality |
|--------|---------|
| "Issue is simple, skip the process" | Simple issues have root causes too. The process is fast for them. |
| "Emergency, no time" | Systematic debugging is FASTER than guess-and-check thrashing. |
| "Try this first, investigate later" | The first fix sets the pattern. Do it right from the start. |
| "Test after the fix works" | Untested fixes don't stick. The test-first proves it. |
| "Multiple fixes at once saves time" | Can't isolate what worked; causes new bugs. |
| "Reference too long, I'll adapt it" | Partial understanding guarantees bugs. Read it completely. |
| "I see the problem, let me fix it" | Seeing symptoms is not understanding root cause. |
| "One more fix" (after 2+ failures) | 3+ failures = architectural problem. Question the pattern. |

## When investigation reveals no root cause

If systematic investigation shows the issue is truly environmental, timing-dependent, or external: you have completed the process. Document what you investigated in the MR description, implement appropriate handling (retry, timeout, clear error message), and add logging for future investigation. But 95% of "no root cause" cases are incomplete investigation — be sure before you conclude this.

## Headless operating rules

- Never wait for approval or mid-run input. Decide, act, and record the decision.
- Every assumption, unverified premise, open question, or architectural concern goes in the MR description so a human can review it in the draft.
- Evidence before assertions: do not claim "fixed" without showing the test run that proves it.

See 00-disciplines-index.md for when to apply this.
