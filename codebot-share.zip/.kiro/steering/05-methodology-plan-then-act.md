---
inclusion: always
---
# Methodology: Plan, then Act (Kiro steering)

Understand the intent → for non-trivial work, form a brief approach with explicit
assumptions → implement test-first → verify before declaring done. This is the
overarching "how to approach any task" methodology that ties the other disciplines
together: test-driven-development, systematic-debugging, and
verification-before-completion.

**This is guidance to think before acting — NOT a rigid template or a forced output
format.** There is no required plan document, no mandated headings, no checklist you
must reproduce. Scale the rigor to the task: a one-line fix needs no plan; a feature
does. Use judgement.

## You run headless

One prompt, no interactive approval, no mid-run human input. The Superpowers
methodology assumes interactive brainstorming and a plan-approval gate — **you have
neither.** So the reframing is:

- **No brainstorming dialogue.** You cannot ask questions one at a time and wait.
  Infer the intent from the request and the repository. Where you would ask a human,
  make the most reasonable assumption and write it down.
- **No approval gate.** Do not stop and wait for a "go" that cannot arrive. Write the
  brief plan + assumptions into the **MR description** (or the reply comment) and
  **proceed.** The human reviews the draft MR afterwards, not before.
- **Never block.** "Waiting for approval" is a failure mode here, not caution.

## The loop

1. **Understand the intent.** What outcome does the requester actually want? Read
   enough of the repo — the relevant code, its tests, the project's conventions — to
   act correctly before changing anything. Restate the goal to yourself in one
   sentence; if you can't, you don't understand it yet.
2. **Surface assumptions.** Every gap you'd normally fill by asking becomes an
   explicit assumption. Name them. Pick the most reasonable reading. These go in the
   MR description under `## Assumptions` (no silent decisions).
3. **Form an approach** (non-trivial work only). A few sentences: what you'll change,
   which files, how you'll test it, known trade-offs or risks. This is a thinking
   aid, not a deliverable — its job is to catch a wrong direction before you write
   code, and to give the reviewer your reasoning. Keep it in the MR description.
4. **Implement test-first.** Follow test-driven-development: failing test → watch it
   fail → minimal code → green. For a bug, follow systematic-debugging first
   (reproduce with a failing test before proposing any fix).
5. **Verify before declaring done.** Follow verification-before-completion: run the
   real commands, read the output, and only then make any "done / fixed / passing"
   claim — in the MR, the commit, and the reply.

## How much planning does THIS task need?

A quick decision procedure — apply it in your head, don't write it out:

- **Single obvious change** (one-line fix, typo, rename, config tweak, trivial bug
  with one clear cause)? → No plan. Make the change, still verify, still note any
  assumption. Skip straight to the test+fix.
- **Touches a few files, or has a real choice between approaches, or any ambiguity in
  the request?** → A short approach (a few sentences) + named assumptions in the MR
  description. Then proceed.
- **A feature, a multi-step change, a cross-cutting refactor, or anything where a
  wrong assumption is expensive to unwind?** → A proper brief plan: goal, the files
  you'll touch, the test strategy, the assumptions and risks. Still no approval gate —
  write it down and execute.

When unsure which bucket, spend thirty seconds more on the plan, not less. Over-
planning a small task wastes a little time; under-planning a large one wastes the run.

## Red flags (you're skipping methodology)

- You started editing code before you could state the goal in one sentence.
- You're writing implementation before a failing test exists.
- You made a judgement call (a default, a format, a scope boundary) and it's nowhere
  in the MR description — a silent assumption.
- You're "waiting for approval / confirmation" — it cannot come; proceed with
  documented assumptions instead.
- You're about to claim "done / fixed / works" without having run the verification.
- A non-trivial task and you can't point to any moment where you considered the
  approach before diving in.
- You're forcing a heavyweight plan onto a one-line fix (rigidity is also a red flag).

If any of these fire, stop and correct course before continuing.

## Bottom line

Think first, scaled to the task. Make your reasoning and assumptions visible in the
MR description instead of asking. Test-first, verify before claiming, and never block
on approval that cannot arrive.

See 00-disciplines-index.md for when to apply each discipline.
