---
inclusion: always
---
# Engineering Standards (mock DB standards) — Kiro steering

These are the standards to review against and to follow when writing code. They
stand in for the organisation's real internal standards; swap this file at DB.

## Security

- **No hardcoded secrets.** No API keys, passwords, tokens, or connection strings
  in source. Use environment variables / a secrets manager. Flag any you find.
- **No injection.** Never build SQL, shell commands, or paths by string
  concatenation of untrusted input. Use parameterised queries / safe APIs.
- **Validate input at the boundary.** Reject malformed input early with a clear error.
- **Least privilege.** Don't broaden scopes, permissions, or network access to make
  something work.

## Correctness & tests

- **Every change has a test.** Bug fixes start with a failing test that reproduces
  the bug. New behaviour is covered by tests written first.
- **Tests assert real behaviour**, not mocks. Mock only true external boundaries.
- **No skipped/commented-out tests** left behind. Pristine test output: no errors,
  no warnings.

## Code quality

- **DRY / YAGNI.** No duplication; no speculative generality. Build what the task needs.
- **Small, focused units.** One responsibility per function/file. Clear names.
- **Match the surrounding code** — its style, naming, error-handling idioms, and
  comment density. Don't introduce a new pattern unless asked.
- **Errors are handled explicitly.** No bare `except`/swallowed errors; surface or
  log with context. Fail loudly in the right place.
- **Public functions carry a short docstring/comment** describing intent.

## Process

- **Conventional, scoped commits.** One logical change per commit; clear message.
- **Draft MRs only**, assigned to a human. Describe the change, the testing done,
  and any assumptions.
- **Never touch CI/pipeline/branch-protection** files.

## Review severities (use these tags when reviewing)

- `[blocker]` — must fix before merge (security flaw, data loss, broken build).
- `[major]` — should fix (likely bug, missing tests, standards violation).
- `[minor]` — nice to fix (readability, naming, small duplication).
- `[info]` — note/observation, no action required.
