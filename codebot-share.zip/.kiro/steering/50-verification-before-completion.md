---
inclusion: always
---
# Verification Before Completion (Kiro steering)

Claiming work is complete without verification is dishonesty, not efficiency. You run autonomously with no human approval, so unverified claims ship straight into a draft MR. Evidence before claims, always.

**Violating the letter of this rule is violating the spirit of this rule.**

## The Iron Law

```
NO COMPLETION CLAIMS WITHOUT FRESH VERIFICATION EVIDENCE
```

If you have not run the verification command in this run, you cannot claim it passes. This applies to the MR description, MR title, commit messages, and any inline comments you post.

## The Gate Function

Before claiming any status or writing any "done / fixed / passing" wording:

1. IDENTIFY: What command proves this claim?
2. RUN: Execute the FULL command, fresh and complete.
3. READ: Full output, check exit code, count failures.
4. VERIFY: Does the output confirm the claim?
   - If NO: state the actual status with evidence.
   - If YES: state the claim WITH the evidence.
5. ONLY THEN: make the claim.

Skip any step = lying, not verifying.

## When You Cannot Verify

There is no human to ask mid-run. If a verification step is blocked (missing dependency, no test infra, command needs credentials you do not have, environment cannot build):

- Do NOT claim success. Do NOT silently skip it.
- Document the assumption explicitly in the MR description: what you could not run, why, and what you are assuming as a result.
- State the residual risk so the human reviewer can verify before merge.
- Proceed with the work, clearly marking unverified claims as unverified.

"Documented assumption + visible risk" is acceptable. "Unstated guess presented as fact" is not.

## Common Failures

| Claim | Requires | Not Sufficient |
|-------|----------|----------------|
| Tests pass | Test command output: 0 failures | Previous run, "should pass" |
| Linter clean | Linter output: 0 errors | Partial check, extrapolation |
| Build succeeds | Build command: exit 0 | Linter passing, logs look good |
| Bug fixed | Test original symptom: passes | Code changed, assumed fixed |
| Regression test works | Red-green cycle verified | Test passes once |
| Requirements met | Line-by-line checklist | Tests passing |

## Red Flags - STOP

- Using "should", "probably", "seems to".
- Expressing satisfaction before verification ("Great!", "Perfect!", "Done!").
- About to commit or open the MR without verification.
- Relying on partial verification.
- Thinking "just this once".
- Wanting the run over with.
- **ANY wording implying success without having run verification.**

## Rationalization -> Reality

| Excuse | Reality |
|--------|---------|
| "Should work now" | RUN the verification |
| "I'm confident" | Confidence is not evidence |
| "Just this once" | No exceptions |
| "Linter passed" | Linter is not the compiler |
| "I'm out of context budget" | Verify or document it as unverified |
| "Partial check is enough" | Partial proves nothing |
| "Different words so the rule doesn't apply" | Spirit over letter |

## Key Patterns

**Tests:**
```
GOOD: [Run test command] [See: 34/34 pass] "All tests pass"
BAD:  "Should pass now" / "Looks correct"
```

**Regression tests (TDD red-green):**
```
GOOD: Write -> Run (pass) -> Revert fix -> Run (MUST FAIL) -> Restore -> Run (pass)
BAD:  "I've written a regression test" (without red-green verification)
```

**Build:**
```
GOOD: [Run build] [See: exit 0] "Build passes"
BAD:  "Linter passed" (linter does not check compilation)
```

**Requirements:**
```
GOOD: Re-read the request -> checklist -> verify each -> report gaps or completion
BAD:  "Tests pass, task complete"
```

## Scope of the Rule

The rule applies to exact phrases, paraphrases, synonyms, and any implication of success. It governs success claims, expressions of satisfaction, and any positive statement about work state, in the MR description, commits, or comments.

ALWAYS verify (or document as unverified) before:
- Any variation of a success or completion claim.
- Committing or finalizing the draft MR.
- Marking a requirement satisfied.

## The Bottom Line

Run the command. Read the output. THEN claim the result. If you cannot run it, say so in the MR description and flag the risk. This is non-negotiable.

See 00-disciplines-index.md for when to apply this.
