---
inclusion: always
---
# Requesting Code Review (Kiro steering)

Self-review your own diff before the orchestrator lands it as a draft MR. You get ONE prompt and no interactive approval, so review is YOUR job: read the change as a hostile reviewer would, fix what you find, and document anything you cannot resolve in the MR description.

**Core principle:** Review early, review often. Untriaged issues cascade.

## Iron Laws

- NEVER skip review because the change "looks simple" or is "a one-liner".
- NEVER leave a Critical issue unfixed. If you cannot fix it, STOP and write the blocker into the MR description instead of shipping broken code.
- NEVER ship an Important issue silently. Fix it, or document why it is deferred in the MR description.
- ALWAYS verify a claim with evidence (test output, the actual diff) before asserting the work is correct.
- You have no human to ask mid-run. Any place you would "ask your partner" -> make the smallest reasonable assumption, ACT on it, and record the assumption in the MR description.

## When to Review

**Mandatory:**
- After completing the feature / fix you were asked for.
- Before signaling the change is ready to land.

**Also valuable:**
- When stuck (re-read the diff fresh).
- After fixing a complex bug (confirm you did not introduce a regression).

## Review Cycle

Run this loop before declaring done:

1. **Establish the diff.** Identify what changed vs the base branch:
   ```bash
   git diff origin/main...HEAD
   ```
   Review the FULL diff, not just the files you remember touching.

2. **Restate requirements.** Write down what the change is supposed to do (from the issue / MR prompt). Check the diff against each requirement.

3. **Read adversarially.** For every hunk ask:
   - Does this actually do what the requirement says?
   - What input breaks it? Edge cases, nulls, empty collections, errors.
   - Are there tests that would fail if this code were wrong? If not, add them.
   - Did I leave debug code, TODOs, commented-out blocks, or secrets?
   - Does it match existing patterns/conventions in the repo?

4. **Triage every finding** into Critical / Important / Minor (see table).

5. **Act on findings** by severity (see decision procedure).

6. **Re-run verification.** Tests, build, linters. Confirm output before claiming success.

## Severity & Decision Procedure

| Severity  | Meaning                                              | Action in a headless run                                                        |
|-----------|------------------------------------------------------|---------------------------------------------------------------------------------|
| Critical  | Breaks correctness, security, data, or the build     | Fix now. If unfixable, STOP and document the blocker in the MR description.      |
| Important | Wrong behavior in real cases, missing tests, bad API | Fix before declaring done. If deferring, document why in the MR description.     |
| Minor     | Style, naming, magic numbers, small cleanups         | Fix if cheap; otherwise note in the MR description as follow-up.                 |

## Documented Assumptions (headless substitute for asking)

When the original discipline would have you pause for human input, do this instead:

- Make the most defensible assumption and proceed.
- Add an **"Assumptions"** section to the MR description listing each one: what was ambiguous, what you chose, and why.
- Add a **"Review notes"** section flagging anything a human should double-check before merge (deferred Importants, risky areas, untested paths).
- If a Critical cannot be resolved without a decision you are not authorized to make, do NOT guess on irreversible/destructive behavior — leave the work as a draft and state the blocker prominently in the MR description.

## Red Flags — STOP if you catch yourself

**Never:**
- Skipping review because "it's simple".
- Marking work done with a Critical or unaddressed Important issue.
- Claiming tests pass without having run them this session.
- Suppressing a warning/error instead of fixing the cause.
- Shipping an assumption silently instead of writing it into the MR description.

**Rationalization -> Reality:**

| Rationalization                                  | Reality                                                            |
|--------------------------------------------------|-------------------------------------------------------------------|
| "It's a trivial change, no review needed."       | Trivial changes ship trivial bugs. Read the diff.                 |
| "I'll note the edge case but ship anyway."       | An unfixed Critical is not shippable. Fix it or block.            |
| "Tests probably still pass."                      | "Probably" is not evidence. Run them and read the output.         |
| "I'd ask a human, but there isn't one — skip it." | Don't skip. Assume, act, and document the assumption in the MR.   |
| "The reviewer step is for interactive work."      | You are the reviewer. Self-review is mandatory here.              |

## Done Criteria

You may signal the change is ready only when ALL hold:
- Full diff reviewed against stated requirements.
- No Critical issues remain (or the run is left as a blocked draft with the blocker documented).
- Important issues are fixed or explicitly deferred in the MR description.
- Verification (tests/build/lint) was run THIS session and the output was confirmed.
- The MR description documents every assumption and any review notes.

See 00-disciplines-index.md for when to apply this.
