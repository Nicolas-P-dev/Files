---
inclusion: always
---
# Test-Driven Development (Kiro steering)

Write the test first. Watch it fail. Write minimal code to pass.

**Core principle:** If you didn't watch the test fail, you don't know if it tests the right thing.

**Violating the letter of the rules is violating the spirit of the rules.**

You run headless: one prompt, no interactive approval, no mid-run human input. When the original discipline says "ask your human partner," you instead **document the assumption in the MR description and proceed.**

## The Iron Law

```
NO PRODUCTION CODE WITHOUT A FAILING TEST FIRST
```

Wrote code before the test? Delete it. Start over. Implement fresh from the tests.

**No exceptions:**
- Don't keep it as "reference"
- Don't "adapt" it while writing tests
- Don't look at it
- Delete means delete

## When to Use

**Always:** new features, bug fixes, refactoring, behavior changes.

**Possible exceptions:** throwaway prototypes, generated code, configuration files. If you believe an exception applies, do not silently skip — **state the exception and your reasoning in the MR description, then proceed.**

Thinking "skip TDD just this once"? Stop. That's rationalization.

## Red-Green-Refactor (the cycle)

```
RED → verify it fails correctly → GREEN → verify it passes (all green) → REFACTOR → stay green → next
```

### RED — Write Failing Test
Write one minimal test showing what should happen.
- One behavior only. "and" in the name? Split it.
- Clear name that describes the behavior.
- Real code, not mocks (mocks only if unavoidable). Test behavior, not a mock's call count.

### Verify RED — Watch It Fail (MANDATORY, never skip)
Run the test. Confirm:
- It **fails** (not errors out).
- The failure message is the one you expected.
- It fails because the feature is missing — not because of a typo.

Test passes already? You're testing existing behavior. Fix the test.
Test errors instead of failing? Fix the error, re-run until it fails correctly.

### GREEN — Minimal Code
Write the simplest code that passes the test. Just enough — nothing more.
- Don't add features, options, or config the test doesn't require (YAGNI).
- Don't refactor or "improve" unrelated code here.

### Verify GREEN — Watch It Pass (MANDATORY)
Run the test. Confirm:
- The test passes.
- Other tests still pass.
- Output is pristine — no errors, no warnings.

Test fails? Fix the code, not the test.
Other tests fail? Fix them now.

### REFACTOR — Clean Up (after green only)
Remove duplication, improve names, extract helpers. Keep tests green. Add no behavior.

### Repeat
Next failing test for the next behavior.

## Good Tests

| Quality | Good | Bad |
|---------|------|-----|
| **Minimal** | One thing. "and" in name? Split it. | `test('validates email and domain and whitespace')` |
| **Clear** | Name describes the behavior | `test('test1')` |
| **Shows intent** | Demonstrates the desired API | Obscures what the code should do |

## Rationalization → Reality

| Excuse | Reality |
|--------|---------|
| "Too simple to test" | Simple code breaks. The test takes 30 seconds. |
| "I'll test after" | Tests written after pass immediately and prove nothing. |
| "Tests after achieve the same goals" | Tests-after ask "what does this do?" Tests-first ask "what should this do?" |
| "Already manually tested it" | Ad-hoc ≠ systematic. No record, can't re-run, easy to forget cases. |
| "Deleting X hours is wasteful" | Sunk cost fallacy. Keeping unverified code is technical debt. |
| "Keep as reference, write tests first" | You'll adapt it — that's testing after. Delete means delete. |
| "Need to explore first" | Fine. Throw away the exploration, then start with TDD. |
| "Hard to test" | Listen to the test. Hard to test = hard to use. Simplify the design. |
| "TDD will slow me down" | TDD is faster than debugging in production. |
| "Existing code has no tests" | You're improving it. Add tests for the existing code. |
| "TDD is dogmatic, I'm being pragmatic" | TDD is pragmatic: catches bugs pre-merge, prevents regressions, enables refactoring. |

## Red Flags — STOP and Start Over

- Code written before the test
- Test written after the implementation
- Test passes immediately
- Can't explain why the test failed
- Tests deferred to "later"
- Rationalizing "just this once"
- "I already manually tested it"
- "Tests after achieve the same purpose"
- "It's about spirit not ritual"
- "Keep as reference" / "adapt existing code"
- "Already spent X hours, deleting is wasteful"
- "TDD is dogmatic, I'm being pragmatic"
- "This is different because..."

**All of these mean: delete the code, start over with TDD.**

## When Stuck

| Problem | Solution |
|---------|----------|
| Don't know how to test | Write the wished-for API; write the assertion first. Still unclear? Document the chosen approach as an assumption in the MR and proceed. |
| Test too complicated | Design too complicated. Simplify the interface. |
| Must mock everything | Code too coupled. Use dependency injection. |
| Test setup huge | Extract helpers. Still complex? Simplify the design. |

## Debugging Integration

Bug found? Write a failing test that reproduces it, then follow the cycle. The test proves the fix and prevents regression. Never fix a bug without a test.

## Testing Anti-Patterns (avoid)

- Testing mock behavior instead of real behavior
- Adding test-only methods to production classes
- Mocking without understanding the dependencies

## Verification Checklist (before marking work complete)

- [ ] Every new function/method has a test
- [ ] Watched each test fail before implementing
- [ ] Each test failed for the expected reason (feature missing, not typo)
- [ ] Wrote minimal code to pass each test
- [ ] All tests pass
- [ ] Output pristine (no errors, no warnings)
- [ ] Tests use real code (mocks only if unavoidable)
- [ ] Edge cases and errors covered

Can't check every box? You skipped TDD. Start over.

## Final Rule

```
Production code → a test exists and failed first
Otherwise → not TDD
```

Any deviation must be documented as an explicit assumption in the MR description.

See 00-disciplines-index.md for when to apply this.
