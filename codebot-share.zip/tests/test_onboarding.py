from cryptography.fernet import Fernet

from orchestrator.config import Settings
from orchestrator.onboarding import onboard
from orchestrator.registry import Registry


class _FakeProject:
    id = 83447596


class _FakeClient:
    def __init__(self):
        self.project = _FakeProject()
        self.webhook = None

    def ensure_webhook(self, url, secret):
        self.webhook = (url, secret)


def test_onboard_registers_webhook_stores_creds_and_scaffolds(tmp_path):
    reg = Registry(tmp_path / "r.db", Fernet.generate_key())
    settings = Settings(_env_file=None, public_base_url="https://codebot.example",
                        gitlab_url="https://gitlab.com")
    client = _FakeClient()
    inits = []

    def fake_run_init(project_id, project_path, token):
        inits.append((project_id, project_path, token))
        return "https://gitlab.com/g/p/-/merge_requests/9"

    res = onboard("g/p", "glpat-x", settings=settings, registry=reg,
                  gitlab_client=client, run_init=fake_run_init)

    assert res.project_id == "83447596"
    # webhook registered at the public base URL with a generated secret
    assert client.webhook[0] == "https://codebot.example/webhook"
    assert client.webhook[1]  # non-empty per-repo secret
    # credential + secret stored in the registry
    rec = reg.get("83447596")
    assert rec.token == "glpat-x"
    assert rec.webhook_secret == client.webhook[1]
    # scaffolding ran with the project's token and the MR link is returned
    assert inits == [("83447596", "g/p", "glpat-x")]
    assert res.scaffold_mr_url.endswith("merge_requests/9")
    assert res.status == "active"


def test_onboard_degrades_when_scaffold_fails(tmp_path):
    # If the optional scaffold MR fails AFTER the webhook + credential are stored,
    # report a partial "connected" state instead of total failure (the functional
    # parts are already in place; @codebot init can retry the scaffold). Finding #6.
    reg = Registry(tmp_path / "r.db", Fernet.generate_key())
    settings = Settings(_env_file=None, public_base_url="https://codebot.example",
                        gitlab_url="https://gitlab.com")
    client = _FakeClient()

    def boom_run_init(project_id, project_path, token):
        raise RuntimeError("scaffold clone failed")

    res = onboard("g/p", "glpat-x", settings=settings, registry=reg,
                  gitlab_client=client, run_init=boom_run_init)

    # the functional parts survived
    assert client.webhook is not None
    assert reg.get("83447596").token == "glpat-x"
    # but onboarding reports partial, not total failure
    assert res.status == "connected"
    assert res.scaffold_mr_url is None
    assert reg.get("83447596").status == "connected"
