import subprocess

import pytest


class _FakeMR:
    iid = 99
    web_url = "https://gitlab.example/mr/99"


class FakeGitLabClient:
    """Records draft-MR and comment calls; used across orchestrator tests."""

    def __init__(self):
        self.draft_mr = None
        self.comments = []
        self.mr_changes = []
        self.get_mr_changes_called = None
        self.mr_source_branch = "codebot/from-mr"
        self.user_id_map = {}

    def create_draft_mr(self, source_branch, target_branch, title, description, assignee_ids=None, labels=None):
        self.draft_mr = dict(
            source_branch=source_branch,
            target_branch=target_branch,
            title=title,
            description=description,
            assignee_ids=assignee_ids,
            labels=labels,
        )
        return _FakeMR()

    def get_mr_changes(self, mr_iid):
        self.get_mr_changes_called = mr_iid
        return self.mr_changes

    def get_mr_source_branch(self, mr_iid):
        return self.mr_source_branch

    def resolve_user_ids(self, usernames):
        return [self.user_id_map[u] for u in (usernames or []) if u in self.user_id_map]

    def post_comment(self, kind, iid, body, discussion_id=None):
        self.comments.append(dict(kind=kind, iid=iid, body=body, discussion_id=discussion_id))


@pytest.fixture
def fake_gitlab():
    return FakeGitLabClient()


def _run(cmd, cwd):
    subprocess.run(cmd, cwd=str(cwd), check=True, capture_output=True, text=True)


@pytest.fixture
def bare_remote(tmp_path):
    """A bare git repo ('remote') seeded with one commit on main, offline."""
    remote = tmp_path / "remote.git"
    subprocess.run(["git", "init", "--bare", str(remote)], check=True, capture_output=True)
    seed = tmp_path / "seed"
    subprocess.run(["git", "clone", remote.as_posix(), str(seed)], check=True, capture_output=True)
    (seed / "README.md").write_text("# seed\n")
    _run(["git", "add", "-A"], seed)
    _run(["git", "-c", "user.email=a@b.c", "-c", "user.name=t", "commit", "-m", "init"], seed)
    _run(["git", "branch", "-M", "main"], seed)
    _run(["git", "push", "origin", "main"], seed)
    return remote


def seed_to_remote(remote, work, files: dict, branch="main"):
    """Add files to a remote's branch (e.g. a .codebot/config.yml)."""
    subprocess.run(
        ["git", "clone", "--branch", branch, remote.as_posix(), str(work)],
        check=True, capture_output=True,
    )
    for rel, content in files.items():
        p = work / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content)
    _run(["git", "add", "-A"], work)
    _run(["git", "-c", "user.email=a@b.c", "-c", "user.name=t", "commit", "-m", "seed"], work)
    _run(["git", "push", "origin", branch], work)


def create_remote_branch(remote, work, name):
    """Create a branch on the remote (e.g. an existing MR's source branch)."""
    subprocess.run(["git", "clone", remote.as_posix(), str(work)], check=True, capture_output=True)
    _run(["git", "checkout", "-b", name], work)
    (work / "PLACEHOLDER.txt").write_text("placeholder\n")
    _run(["git", "add", "-A"], work)
    _run(["git", "-c", "user.email=a@b.c", "-c", "user.name=t", "commit", "-m", "branch"], work)
    _run(["git", "push", "origin", name], work)
