from pathlib import Path

import pytest

from orchestrator.repo_config import (
    RepoConfig,
    compiled_context,
    extra_protected_globs,
    is_intent_allowed,
    load_repo_config,
    resolve_standard_packs,
)
from orchestrator.models import Intent


def _write_codebot(tmp_path: Path, config_yaml: str) -> Path:
    d = tmp_path / ".codebot"
    d.mkdir()
    (d / "config.yml").write_text(config_yaml)
    return tmp_path


def test_absent_config_returns_defaults(tmp_path):
    cfg = load_repo_config(tmp_path)
    assert cfg.enabled is True
    assert cfg.intents_allow == ["review", "audit", "fix", "improve", "feature"]
    assert cfg.branching.prefix == "codebot"
    assert cfg.branching.target_branch == "main"
    assert cfg.branching.reuse_mr_branch is True
    assert cfg.safety.draft_only is True


def test_malformed_config_returns_defaults(tmp_path):
    _write_codebot(tmp_path, "this: : : not valid yaml: [")
    cfg = load_repo_config(tmp_path)
    assert cfg == RepoConfig.default()


def test_full_config_parsed(tmp_path):
    _write_codebot(
        tmp_path,
        """
enabled: true
goal: Keep it secure.
intents:
  allow: [review, fix]
branching:
  prefix: bot
  target_branch: develop
  reuse_mr_branch: false
review:
  focus: [security]
  reviewers: [alice, bob]
  labels: [codebot]
protected_paths:
  - "infra/**"
standards:
  packs: [security]
  rules: ["No secrets in code."]
commands:
  test: "pytest -q"
safety:
  max_changed_files: 5
""",
    )
    cfg = load_repo_config(tmp_path)
    assert cfg.goal == "Keep it secure."
    assert cfg.intents_allow == ["review", "fix"]
    assert cfg.branching.prefix == "bot"
    assert cfg.branching.target_branch == "develop"
    assert cfg.branching.reuse_mr_branch is False
    assert cfg.review.focus == ["security"]
    assert cfg.review.reviewers == ["alice", "bob"]
    assert cfg.review.labels == ["codebot"]
    assert cfg.protected_paths == ["infra/**"]
    assert cfg.standards.packs == ["security"]
    assert cfg.standards.rules == ["No secrets in code."]
    assert cfg.commands["test"] == "pytest -q"
    assert cfg.safety.max_changed_files == 5


def test_is_intent_allowed():
    cfg = RepoConfig.default()
    cfg.intents_allow = ["review"]
    assert is_intent_allowed(cfg, Intent.REVIEW) is True
    assert is_intent_allowed(cfg, Intent.FIX) is False


def test_review_apply_fixes_default_true_and_parses():
    assert RepoConfig.default().review.apply_fixes is True
    cfg = RepoConfig.from_dict({"review": {"apply_fixes": False}})
    assert cfg.review.apply_fixes is False


def test_audit_in_default_intents():
    assert "audit" in RepoConfig.default().intents_allow


def test_triggers_review_on_open():
    assert RepoConfig.default().triggers.review_on_open is False
    assert RepoConfig.from_dict({"triggers": {"review_on_open": True}}).triggers.review_on_open is True


def test_extra_protected_globs():
    cfg = RepoConfig.default()
    cfg.protected_paths = ["infra/**", "migrations/**"]
    assert extra_protected_globs(cfg) == ["infra/**", "migrations/**"]


def test_resolve_standard_packs_security():
    packs = resolve_standard_packs(["security"])
    assert packs and len(packs) == 1
    body = packs[0].lower()
    assert "secret" in body and "injection" in body


def test_resolve_standard_packs_unknown_ignored():
    assert resolve_standard_packs(["does-not-exist"]) == []


def test_standards_ref_cannot_escape_codebot_relative(tmp_path):
    # A secret file living OUTSIDE .codebot/ on the orchestrator host.
    (tmp_path / "secret.md").write_text("TOPSECRET-RELATIVE")
    root = _write_codebot(
        tmp_path,
        """
standards:
  ref: ["../secret.md"]
""",
    )
    cfg = load_repo_config(root)
    ctx = compiled_context(root, cfg)
    assert "TOPSECRET-RELATIVE" not in ctx


def test_standards_ref_rejects_absolute_path(tmp_path):
    secret = tmp_path / "abs_secret.md"
    secret.write_text("TOPSECRET-ABSOLUTE")
    root = _write_codebot(
        tmp_path,
        f"""
standards:
  ref: ["{secret.as_posix()}"]
""",
    )
    cfg = load_repo_config(root)
    ctx = compiled_context(root, cfg)
    assert "TOPSECRET-ABSOLUTE" not in ctx


def test_standards_ref_within_codebot_is_inlined(tmp_path):
    # A ref that stays inside .codebot/ (and is not under steering/ or memory/,
    # so it is only inlined via the ref path) must still work.
    root = _write_codebot(
        tmp_path,
        """
standards:
  ref: ["extra.md"]
""",
    )
    (root / ".codebot" / "extra.md").write_text("INLINE-OK-CONTENT")
    cfg = load_repo_config(root)
    ctx = compiled_context(root, cfg)
    assert "INLINE-OK-CONTENT" in ctx


def test_compiled_context_includes_everything(tmp_path):
    root = _write_codebot(
        tmp_path,
        """
goal: Keep the orders service secure.
review:
  focus: [security]
standards:
  packs: [security]
  rules: ["Parameterise all SQL."]
""",
    )
    steering = root / ".codebot" / "steering"
    steering.mkdir()
    (steering / "arch.md").write_text("Service uses SQLite.")
    memory = root / ".codebot" / "memory"
    memory.mkdir()
    (memory / "glossary.md").write_text("MR = merge request.")

    cfg = load_repo_config(root)
    ctx = compiled_context(root, cfg)

    assert "Keep the orders service secure." in ctx  # goal
    assert "security" in ctx.lower()  # focus + pack
    assert "Parameterise all SQL." in ctx  # repo rule
    assert "Service uses SQLite." in ctx  # steering body
    assert "MR = merge request." in ctx  # memory body
