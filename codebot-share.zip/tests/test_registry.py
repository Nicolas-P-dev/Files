from cryptography.fernet import Fernet

from orchestrator.registry import Registry


def _reg(tmp_path):
    return Registry(tmp_path / "codebot.db", Fernet.generate_key())


def test_register_and_get_roundtrip(tmp_path):
    reg = _reg(tmp_path)
    reg.register("123", "g/p", "glpat-secret", "whsecret")
    rec = reg.get("123")
    assert rec is not None
    assert rec.project_id == "123"
    assert rec.project_path == "g/p"
    assert rec.token == "glpat-secret"  # decrypted
    assert rec.webhook_secret == "whsecret"
    assert rec.status == "active"


def test_token_encrypted_at_rest(tmp_path):
    reg = _reg(tmp_path)
    reg.register("123", "g/p", "glpat-SUPER-SECRET", "wh")
    raw = (tmp_path / "codebot.db").read_bytes()
    assert b"glpat-SUPER-SECRET" not in raw  # never stored in plaintext


def test_get_missing_returns_none(tmp_path):
    assert _reg(tmp_path).get("nope") is None


def test_register_is_upsert(tmp_path):
    reg = _reg(tmp_path)
    reg.register("1", "g/p", "tok1", "wh1")
    reg.register("1", "g/p2", "tok2", "wh2")
    rec = reg.get("1")
    assert rec.project_path == "g/p2" and rec.token == "tok2" and rec.webhook_secret == "wh2"


def test_list_does_not_expose_token(tmp_path):
    reg = _reg(tmp_path)
    reg.register("1", "g/p", "tok", "wh")
    recs = reg.list()
    assert len(recs) == 1 and recs[0].project_id == "1" and recs[0].project_path == "g/p"
    assert recs[0].token != "tok"  # masked in the listing


def test_get_with_wrong_key_does_not_crash(tmp_path):
    # Onboard with one key, then reopen the same DB with a different key
    # (lost/rotated CODEBOT_ENC_KEY). get() must degrade, not 500.
    Registry(tmp_path / "c.db", Fernet.generate_key()).register("1", "g/p", "glpat-secret", "wh")
    reg2 = Registry(tmp_path / "c.db", Fernet.generate_key())
    rec = reg2.get("1")
    assert rec is not None
    assert rec.token == ""                 # token can't be decrypted
    assert rec.webhook_secret == "wh"      # plaintext secret still usable for auth
    assert rec.status == "needs_reonboard"


def test_set_status(tmp_path):
    reg = _reg(tmp_path)
    reg.register("1", "g/p", "tok", "wh")
    reg.set_status("1", "error")
    assert reg.get("1").status == "error"
