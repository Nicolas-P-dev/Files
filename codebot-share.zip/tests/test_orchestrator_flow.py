import subprocess
from pathlib import Path

from orchestrator.orchestrator import Orchestrator
from orchestrator.agents.base import CodingAgent
from orchestrator.agents.stub import StubAgent
from orchestrator.config import Settings
from orchestrator.models import AgentResult, Task, Intent
from tests.conftest import FakeGitLabClient, seed_to_remote, create_remote_branch


def _settings():
    return Settings(_env_file=None)


def _task(intent, **kw):
    base = dict(intent=intent, instruction="do it", project_id="1", default_branch="main")
    base.update(kw)
    return Task(**base)


def _pushed_tree(remote, branch):
    out = subprocess.run(
        ["git", "ls-tree", "-r", branch, "--name-only"], cwd=str(remote), capture_output=True, text=True
    )
    return out.stdout


class _TwoFileAgent(CodingAgent):
    def __init__(self, files):
        self.files = files

    def run(self, task, workspace):
        for name, content in self.files.items():
            p = Path(workspace) / name
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content)
        return AgentResult(changed=True, summary="wrote files")


# --- new-branch path (issue / standalone trigger) --------------------------

def test_feature_on_issue_creates_branch_and_draft_mr(bare_remote, tmp_path):
    gl = FakeGitLabClient()
    task = _task(Intent.FEATURE, instruction="add a /health endpoint",
                 repo_url=bare_remote.as_posix(), source_kind="issue", source_iid=3, discussion_id="d1")
    result = Orchestrator(_settings(), StubAgent(), gl, assignee_ids=[7]).run(task, workspace_dir=tmp_path / "ws")

    assert result.changed is True
    assert result.branch.startswith("codebot/feature-")
    assert "AGENT_NOTES.md" in _pushed_tree(bare_remote, result.branch)  # branch pushed
    assert gl.draft_mr["target_branch"] == "main"
    assert gl.draft_mr["assignee_ids"] == [7]
    assert gl.comments and gl.comments[-1]["iid"] == 3
    assert result.mr_url == "https://gitlab.example/mr/99"


# --- MR trigger reuses the MR's own branch (no second MR) ------------------

def test_fix_on_mr_pushes_to_mr_branch_and_opens_no_new_mr(bare_remote, tmp_path):
    src = "feature/login"
    create_remote_branch(bare_remote, tmp_path / "mk", src)
    gl = FakeGitLabClient()
    gl.mr_source_branch = src
    task = _task(Intent.FIX, instruction="fix the failing tests",
                 repo_url=bare_remote.as_posix(), source_kind="mr", source_iid=5, discussion_id="d1")

    result = Orchestrator(_settings(), StubAgent(), gl).run(task, workspace_dir=tmp_path / "ws")

    assert result.changed is True
    assert result.branch == src
    assert gl.draft_mr is None  # reused the MR's branch -> no new MR
    assert "AGENT_NOTES.md" in _pushed_tree(bare_remote, src)
    assert gl.comments and "branch" in gl.comments[-1]["body"].lower()


# --- compiled .codebot context reaches the agent but never the MR ----------

def test_codebot_context_excluded_from_mr(bare_remote, tmp_path):
    seed_to_remote(bare_remote, tmp_path / "seed2", {".codebot/config.yml": "goal: Be secure.\n"})
    gl = FakeGitLabClient()
    task = _task(Intent.FEATURE, instruction="add health", repo_url=bare_remote.as_posix(),
                 source_kind="issue", source_iid=1)
    ws = tmp_path / "ws"
    result = Orchestrator(_settings(), StubAgent(), gl).run(task, workspace_dir=ws)

    assert (ws / ".kiro" / "steering" / "zzz-codebot-context.md").exists()
    tree = _pushed_tree(bare_remote, result.branch)
    assert "AGENT_NOTES.md" in tree
    assert ".kiro/steering" not in tree


# --- config gates ----------------------------------------------------------

def test_disabled_repo_does_no_work(bare_remote, tmp_path):
    seed_to_remote(bare_remote, tmp_path / "seed2", {".codebot/config.yml": "enabled: false\n"})
    gl = FakeGitLabClient()
    task = _task(Intent.FIX, repo_url=bare_remote.as_posix(), source_kind="mr", source_iid=5)
    result = Orchestrator(_settings(), StubAgent(), gl).run(task, workspace_dir=tmp_path / "ws")

    assert result.changed is False
    assert gl.draft_mr is None
    assert gl.comments and "disabled" in gl.comments[-1]["body"].lower()


def test_disallowed_intent_declined(bare_remote, tmp_path):
    seed_to_remote(bare_remote, tmp_path / "seed2", {".codebot/config.yml": "intents:\n  allow: [review]\n"})
    gl = FakeGitLabClient()
    task = _task(Intent.FIX, repo_url=bare_remote.as_posix(), source_kind="issue", source_iid=2)
    result = Orchestrator(_settings(), StubAgent(), gl).run(task, workspace_dir=tmp_path / "ws")

    assert result.changed is False
    assert gl.draft_mr is None
    assert gl.comments and ("not permitted" in gl.comments[-1]["body"].lower()
                            or "not allowed" in gl.comments[-1]["body"].lower())


# --- repo-defined protected paths ------------------------------------------

def test_repo_protected_path_stripped(bare_remote, tmp_path):
    seed_to_remote(bare_remote, tmp_path / "seed2", {".codebot/config.yml": "protected_paths:\n  - secret.txt\n"})
    gl = FakeGitLabClient()
    agent = _TwoFileAgent({"secret.txt": "leak\n", "app.py": "# ok\n"})
    task = _task(Intent.IMPROVE, repo_url=bare_remote.as_posix(), source_kind="issue", source_iid=4)
    result = Orchestrator(_settings(), agent, gl).run(task, workspace_dir=tmp_path / "ws")

    tree = _pushed_tree(bare_remote, result.branch)
    assert "app.py" in tree
    assert "secret.txt" not in tree
    assert "secret.txt" in gl.draft_mr["description"]


# --- reviewers + labels ----------------------------------------------------

def test_reviewers_and_labels_applied(bare_remote, tmp_path):
    seed_to_remote(
        bare_remote, tmp_path / "seed2",
        {".codebot/config.yml": "review:\n  reviewers: [alice]\n  labels: [codebot, automated]\n"},
    )
    gl = FakeGitLabClient()
    gl.user_id_map = {"alice": 101}
    task = _task(Intent.FEATURE, repo_url=bare_remote.as_posix(), source_kind="issue", source_iid=6)
    Orchestrator(_settings(), StubAgent(), gl, assignee_ids=[7]).run(task, workspace_dir=tmp_path / "ws")

    assert gl.draft_mr["assignee_ids"] == [101]  # configured reviewer wins over default
    assert gl.draft_mr["labels"] == ["codebot", "automated"]


# --- safety cap ------------------------------------------------------------

def test_max_changed_files_cap_blocks_mr(bare_remote, tmp_path):
    seed_to_remote(bare_remote, tmp_path / "seed2", {".codebot/config.yml": "safety:\n  max_changed_files: 0\n"})
    gl = FakeGitLabClient()
    task = _task(Intent.FIX, repo_url=bare_remote.as_posix(), source_kind="issue", source_iid=7)
    result = Orchestrator(_settings(), StubAgent(), gl).run(task, workspace_dir=tmp_path / "ws")

    assert result.changed is False
    assert gl.draft_mr is None
    assert gl.comments and ("too many" in gl.comments[-1]["body"].lower()
                            or "limit" in gl.comments[-1]["body"].lower())


# --- review intent (unchanged behavior) ------------------------------------

def test_init_opens_mr_adding_codebot_config(bare_remote, tmp_path):
    gl = FakeGitLabClient()
    task = _task(Intent.INIT, instruction="init", repo_url=bare_remote.as_posix(),
                 source_kind="issue", source_iid=1)
    result = Orchestrator(_settings(), StubAgent(), gl).run(task, workspace_dir=tmp_path / "ws")

    assert result.changed is True
    assert ".codebot/config.yml" in _pushed_tree(bare_remote, result.branch)
    assert gl.draft_mr is not None
    # the stub agent is bypassed for init — no AGENT_NOTES
    assert "AGENT_NOTES.md" not in _pushed_tree(bare_remote, result.branch)


def test_init_on_already_configured_repo_is_noop(bare_remote, tmp_path):
    seed_to_remote(bare_remote, tmp_path / "seed2", {".codebot/config.yml": "enabled: true\n"})
    gl = FakeGitLabClient()
    task = _task(Intent.INIT, instruction="init", repo_url=bare_remote.as_posix(),
                 source_kind="issue", source_iid=2)
    result = Orchestrator(_settings(), StubAgent(), gl).run(task, workspace_dir=tmp_path / "ws")

    assert result.changed is False
    assert gl.draft_mr is None
    assert gl.comments and "already configured" in gl.comments[-1]["body"].lower()


def test_audit_on_mr_reads_diff_and_lists_changed_files(bare_remote, tmp_path):
    gl = FakeGitLabClient()
    gl.mr_changes = [{"new_path": "app.py"}, {"new_path": "test_app.py"}]
    task = _task(Intent.AUDIT, instruction="audit this MR", repo_url=bare_remote.as_posix(),
                 source_kind="mr", source_iid=5)
    Orchestrator(_settings(), StubAgent(), gl).run(task, workspace_dir=tmp_path / "ws")

    assert gl.get_mr_changes_called == 5
    body = gl.comments[0]["body"]
    assert "app.py" in body and "test_app.py" in body


def test_audit_posts_comment_and_opens_no_mr(bare_remote, tmp_path):
    gl = FakeGitLabClient()
    task = _task(Intent.AUDIT, instruction="audit this", repo_url=bare_remote.as_posix(),
                 source_kind="mr", source_iid=8)
    result = Orchestrator(_settings(), StubAgent(), gl).run(task, workspace_dir=tmp_path / "ws")

    assert result.changed is False
    assert gl.draft_mr is None
    assert gl.comments and "review" in gl.comments[0]["body"].lower()
