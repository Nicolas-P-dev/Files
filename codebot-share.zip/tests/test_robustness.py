"""Tests for the robustness/reliability fixes from the code review."""

import os
import tempfile
from pathlib import Path

import pytest

import orchestrator.orchestrator as omod
from orchestrator.orchestrator import Orchestrator
from orchestrator.agents.base import CodingAgent
from orchestrator.agents.stub import StubAgent
from orchestrator.config import Settings
from orchestrator.git_repo import _redact
from orchestrator.models import AgentResult, Task, Intent


def _settings():
    return Settings(_env_file=None)


def _task(**kw):
    base = dict(intent=Intent.FIX, instruction="do it", project_id="1", default_branch="main")
    base.update(kw)
    return Task(**base)


class BoomAgent(CodingAgent):
    def run(self, task, workspace):
        raise RuntimeError("boom")


class NoAssumeAgent(CodingAgent):
    def run(self, task, workspace):
        (Path(workspace) / "x.txt").write_text("hi\n")
        return AgentResult(changed=True, summary="did x")  # assumptions defaults to []


# --- temp workspace cleanup ------------------------------------------------

def test_orchestrator_removes_temp_workspace_it_created(bare_remote, monkeypatch):
    created = {}
    real = tempfile.mkdtemp

    def spy(*a, **k):
        d = real(*a, **k)
        created["dir"] = d
        return d

    monkeypatch.setattr(omod.tempfile, "mkdtemp", spy)
    orch = Orchestrator(_settings(), StubAgent(), _fake_gitlab())
    orch.run(_task(repo_url=bare_remote.as_posix()))  # no workspace_dir -> orchestrator owns temp dir

    assert created["dir"]
    assert not os.path.exists(created["dir"])  # cleaned up


def test_orchestrator_keeps_caller_provided_workspace(bare_remote, tmp_path):
    ws = tmp_path / "ws"
    Orchestrator(_settings(), StubAgent(), _fake_gitlab()).run(
        _task(repo_url=bare_remote.as_posix()), workspace_dir=ws
    )
    assert ws.exists()  # caller owns it -> not deleted


# --- failure handling ------------------------------------------------------

def test_failure_posts_comment_cleans_up_and_reraises(bare_remote, monkeypatch):
    created = {}
    real = tempfile.mkdtemp
    monkeypatch.setattr(omod.tempfile, "mkdtemp", lambda *a, **k: created.setdefault("dir", real(*a, **k)))

    gl = _fake_gitlab()
    orch = Orchestrator(_settings(), BoomAgent(), gl)
    task = _task(repo_url=bare_remote.as_posix(), source_kind="issue", source_iid=9, discussion_id="d1")

    with pytest.raises(RuntimeError):
        orch.run(task)

    # the requester is told it failed, on the originating thread
    assert gl.comments and gl.comments[-1]["kind"] == "issue" and gl.comments[-1]["iid"] == 9
    assert "fail" in gl.comments[-1]["body"].lower() or "error" in gl.comments[-1]["body"].lower()
    # and the temp workspace is not leaked
    assert not os.path.exists(created["dir"])


# --- assumptions always documented (matters for the kiro backend) ----------

def test_mr_description_always_has_assumptions_section(bare_remote, tmp_path):
    gl = _fake_gitlab()
    orch = Orchestrator(_settings(), NoAssumeAgent(), gl)
    orch.run(_task(repo_url=bare_remote.as_posix(), source_kind="issue", source_iid=1), workspace_dir=tmp_path / "ws")
    assert "## Assumptions" in gl.draft_mr["description"]


# --- credential redaction in git errors ------------------------------------

def test_redact_strips_userinfo_from_urls():
    s = "fatal: unable to access 'https://oauth2:glpat-SECRET@gitlab.com/x.git': 403"
    out = _redact(s)
    assert "glpat-SECRET" not in out
    assert "gitlab.com/x.git" in out  # non-secret part preserved


def _fake_gitlab():
    from tests.conftest import FakeGitLabClient

    return FakeGitLabClient()
