from orchestrator.config import Settings


def test_settings_load_from_env(monkeypatch):
    monkeypatch.setenv("GITLAB_PROJECT", "g/p")
    monkeypatch.setenv("GITLAB_PROJECT_ID", "123")
    monkeypatch.setenv("GITLAB_TOKEN", "glpat-x")
    s = Settings(_env_file=None)
    assert s.gitlab_project == "g/p"
    assert s.gitlab_project_id == "123"
    assert s.gitlab_token == "glpat-x"
    # defaults
    assert s.agent_backend == "stub"
    assert s.gitlab_url == "https://gitlab.com"
    assert s.gitlab_default_branch == "main"
    assert s.bot_mention == "@codebot"
    assert s.langfuse_base_url == "https://cloud.langfuse.com"


def test_settings_case_insensitive_and_extra_ignored(monkeypatch):
    monkeypatch.setenv("GITLAB_PROJECT", "g/p")
    monkeypatch.setenv("GITLAB_PROJECT_ID", "1")
    monkeypatch.setenv("GITLAB_TOKEN", "t")
    monkeypatch.setenv("SOME_UNRELATED_VAR", "ignored")
    monkeypatch.setenv("AGENT_BACKEND", "kiro")
    s = Settings(_env_file=None)
    assert s.agent_backend == "kiro"
