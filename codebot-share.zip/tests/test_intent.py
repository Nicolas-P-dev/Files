import pytest

from orchestrator.intent import parse_intent
from orchestrator.models import Intent


@pytest.mark.parametrize(
    "text,expected",
    [
        ("@codebot review", Intent.REVIEW),
        ("@codebot review this MR please", Intent.REVIEW),
        ("@codebot please review the diff", Intent.REVIEW),
        ("@codebot fix the failing tests", Intent.FIX),
        ("@codebot fix this bug", Intent.FIX),
        ("@codebot improve error handling here", Intent.IMPROVE),
        ("@codebot refactor this function", Intent.IMPROVE),
        ("@codebot add a /health endpoint", Intent.FEATURE),
        ("@codebot implement pagination", Intent.FEATURE),
        ("@codebot create a new endpoint", Intent.FEATURE),
        ("@codebot do a barrel roll", Intent.UNKNOWN),
        ("", Intent.UNKNOWN),
    ],
)
def test_parse_intent(text, expected):
    assert parse_intent(text) == expected


def test_review_takes_precedence_over_other_keywords():
    # "review" wins even if other action words appear
    assert parse_intent("@codebot review and fix if needed") == Intent.REVIEW


def test_parse_init_intent():
    assert parse_intent("@codebot init") == Intent.INIT
    assert parse_intent("@codebot onboard this repo") == Intent.INIT


def test_parse_audit_intent():
    assert parse_intent("@codebot audit") == Intent.AUDIT
    assert parse_intent("@codebot review") == Intent.REVIEW  # still distinct
