from orchestrator.webhook import build_task_from_note
from orchestrator.models import Intent


def mr_note(note, author="alice"):
    return {
        "object_kind": "note",
        "event_type": "note",
        "user": {"username": author},
        "project": {
            "id": 83447596,
            "path_with_namespace": "poc-agent/poc-agent-sandbox",
            "default_branch": "main",
            "git_http_url": "https://gitlab.com/poc-agent/poc-agent-sandbox.git",
        },
        "object_attributes": {
            "note": note,
            "noteable_type": "MergeRequest",
            "discussion_id": "disc123",
        },
        "merge_request": {"iid": 7},
    }


def issue_note(note, author="alice"):
    p = mr_note(note, author)
    p["object_attributes"]["noteable_type"] = "Issue"
    del p["merge_request"]
    p["issue"] = {"iid": 3}
    return p


BOT = "@codebot"
BOTUSER = "01082002nic"


def test_mr_mention_builds_fix_task():
    t = build_task_from_note(mr_note("@codebot fix the failing tests"), bot_mention=BOT, bot_username=BOTUSER)
    assert t is not None
    assert t.intent == Intent.FIX
    assert t.source_kind == "mr"
    assert t.source_iid == 7
    assert t.discussion_id == "disc123"
    assert t.author == "alice"
    assert t.project_id == "83447596"
    assert t.repo_url == "https://gitlab.com/poc-agent/poc-agent-sandbox.git"
    assert t.default_branch == "main"
    assert "fix the failing tests" in t.instruction
    assert BOT not in t.instruction  # mention stripped


def test_issue_mention_builds_feature_task():
    t = build_task_from_note(issue_note("@codebot add a /health endpoint"), bot_mention=BOT, bot_username=BOTUSER)
    assert t.intent == Intent.FEATURE
    assert t.source_kind == "issue"
    assert t.source_iid == 3


def test_note_without_mention_is_ignored():
    assert build_task_from_note(mr_note("just a normal comment"), bot_mention=BOT, bot_username=BOTUSER) is None


def test_note_authored_by_bot_is_ignored():
    # loop prevention: the bot's own replies must not re-trigger it
    assert build_task_from_note(mr_note("@codebot fix", author=BOTUSER), bot_mention=BOT, bot_username=BOTUSER) is None


def test_non_note_event_is_ignored():
    assert build_task_from_note({"object_kind": "push"}, bot_mention=BOT, bot_username=BOTUSER) is None


def test_unsupported_noteable_type_is_ignored():
    p = mr_note("@codebot review")
    p["object_attributes"]["noteable_type"] = "Commit"
    assert build_task_from_note(p, bot_mention=BOT, bot_username=BOTUSER) is None


def mr_event(action="open", author="alice"):
    return {
        "object_kind": "merge_request",
        "user": {"username": author},
        "project": {
            "id": 83447596,
            "default_branch": "main",
            "git_http_url": "https://gitlab.com/poc-agent/poc-agent-sandbox.git",
        },
        "object_attributes": {"action": action, "iid": 12},
    }


def test_mr_open_event_builds_auto_audit_task():
    from orchestrator.webhook import build_task_from_mr_event

    t = build_task_from_mr_event(mr_event("open"), bot_username=BOTUSER, allowed_host="gitlab.com")
    assert t is not None
    assert t.intent == Intent.AUDIT and t.source_kind == "mr" and t.source_iid == 12
    assert t.auto is True


def test_mr_update_event_ignored():
    from orchestrator.webhook import build_task_from_mr_event

    assert build_task_from_mr_event(mr_event("update"), bot_username=BOTUSER, allowed_host="gitlab.com") is None


def test_mr_event_by_bot_is_ignored():
    from orchestrator.webhook import build_task_from_mr_event

    assert build_task_from_mr_event(mr_event("open", author=BOTUSER), bot_username=BOTUSER, allowed_host="gitlab.com") is None


def test_mr_event_foreign_host_ignored():
    from orchestrator.webhook import build_task_from_mr_event

    p = mr_event("open")
    p["project"]["git_http_url"] = "https://attacker.example/x.git"
    assert build_task_from_mr_event(p, bot_username=BOTUSER, allowed_host="gitlab.com") is None
