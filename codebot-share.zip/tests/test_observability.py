import base64

from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from orchestrator.config import Settings
from orchestrator.observability import (
    build_tracer_provider,
    get_tracer,
    langfuse_auth_header,
    langfuse_otlp_endpoint,
)


def test_langfuse_otlp_endpoint():
    s = Settings(_env_file=None, langfuse_base_url="https://cloud.langfuse.com")
    assert (
        langfuse_otlp_endpoint(s) == "https://cloud.langfuse.com/api/public/otel/v1/traces"
    )


def test_langfuse_auth_header_is_basic_base64():
    s = Settings(_env_file=None, langfuse_public_key="pk", langfuse_secret_key="sk")
    assert langfuse_auth_header(s) == "Basic " + base64.b64encode(b"pk:sk").decode()


def test_build_provider_with_in_memory_exporter_records_spans():
    s = Settings(_env_file=None)
    exporter = InMemorySpanExporter()
    provider = build_tracer_provider(s, exporter=exporter)
    tracer = get_tracer(provider)

    with tracer.start_as_current_span("hello"):
        pass
    provider.force_flush()

    assert [sp.name for sp in exporter.get_finished_spans()] == ["hello"]


def test_resource_has_service_name():
    s = Settings(_env_file=None, otel_service_name="gitlab-code-assistant")
    exporter = InMemorySpanExporter()
    provider = build_tracer_provider(s, exporter=exporter)
    with get_tracer(provider).start_as_current_span("x"):
        pass
    provider.force_flush()
    sp = exporter.get_finished_spans()[0]
    assert sp.resource.attributes.get("service.name") == "gitlab-code-assistant"
