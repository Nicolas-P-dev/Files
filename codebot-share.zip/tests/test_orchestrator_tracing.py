from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter

from orchestrator.config import Settings
from orchestrator.observability import build_tracer_provider, get_tracer
from orchestrator.orchestrator import Orchestrator
from orchestrator.agents.stub import StubAgent
from orchestrator.models import Task, Intent


def _traced_orchestrator(agent, gl):
    s = Settings(_env_file=None)
    exporter = InMemorySpanExporter()
    provider = build_tracer_provider(s, exporter=exporter)
    tracer = get_tracer(provider)
    orch = Orchestrator(s, agent, gl, tracer=tracer)
    return orch, exporter, provider


def test_fix_run_emits_span_tree(bare_remote, tmp_path, fake_gitlab):
    task = Task(
        intent=Intent.FIX,
        instruction="fix it",
        project_id="1",
        repo_url=bare_remote.as_posix(),
        default_branch="main",
        source_kind="issue",
        source_iid=3,
    )
    orch, exporter, provider = _traced_orchestrator(StubAgent(), fake_gitlab)

    orch.run(task, workspace_dir=tmp_path / "ws")
    provider.force_flush()

    spans = {sp.name: sp for sp in exporter.get_finished_spans()}
    assert "task.received" in spans
    assert "workspace.prepared" in spans
    assert "agent.invoke" in spans
    assert "gitlab.create_mr" in spans
    assert "gitlab.comment" in spans

    assert spans["agent.invoke"].attributes.get("agent.backend") == "stub"
    assert spans["agent.invoke"].attributes.get("agent.changed") is True
    assert spans["task.received"].attributes.get("intent") == "fix"
    assert spans["task.received"].attributes.get("outcome") == "changed"


def test_review_run_has_no_create_mr_span(bare_remote, tmp_path, fake_gitlab):
    task = Task(
        intent=Intent.AUDIT,
        instruction="audit this",
        project_id="1",
        repo_url=bare_remote.as_posix(),
        default_branch="main",
        source_kind="mr",
        source_iid=4,
    )
    orch, exporter, provider = _traced_orchestrator(StubAgent(), fake_gitlab)

    orch.run(task, workspace_dir=tmp_path / "ws")
    provider.force_flush()

    names = {sp.name for sp in exporter.get_finished_spans()}
    assert "agent.invoke" in names
    assert "gitlab.create_mr" not in names
    assert "gitlab.comment" in names
