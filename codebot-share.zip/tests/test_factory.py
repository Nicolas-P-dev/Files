import pytest

from orchestrator.agents.factory import make_agent
from orchestrator.agents.stub import StubAgent
from orchestrator.agents.kiro import KiroAgent


def test_factory_returns_stub():
    assert isinstance(make_agent("stub"), StubAgent)


def test_factory_returns_kiro():
    assert isinstance(make_agent("kiro"), KiroAgent)


def test_factory_unknown_raises():
    with pytest.raises(ValueError):
        make_agent("nope")
