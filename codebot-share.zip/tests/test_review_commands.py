from pathlib import Path
import subprocess

from orchestrator.orchestrator import Orchestrator
from orchestrator.agents.base import CodingAgent
from orchestrator.agents.stub import StubAgent
from orchestrator.config import Settings
from orchestrator.models import AgentResult, Task, Intent
from tests.conftest import FakeGitLabClient, seed_to_remote, create_remote_branch


def _settings():
    return Settings(_env_file=None)


def _task(intent, **kw):
    base = dict(intent=intent, instruction="do it", project_id="1", default_branch="main")
    base.update(kw)
    return Task(**base)


def _tree(remote, branch):
    return subprocess.run(["git", "ls-tree", "-r", branch, "--name-only"],
                          cwd=str(remote), capture_output=True, text=True).stdout


class _ReviewFixAgent(CodingAgent):
    """An agent that applies a fix while reviewing (what Kiro might do)."""

    def run(self, task, workspace):
        (Path(workspace) / "app.py").write_text("# fixed by review\n")
        return AgentResult(changed=True, summary="reviewed and applied a confident fix")


class _SummaryOnlyAgent(CodingAgent):
    """A Kiro-shaped agent: reports findings in summary, never sets review_comments."""

    def run(self, task, workspace):
        return AgentResult(
            changed=False,
            summary="[high] SQL injection in users.py\n[medium] Hardcoded secret in config.py",
        )


def test_audit_surfaces_agent_summary_findings_in_comment(bare_remote, tmp_path):
    # Real Kiro reports findings on stdout (-> AgentResult.summary), not as
    # structured review_comments. The review reply must surface them, not claim
    # "No issues found."
    gl = FakeGitLabClient()
    task = _task(Intent.AUDIT, instruction="audit", repo_url=bare_remote.as_posix(),
                 source_kind="mr", source_iid=5)
    Orchestrator(_settings(), _SummaryOnlyAgent(), gl).run(task, workspace_dir=tmp_path / "ws")
    body = " ".join(c["body"] for c in gl.comments)
    assert "SQL injection" in body
    assert "No issues found" not in body


def test_is_mutating_is_an_explicit_whitelist():
    from orchestrator.repo_config import RepoConfig

    orch = Orchestrator(_settings(), StubAgent(), FakeGitLabClient())
    cfg = RepoConfig.default()
    # Only fix/improve/feature mutate. UNKNOWN must never fall through to mutating.
    assert orch._is_mutating(_task(Intent.UNKNOWN, repo_url=""), cfg) is False
    assert orch._is_mutating(_task(Intent.AUDIT, repo_url=""), cfg) is False
    assert orch._is_mutating(_task(Intent.FIX, repo_url=""), cfg) is True
    assert orch._is_mutating(_task(Intent.IMPROVE, repo_url=""), cfg) is True
    assert orch._is_mutating(_task(Intent.FEATURE, repo_url=""), cfg) is True


def test_review_applies_confident_fixes_to_mr_branch(bare_remote, tmp_path):
    src = "feature/login"
    create_remote_branch(bare_remote, tmp_path / "mk", src)
    gl = FakeGitLabClient()
    gl.mr_source_branch = src
    task = _task(Intent.REVIEW, repo_url=bare_remote.as_posix(), source_kind="mr", source_iid=5, discussion_id="d1")

    result = Orchestrator(_settings(), _ReviewFixAgent(), gl).run(task, workspace_dir=tmp_path / "ws")

    assert result.changed is True
    assert result.branch == src  # pushed to the MR's own branch
    assert gl.draft_mr is None  # no second MR
    assert "app.py" in _tree(bare_remote, src)


def test_audit_never_pushes_even_if_agent_changes(bare_remote, tmp_path):
    src = "feature/login"
    create_remote_branch(bare_remote, tmp_path / "mk", src)
    gl = FakeGitLabClient()
    gl.mr_source_branch = src
    task = _task(Intent.AUDIT, instruction="audit", repo_url=bare_remote.as_posix(),
                 source_kind="mr", source_iid=5)

    Orchestrator(_settings(), _ReviewFixAgent(), gl).run(task, workspace_dir=tmp_path / "ws")

    assert gl.draft_mr is None
    assert "app.py" not in _tree(bare_remote, src)  # read-only: fix not pushed
    assert gl.comments  # but it still comments


def test_auto_review_is_silent_noop_when_not_enabled(bare_remote, tmp_path):
    gl = FakeGitLabClient()
    task = _task(Intent.AUDIT, repo_url=bare_remote.as_posix(), source_kind="mr", source_iid=5, auto=True)
    result = Orchestrator(_settings(), _ReviewFixAgent(), gl).run(task, workspace_dir=tmp_path / "ws")
    assert result.changed is False
    assert gl.comments == []  # silent — no noise on repos that didn't opt in
    assert gl.draft_mr is None


def test_auto_review_runs_when_enabled(bare_remote, tmp_path):
    seed_to_remote(bare_remote, tmp_path / "seed2", {".codebot/config.yml": "triggers:\n  review_on_open: true\n"})
    gl = FakeGitLabClient()
    gl.mr_changes = [{"new_path": "app.py"}]
    task = _task(Intent.AUDIT, instruction="auto review", repo_url=bare_remote.as_posix(),
                 source_kind="mr", source_iid=5, auto=True)
    Orchestrator(_settings(), StubAgent(), gl).run(task, workspace_dir=tmp_path / "ws")
    assert gl.comments  # posts the auto review
    assert gl.draft_mr is None  # read-only


def test_review_apply_fixes_false_is_read_only(bare_remote, tmp_path):
    seed_to_remote(bare_remote, tmp_path / "seed2", {".codebot/config.yml": "review:\n  apply_fixes: false\n"})
    src = "feature/ro"
    create_remote_branch(bare_remote, tmp_path / "mk", src)
    gl = FakeGitLabClient()
    gl.mr_source_branch = src
    task = _task(Intent.REVIEW, repo_url=bare_remote.as_posix(), source_kind="mr", source_iid=5)

    Orchestrator(_settings(), _ReviewFixAgent(), gl).run(task, workspace_dir=tmp_path / "ws")

    assert gl.draft_mr is None
    assert "app.py" not in _tree(bare_remote, src)  # apply_fixes:false -> nothing pushed
