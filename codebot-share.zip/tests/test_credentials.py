from cryptography.fernet import Fernet

from orchestrator.config import Settings
from orchestrator.credentials import secret_for, token_for
from orchestrator.registry import Registry


def _settings():
    return Settings(_env_file=None, gitlab_token="ENV-TOKEN", webhook_secret="ENV-SECRET")


def _reg(tmp_path):
    return Registry(tmp_path / "r.db", Fernet.generate_key())


def test_token_for_falls_back_to_env_without_registry():
    assert token_for("1", _settings(), None) == "ENV-TOKEN"


def test_token_for_uses_registry_when_registered(tmp_path):
    reg = _reg(tmp_path)
    reg.register("1", "g/p", "REPO-TOKEN", "wh")
    assert token_for("1", _settings(), reg) == "REPO-TOKEN"


def test_token_for_falls_back_when_project_not_registered(tmp_path):
    assert token_for("999", _settings(), _reg(tmp_path)) == "ENV-TOKEN"


def test_secret_for_registry_then_env(tmp_path):
    reg = _reg(tmp_path)
    reg.register("1", "g/p", "tok", "REPO-SECRET")
    assert secret_for("1", _settings(), reg) == "REPO-SECRET"
    assert secret_for("2", _settings(), reg) == "ENV-SECRET"
