import pytest

from orchestrator.agents.kiro import KiroAgent
from orchestrator.models import Task, Intent


def _task():
    return Task(intent=Intent.FIX, instruction="fix the failing tests", project_id="1", repo_url="u")


def test_build_command_is_headless_and_trusts_tools():
    cmd = KiroAgent(api_key="k").build_command("PROMPT")
    assert cmd[0] == "kiro-cli"
    assert "chat" in cmd
    assert "--no-interactive" in cmd
    # the trust-tools names match the real CLI (kiro-cli 2.x help example: fs_read,fs_write)
    trust = next(c for c in cmd if c.startswith("--trust-tools="))
    assert "fs_read" in trust and "fs_write" in trust
    assert cmd[-1] == "PROMPT"


def test_build_prompt_includes_instruction_and_steering_reminder():
    prompt = KiroAgent(api_key="k").build_prompt(_task())
    assert "fix the failing tests" in prompt
    # the prompt must point the runtime agent at its steering disciplines
    assert "steering" in prompt.lower() or ".kiro" in prompt.lower()


def test_run_raises_clear_error_when_cli_missing(tmp_path):
    # No KIRO_API_KEY required to attempt a run (session auth is also valid);
    # but a missing CLI must produce a clear, actionable error.
    agent = KiroAgent(api_key="", binary="kiro-cli-definitely-not-installed-xyz")
    with pytest.raises(RuntimeError, match="not found on PATH"):
        agent.run(_task(), tmp_path)


def test_configure_sets_model_and_effort(tmp_path):
    from orchestrator.repo_config import AgentTuning

    a = KiroAgent(api_key="k")
    a.configure(AgentTuning(model="claude-opus", effort="high", trust_tools=["fs_read", "fs_write"]))
    cmd = a.build_command("PROMPT")
    assert "--model" in cmd and "claude-opus" in cmd
    assert "--effort" in cmd and "high" in cmd
    trust = next(c for c in cmd if c.startswith("--trust-tools="))
    assert "fs_read" in trust and "fs_write" in trust


def test_configure_does_not_clobber_with_empty(tmp_path):
    from orchestrator.repo_config import AgentTuning

    a = KiroAgent(api_key="k", model="preset-model")
    a.configure(AgentTuning())  # nothing set
    assert "preset-model" in a.build_command("P")


def test_stub_configure_is_noop():
    from orchestrator.agents.stub import StubAgent
    from orchestrator.repo_config import AgentTuning

    StubAgent().configure(AgentTuning(model="x"))  # must not raise


def test_run_raises_on_authentication_failure_marker(tmp_path, monkeypatch):
    # kiro-cli exits 0 on auth failure; on a read-only intent there are no workspace
    # changes to signal failure, so a silent auth failure would look like a clean run.
    # Detect it from the CLI's own output and fail loudly. Audit finding #2.
    import orchestrator.agents.kiro as kmod

    class _Proc:
        stdout = "Authentication failed. Your API key may be invalid or expired."
        stderr = ""
        returncode = 0

    monkeypatch.setattr(kmod.subprocess, "run", lambda *a, **k: _Proc())
    with pytest.raises(RuntimeError, match="authentic"):
        KiroAgent(api_key="ksk_bad").run(_task(), tmp_path)


def test_run_raises_on_nonzero_exit(tmp_path, monkeypatch):
    # A non-zero exit is a genuine crash/bad-args — never land a partial change. #4
    import orchestrator.agents.kiro as kmod

    class _Proc:
        stdout = "did some partial work"
        stderr = "kiro-cli: fatal: boom"
        returncode = 2

    monkeypatch.setattr(kmod.subprocess, "run", lambda *a, **k: _Proc())
    with pytest.raises(RuntimeError, match="exit 2"):
        KiroAgent(api_key="ksk_x").run(_task(), tmp_path)


def test_run_timeout_raises_clear_error(tmp_path, monkeypatch):
    # An unauthenticated kiro-cli hangs on SSO login; a timeout must surface clearly.
    import subprocess

    import orchestrator.agents.kiro as kmod

    def _timeout(*a, **k):
        raise subprocess.TimeoutExpired(cmd="kiro-cli", timeout=k.get("timeout", 1))

    monkeypatch.setattr(kmod.subprocess, "run", _timeout)
    with pytest.raises(RuntimeError, match="timed out"):
        KiroAgent(api_key="k", timeout=1).run(_task(), tmp_path)
