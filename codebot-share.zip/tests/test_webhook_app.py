from fastapi.testclient import TestClient

from orchestrator.config import Settings
from orchestrator.webhook import create_app
from tests.test_webhook_parse import mr_note


def _settings():
    return Settings(
        _env_file=None,
        webhook_secret="topsecret",
        bot_mention="@codebot",
        bot_username="01082002nic",
        gitlab_project="poc-agent/poc-agent-sandbox",
        gitlab_project_id="83447596",
    )


class RecordingOrchestrator:
    runs = []

    def run(self, task, **kw):
        RecordingOrchestrator.runs.append(task)
        return None


def _client():
    RecordingOrchestrator.runs = []
    app = create_app(settings=_settings(), orchestrator_factory=lambda task: RecordingOrchestrator())
    return TestClient(app)


def test_rejects_wrong_secret():
    r = _client().post("/webhook", json=mr_note("@codebot fix it"), headers={"X-Gitlab-Token": "wrong"})
    assert r.status_code == 401
    assert RecordingOrchestrator.runs == []


def test_accepts_and_routes_fix():
    c = _client()
    r = c.post("/webhook", json=mr_note("@codebot fix the failing tests"), headers={"X-Gitlab-Token": "topsecret"})
    assert r.status_code == 200
    assert r.json()["status"] == "accepted"
    assert r.json()["intent"] == "fix"
    # background task ran -> orchestrator received the task
    assert len(RecordingOrchestrator.runs) == 1
    assert RecordingOrchestrator.runs[0].source_iid == 7


def test_ignores_non_mention():
    c = _client()
    r = c.post("/webhook", json=mr_note("nothing to see"), headers={"X-Gitlab-Token": "topsecret"})
    assert r.status_code == 200
    assert r.json()["status"] == "ignored"
    assert RecordingOrchestrator.runs == []


def test_ignores_non_note_event():
    c = _client()
    r = c.post("/webhook", json={"object_kind": "push"}, headers={"X-Gitlab-Token": "topsecret"})
    assert r.status_code == 200
    assert r.json()["status"] == "ignored"
    assert RecordingOrchestrator.runs == []


def test_healthz():
    assert _client().get("/healthz").json() == {"status": "ok"}


def test_default_factory_wires_token_agent_and_orchestrator(monkeypatch):
    # The other tests inject a fake factory; this exercises the REAL default_factory:
    # webhook -> token_for -> make_agent -> GitLabClient.from_settings -> Orchestrator -> run.
    # Audit finding #5 (no integration test of this wiring).
    import orchestrator.webhook as wh

    captured = {}

    class _FakeGL:
        def current_user_id(self):
            return 42

    def _fake_from_settings(settings, project_id=None, token=None):
        captured["fs_token"] = token
        return _FakeGL()

    class _StubAgent:
        def run(self, task, workspace):
            return None

        def configure(self, cfg):
            return None

    def _fake_make_agent(backend, kiro_api_key=""):
        captured["backend"] = backend
        return _StubAgent()

    def _record_run(self, task, **kw):
        captured["task"] = task
        captured["assignee_ids"] = self.assignee_ids
        captured["gitlab_token"] = self.gitlab_token
        return None

    monkeypatch.setattr(wh.GitLabClient, "from_settings", staticmethod(_fake_from_settings))
    monkeypatch.setattr(wh, "make_agent", _fake_make_agent)
    monkeypatch.setattr(wh.Orchestrator, "run", _record_run)

    settings = Settings(
        _env_file=None, webhook_secret="topsecret", bot_mention="@codebot",
        bot_username="01082002nic", gitlab_url="https://gitlab.com", gitlab_token="glpat-envtoken",
    )
    app = create_app(settings=settings)  # no injected factory -> real default_factory
    r = TestClient(app).post(
        "/webhook", json=mr_note("@codebot fix it"), headers={"X-Gitlab-Token": "topsecret"},
    )

    assert r.status_code == 200 and r.json()["status"] == "accepted"
    assert captured["task"].source_iid == 7            # parsed task reached run()
    assert captured["fs_token"] == "glpat-envtoken"    # token_for resolved the env token
    assert captured["gitlab_token"] == "glpat-envtoken"
    assert captured["backend"] == settings.agent_backend
    assert captured["assignee_ids"] == [42]            # current_user_id -> default assignee
