"""Tests for the security fixes from the code review."""

from pathlib import Path

from fastapi.testclient import TestClient

from orchestrator.agents.base import CodingAgent
from orchestrator.config import Settings
from orchestrator.models import AgentResult, Intent, Task
from orchestrator.orchestrator import Orchestrator
from orchestrator.redact import redact
from orchestrator.webhook import create_app, build_task_from_note
from orchestrator.workspace import authenticated_url
from tests.conftest import FakeGitLabClient
from tests.test_webhook_parse import mr_note


# --- token injection is host-gated (no credential leak to foreign hosts) ---

def test_authenticated_url_injects_only_for_allowed_host():
    url = "https://gitlab.com/g/p.git"
    assert authenticated_url(url, "TOK", allowed_host="gitlab.com") == "https://oauth2:TOK@gitlab.com/g/p.git"


def test_authenticated_url_refuses_token_for_foreign_host():
    url = "https://attacker.example/p.git"
    # must NOT embed the token in a URL pointing at an unconfigured host
    assert "TOK" not in authenticated_url(url, "TOK", allowed_host="gitlab.com")
    assert authenticated_url(url, "TOK", allowed_host="gitlab.com") == url


# --- webhook rejects notes whose repo host is not the configured GitLab ---

def test_build_task_rejects_foreign_repo_host():
    p = mr_note("@codebot fix")
    p["project"]["git_http_url"] = "https://attacker.example/evil.git"
    assert build_task_from_note(p, bot_mention="@codebot", bot_username="bot", allowed_host="gitlab.com") is None


def test_build_task_allows_configured_repo_host():
    p = mr_note("@codebot fix")  # git_http_url host is gitlab.com
    assert build_task_from_note(p, bot_mention="@codebot", bot_username="bot", allowed_host="gitlab.com") is not None


# --- empty webhook secret fails closed (no auth bypass) ---

def test_empty_webhook_secret_rejects_all_requests():
    settings = Settings(_env_file=None, webhook_secret="", gitlab_url="https://gitlab.com")
    app = create_app(settings=settings, orchestrator_factory=lambda task: None)
    client = TestClient(app)
    # even with a matching empty token header, must be rejected
    r = client.post("/webhook", json=mr_note("@codebot fix"), headers={"X-Gitlab-Token": ""})
    assert r.status_code in (401, 503)


def test_webhook_uses_per_repo_secret(tmp_path):
    from cryptography.fernet import Fernet

    from orchestrator.registry import Registry

    reg = Registry(tmp_path / "r.db", Fernet.generate_key())
    reg.register("83447596", "poc-agent/poc-agent-sandbox", "glpat-x", "REPO-SECRET")
    settings = Settings(_env_file=None, webhook_secret="GLOBAL", bot_mention="@codebot",
                        bot_username="bot", gitlab_url="https://gitlab.com")
    calls = []
    app = create_app(settings=settings, orchestrator_factory=lambda task: _Rec(calls), registry=reg)
    client = TestClient(app)

    # the repo's own secret is accepted
    ok = client.post("/webhook", json=mr_note("@codebot fix"), headers={"X-Gitlab-Token": "REPO-SECRET"})
    assert ok.status_code == 200 and ok.json()["status"] == "accepted"
    # the global secret is NOT valid for this registered repo
    bad = client.post("/webhook", json=mr_note("@codebot fix"), headers={"X-Gitlab-Token": "GLOBAL"})
    assert bad.status_code == 401


def test_configured_secret_still_works():
    settings = Settings(_env_file=None, webhook_secret="s3cret", gitlab_url="https://gitlab.com",
                        bot_mention="@codebot", bot_username="bot")
    calls = []
    app = create_app(settings=settings, orchestrator_factory=lambda task: _Rec(calls))
    client = TestClient(app)
    r = client.post("/webhook", json=mr_note("@codebot fix"), headers={"X-Gitlab-Token": "s3cret"})
    assert r.status_code == 200 and r.json()["status"] == "accepted"
    assert len(calls) == 1


class _Rec:
    def __init__(self, calls):
        self.calls = calls

    def run(self, task, **kw):
        self.calls.append(task)


# --- agent output is redacted on every outbound surface ---------------------

def test_redact_masks_tokens_and_url_userinfo():
    assert "glpat-AbCdEf1234567890" not in redact("saw glpat-AbCdEf1234567890 in env")
    assert "ksk_SecretSession99xx" not in redact("KIRO_API_KEY=ksk_SecretSession99xx")
    assert "sk-lf-abcdef123456" not in redact("langfuse sk-lf-abcdef123456")
    # non-secret URL parts are preserved
    assert redact("https://oauth2:glpat-TOK@gitlab.com/g/p.git") == "https://***@gitlab.com/g/p.git"


class _TokenLeakAgent(CodingAgent):
    """Worst case: an agent that echoes a credential into its summary/stdout."""

    def run(self, task, workspace):
        (Path(workspace) / "app.py").write_text("# changed\n")
        return AgentResult(
            changed=True,
            summary="Ran `env`; output included glpat-AbCdEf1234567890.",
            raw_stdout="full agent log: glpat-AbCdEf1234567890 ksk_SecretSession99xx",
        )


def test_agent_token_in_output_is_redacted_in_mr_and_comment(bare_remote, tmp_path):
    gl = FakeGitLabClient()
    task = Task(
        intent=Intent.FIX, instruction="fix it", project_id="1", default_branch="main",
        repo_url=bare_remote.as_posix(), source_kind="issue", source_iid=7,
    )
    Orchestrator(Settings(_env_file=None), _TokenLeakAgent(), gl).run(task, workspace_dir=tmp_path / "ws")

    body = gl.draft_mr["description"]
    assert "glpat-AbCdEf1234567890" not in body
    comment = " ".join(c["body"] for c in gl.comments)
    assert "glpat-AbCdEf1234567890" not in comment
