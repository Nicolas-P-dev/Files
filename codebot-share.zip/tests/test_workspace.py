import subprocess
from pathlib import Path

from orchestrator.workspace import authenticated_url, prepare_workspace, write_agent_context
from orchestrator.git_repo import GitRepo
from orchestrator.models import Task, Intent


def test_authenticated_url_injects_token():
    assert (
        authenticated_url("https://gitlab.com/g/p.git", "TOK")
        == "https://oauth2:TOK@gitlab.com/g/p.git"
    )


def test_authenticated_url_noop_without_token_or_non_https():
    assert authenticated_url("https://gitlab.com/g/p.git", "") == "https://gitlab.com/g/p.git"
    assert authenticated_url("/local/path.git", "TOK") == "/local/path.git"


def test_prepare_workspace_clones_only(tmp_path):
    calls = {}

    def fake_clone(url, dest, branch):
        Path(dest).mkdir(parents=True, exist_ok=True)
        (Path(dest) / "README.md").write_text("# repo\n")
        calls["url"] = url
        calls["branch"] = branch
        return GitRepo(dest)

    task = Task(
        intent=Intent.FIX,
        instruction="x",
        project_id="1",
        repo_url="https://gitlab.com/g/p.git",
        default_branch="main",
    )
    dest = tmp_path / "ws"
    repo = prepare_workspace(task, dest=dest, clone_fn=fake_clone, token="TOK", allowed_host="gitlab.com")

    assert calls["url"].startswith("https://oauth2:TOK@")
    assert calls["branch"] == "main"
    assert isinstance(repo, GitRepo)
    # no steering injected at clone time anymore
    assert not (dest / ".kiro" / "steering").exists()


def test_write_agent_context_creates_excluded_file(bare_remote, tmp_path):
    repo = GitRepo.clone(bare_remote.as_posix(), tmp_path / "ws", "main")
    path = write_agent_context(repo.path, "## Goal\nBe excellent.")

    assert path is not None and path.exists()
    assert path.name == "zzz-codebot-context.md"
    assert "Be excellent." in path.read_text()
    # the injected context must NOT show up as a change to be committed
    porcelain = subprocess.run(
        ["git", "status", "--porcelain"], cwd=str(repo.path), capture_output=True, text=True
    ).stdout
    assert "zzz-codebot-context.md" not in porcelain
    assert repo.has_changes() is False


def test_write_agent_context_noop_on_empty(bare_remote, tmp_path):
    repo = GitRepo.clone(bare_remote.as_posix(), tmp_path / "ws", "main")
    assert write_agent_context(repo.path, "") is None
    assert not (repo.path / ".kiro" / "steering" / "zzz-codebot-context.md").exists()
