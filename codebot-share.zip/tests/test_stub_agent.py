from orchestrator.agents.stub import StubAgent
from orchestrator.agents.base import CodingAgent
from orchestrator.models import Task, Intent


def _task(intent, instruction="do the thing"):
    return Task(intent=intent, instruction=instruction, project_id="1", repo_url="u")


def test_stub_is_a_coding_agent():
    assert isinstance(StubAgent(), CodingAgent)


def test_stub_fix_makes_real_edit(tmp_path):
    (tmp_path / "README.md").write_text("# hello\n")
    res = StubAgent().run(_task(Intent.FIX, "fix the failing tests"), tmp_path)
    assert res.changed is True
    note = tmp_path / "AGENT_NOTES.md"
    assert note.exists()
    assert "fix" in note.read_text().lower()
    assert res.summary
    assert res.assumptions  # stub must document its assumptions


def test_stub_feature_creates_endpoint_stub(tmp_path):
    res = StubAgent().run(_task(Intent.FEATURE, "add a /health endpoint"), tmp_path)
    assert res.changed is True
    assert (tmp_path / "health.py").exists()
    assert (tmp_path / "AGENT_NOTES.md").exists()


def test_stub_improve_appends_to_existing_notes(tmp_path):
    note = tmp_path / "AGENT_NOTES.md"
    note.write_text("# Agent Notes\n\n- [fix] earlier\n")
    res = StubAgent().run(_task(Intent.IMPROVE, "improve error handling"), tmp_path)
    assert res.changed is True
    text = note.read_text()
    assert "earlier" in text  # did not clobber prior content
    assert "improve" in text.lower()


def test_stub_review_makes_no_edit_but_comments(tmp_path):
    (tmp_path / "README.md").write_text("# hello\n")
    res = StubAgent().run(_task(Intent.REVIEW, "review this"), tmp_path)
    assert res.changed is False
    assert res.review_comments  # at least one review comment
    assert not (tmp_path / "AGENT_NOTES.md").exists()


def test_stub_audit_is_read_only_like_review(tmp_path):
    res = StubAgent().run(_task(Intent.AUDIT, "audit this"), tmp_path)
    assert res.changed is False
    assert res.review_comments
    assert not (tmp_path / "AGENT_NOTES.md").exists()
