import subprocess

from orchestrator.git_repo import GitRepo


def _run(cmd, cwd):
    subprocess.run(cmd, cwd=str(cwd), check=True, capture_output=True, text=True)


def _init_remote(tmp_path):
    """Create a bare repo (the 'remote') seeded with one commit on main."""
    remote = tmp_path / "remote.git"
    subprocess.run(["git", "init", "--bare", str(remote)], check=True, capture_output=True)
    seed = tmp_path / "seed"
    subprocess.run(["git", "clone", remote.as_posix(), str(seed)], check=True, capture_output=True)
    (seed / "README.md").write_text("# seed\n")
    _run(["git", "add", "-A"], seed)
    _run(["git", "-c", "user.email=a@b.c", "-c", "user.name=t", "commit", "-m", "init"], seed)
    _run(["git", "branch", "-M", "main"], seed)
    _run(["git", "push", "origin", "main"], seed)
    return remote


def test_clone_branch_commit_push(tmp_path):
    remote = _init_remote(tmp_path)
    ws = tmp_path / "ws"

    repo = GitRepo.clone(remote.as_posix(), ws, "main")
    assert repo.path == ws
    assert repo.has_changes() is False  # clean right after clone

    (repo.path / "AGENT_NOTES.md").write_text("hi\n")
    assert repo.has_changes() is True

    repo.checkout_new_branch("codebot/test")
    repo.commit("codebot: change", "codebot", "codebot@example.com")
    repo.push("codebot/test")

    # The branch now exists on the remote.
    out = subprocess.run(
        ["git", "branch", "--all"], cwd=str(remote), capture_output=True, text=True
    )
    assert "codebot/test" in out.stdout
    assert repo.has_changes() is False  # committed -> clean tree


def test_current_branch(tmp_path):
    remote = _init_remote(tmp_path)
    repo = GitRepo.clone(remote.as_posix(), tmp_path / "ws", "main")
    assert repo.current_branch() == "main"
    repo.checkout_new_branch("codebot/feature")
    assert repo.current_branch() == "codebot/feature"
