from orchestrator.scaffold import scaffold_codebot
from orchestrator.repo_config import load_repo_config


def test_scaffolded_config_allows_audit(tmp_path):
    # The scaffold must permit `@codebot audit`, the documented read-only command.
    scaffold_codebot(tmp_path)
    cfg = load_repo_config(tmp_path)
    assert "audit" in cfg.intents_allow


def test_scaffold_writes_config_when_absent(tmp_path):
    wrote = scaffold_codebot(tmp_path)
    assert wrote is True
    cfg = tmp_path / ".codebot" / "config.yml"
    assert cfg.exists()
    text = cfg.read_text()
    assert "enabled" in text and "intents" in text


def test_scaffold_is_idempotent(tmp_path):
    (tmp_path / ".codebot").mkdir()
    (tmp_path / ".codebot" / "config.yml").write_text("enabled: true\n")
    assert scaffold_codebot(tmp_path) is False
