from orchestrator.cli import build_task_from_args
from orchestrator.config import Settings
from orchestrator.models import Intent


def _settings():
    return Settings(_env_file=None, gitlab_project="g/p", gitlab_project_id="1")


def test_build_task_infers_intent_and_cli_source():
    t = build_task_from_args(["--instruction", "fix the failing tests"], _settings())
    assert t.intent == Intent.FIX
    assert t.source_kind == "cli"
    assert t.source_iid is None
    assert t.repo_url == "https://gitlab.com/g/p.git"
    assert t.project_id == "1"
    assert t.default_branch == "main"


def test_build_task_explicit_intent_and_mr_with_discussion():
    t = build_task_from_args(
        ["--intent", "review", "--instruction", "look at this", "--mr", "12", "--discussion", "abc"],
        _settings(),
    )
    assert t.intent == Intent.REVIEW
    assert t.source_kind == "mr"
    assert t.source_iid == 12
    assert t.discussion_id == "abc"


def test_build_task_issue_source():
    t = build_task_from_args(
        ["--instruction", "add a /health endpoint", "--issue", "7"], _settings()
    )
    assert t.intent == Intent.FEATURE
    assert t.source_kind == "issue"
    assert t.source_iid == 7
