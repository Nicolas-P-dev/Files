from orchestrator.models import Intent, Task, AgentResult


def test_task_defaults():
    t = Task(
        intent=Intent.FIX,
        instruction="fix tests",
        project_id="123",
        repo_url="https://x/y.git",
    )
    assert t.default_branch == "main"
    assert t.source_kind == "cli"
    assert t.source_iid is None
    assert t.discussion_id is None
    assert t.author is None


def test_agent_result_defaults():
    r = AgentResult(changed=True, summary="did a thing")
    assert r.changed is True
    assert r.summary == "did a thing"
    assert r.assumptions == []
    assert r.review_comments == []
    assert r.branch is None
    assert r.raw_stdout == ""
    assert r.exit_code == 0


def test_intent_is_str_enum():
    assert Intent.REVIEW == "review"
    assert Intent("fix") is Intent.FIX
