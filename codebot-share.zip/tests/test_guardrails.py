"""Tests for branch-name uniqueness and the protected-file guardrail."""

from pathlib import Path
import subprocess

from orchestrator.orchestrator import Orchestrator
from orchestrator.agents.base import CodingAgent
from orchestrator.agents.stub import StubAgent
from orchestrator.config import Settings
from orchestrator.models import AgentResult, Task, Intent


def _settings():
    return Settings(_env_file=None)


def _task(**kw):
    base = dict(
        intent=Intent.FIX, instruction="fix it", project_id="1", default_branch="main"
    )
    base.update(kw)
    return Task(**base)


def _pushed_tree(remote, branch):
    out = subprocess.run(
        ["git", "ls-tree", "-r", branch, "--name-only"],
        cwd=str(remote), capture_output=True, text=True,
    )
    return out.stdout


# --- branch uniqueness -----------------------------------------------------

def test_branch_names_unique_across_identical_requests(bare_remote, tmp_path, fake_gitlab):
    orch = Orchestrator(_settings(), StubAgent(), fake_gitlab)
    r1 = orch.run(_task(repo_url=bare_remote.as_posix()), workspace_dir=tmp_path / "ws1")
    r2 = orch.run(_task(repo_url=bare_remote.as_posix()), workspace_dir=tmp_path / "ws2")
    assert r1.branch != r2.branch
    assert r1.branch.startswith("codebot/fix-")


# --- protected-file guardrail ----------------------------------------------

class _CIAgent(CodingAgent):
    """Touches both a protected CI file and a normal file."""

    def run(self, task, workspace):
        (Path(workspace) / ".gitlab-ci.yml").write_text("evil: true\n")
        (Path(workspace) / "app.py").write_text("# fixed\n")
        return AgentResult(changed=True, summary="changed ci + app")


class _OnlyCIAgent(CodingAgent):
    def run(self, task, workspace):
        (Path(workspace) / ".gitlab-ci.yml").write_text("evil: true\n")
        return AgentResult(changed=True, summary="touched ci only")


def test_protected_file_is_stripped_but_allowed_change_lands(bare_remote, tmp_path, fake_gitlab):
    orch = Orchestrator(_settings(), _CIAgent(), fake_gitlab)
    result = orch.run(
        _task(repo_url=bare_remote.as_posix(), source_kind="issue", source_iid=1),
        workspace_dir=tmp_path / "ws",
    )
    tree = _pushed_tree(bare_remote, result.branch)
    assert ".gitlab-ci.yml" not in tree   # protected file never committed
    assert "app.py" in tree               # the allowed change still lands
    assert ".gitlab-ci.yml" in fake_gitlab.draft_mr["description"]  # skip is disclosed


class _StagedCIAgent(CodingAgent):
    """Creates AND stages a protected file (as real Kiro could via execute_bash).
    A staged add/rename has no version in HEAD, so a naive discard crashes."""

    def run(self, task, workspace):
        ws = Path(workspace)
        (ws / ".gitlab-ci.yml").write_text("evil: true\n")
        (ws / "app.py").write_text("# fixed\n")
        subprocess.run(["git", "add", ".gitlab-ci.yml"], cwd=str(ws), check=True, capture_output=True)
        return AgentResult(changed=True, summary="staged ci + edited app")


def test_staged_protected_file_is_discarded_not_crash(bare_remote, tmp_path, fake_gitlab):
    # A protected file that is staged (not in HEAD) must be discarded gracefully,
    # not crash the whole task on `git checkout HEAD -- <path>`. Audit finding #9.
    orch = Orchestrator(_settings(), _StagedCIAgent(), fake_gitlab)
    result = orch.run(
        _task(repo_url=bare_remote.as_posix(), source_kind="issue", source_iid=3),
        workspace_dir=tmp_path / "ws",
    )
    tree = _pushed_tree(bare_remote, result.branch)
    assert ".gitlab-ci.yml" not in tree   # protected staged file discarded
    assert "app.py" in tree               # the allowed change still lands


def test_only_protected_change_opens_no_mr(bare_remote, tmp_path, fake_gitlab):
    orch = Orchestrator(_settings(), _OnlyCIAgent(), fake_gitlab)
    orch.run(
        _task(repo_url=bare_remote.as_posix(), source_kind="issue", source_iid=2),
        workspace_dir=tmp_path / "ws",
    )
    assert fake_gitlab.draft_mr is None  # nothing allowed to land -> no MR
    assert fake_gitlab.comments
    assert "protected" in fake_gitlab.comments[-1]["body"].lower()
