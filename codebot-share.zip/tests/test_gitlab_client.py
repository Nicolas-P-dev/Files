import pytest

from orchestrator.gitlab_client import GitLabClient


class FakeNotes:
    def __init__(self):
        self.created = []

    def create(self, payload):
        self.created.append(payload)
        return {"id": len(self.created), **payload}


class FakeDiscussion:
    def __init__(self):
        self.notes = FakeNotes()


class FakeDiscussions:
    def __init__(self):
        self._d = FakeDiscussion()
        self.requested = None

    def get(self, discussion_id):
        self.requested = discussion_id
        return self._d


class FakeMR:
    def __init__(self, iid):
        self.iid = iid
        self.web_url = f"https://gitlab.example/mr/{iid}"
        self.notes = FakeNotes()
        self.discussions = FakeDiscussions()


class FakeMRManager:
    def __init__(self):
        self.created = None
        self._mrs = {}

    def create(self, payload):
        self.created = payload
        mr = FakeMR(iid=42)
        self._mrs[42] = mr
        return mr

    def get(self, iid):
        return self._mrs.setdefault(iid, FakeMR(iid))


class FakeProject:
    def __init__(self):
        self.mergerequests = FakeMRManager()


def test_create_draft_mr_prefixes_title_and_sets_fields():
    proj = FakeProject()
    c = GitLabClient(project=proj)
    mr = c.create_draft_mr("codebot/x", "main", "Fix tests", "desc", assignee_ids=[7])
    p = proj.mergerequests.created
    assert p["source_branch"] == "codebot/x"
    assert p["target_branch"] == "main"
    assert p["title"].startswith("Draft:")
    assert p["description"] == "desc"
    assert p["assignee_ids"] == [7]
    assert mr.iid == 42


def test_create_draft_mr_does_not_double_prefix():
    proj = FakeProject()
    GitLabClient(project=proj).create_draft_mr("b", "main", "Draft: already", "d")
    assert proj.mergerequests.created["title"] == "Draft: already"


def test_post_mr_comment_top_level():
    proj = FakeProject()
    GitLabClient(project=proj).post_comment("mr", 42, "hello")
    assert proj.mergerequests.get(42).notes.created[-1]["body"] == "hello"


def test_post_mr_comment_in_discussion_thread():
    proj = FakeProject()
    GitLabClient(project=proj).post_comment("mr", 42, "reply", discussion_id="abc")
    mr = proj.mergerequests.get(42)
    assert mr.discussions.requested == "abc"
    assert mr.discussions._d.notes.created[-1]["body"] == "reply"


def test_post_comment_unknown_kind_raises():
    with pytest.raises(ValueError):
        GitLabClient(project=FakeProject()).post_comment("wiki", 1, "x")


class _FakeUser:
    id = 39268001


class _FakeGL:
    def __init__(self):
        self.authed = False
        self.user = _FakeUser()

    def auth(self):
        self.authed = True


def test_current_user_id_authenticates_and_returns_id():
    gl = _FakeGL()
    c = GitLabClient(project=FakeProject(), gl=gl)
    assert c.current_user_id() == 39268001
    assert gl.authed is True


def test_current_user_id_none_without_gl():
    assert GitLabClient(project=FakeProject()).current_user_id() is None


def test_get_mr_changes_returns_changed_files_list():
    proj = FakeProject()
    c = GitLabClient(project=proj)
    mr = proj.mergerequests.get(7)
    mr.changes = lambda: {"changes": [{"new_path": "a.py"}, {"new_path": "b.py"}]}
    out = c.get_mr_changes(7)
    assert [f["new_path"] for f in out] == ["a.py", "b.py"]


def test_create_draft_mr_with_labels():
    proj = FakeProject()
    GitLabClient(project=proj).create_draft_mr("b", "main", "T", "d", labels=["codebot", "automated"])
    assert proj.mergerequests.created["labels"] == ["codebot", "automated"]


def test_get_mr_source_branch():
    proj = FakeProject()
    c = GitLabClient(project=proj)
    mr = proj.mergerequests.get(7)
    mr.source_branch = "feature/x"
    assert c.get_mr_source_branch(7) == "feature/x"


class _FakeUser2:
    def __init__(self, uid):
        self.id = uid


class _FakeUsers:
    def list(self, username=None, **kw):
        return [_FakeUser2(101)] if username == "alice" else []


class _FakeGL2:
    def __init__(self):
        self.users = _FakeUsers()


def test_resolve_user_ids_skips_unknown():
    c = GitLabClient(project=FakeProject(), gl=_FakeGL2())
    assert c.resolve_user_ids(["alice", "ghost"]) == [101]


def test_resolve_user_ids_empty_without_gl():
    assert GitLabClient(project=FakeProject()).resolve_user_ids(["alice"]) == []


class _FakeHook:
    def __init__(self, hid, url):
        self.id = hid
        self.url = url
        self.saved = False

    def save(self):
        self.saved = True


class _FakeHooks:
    def __init__(self):
        self._hooks = []
        self.created = None

    def list(self, **kw):
        return list(self._hooks)

    def create(self, payload):
        self.created = payload
        h = _FakeHook(1, payload["url"])
        self._hooks.append(h)
        return h


class _FakeProjectHooks:
    def __init__(self):
        self.hooks = _FakeHooks()


def test_ensure_webhook_creates_when_absent():
    proj = _FakeProjectHooks()
    GitLabClient(project=proj).ensure_webhook("https://x/webhook", "sec")
    p = proj.hooks.created
    assert p["url"] == "https://x/webhook" and p["token"] == "sec"
    assert p["note_events"] is True and p["merge_requests_events"] is True
    assert p["push_events"] is False


def test_ensure_webhook_updates_when_present():
    proj = _FakeProjectHooks()
    existing = _FakeHook(7, "https://x/webhook")
    proj.hooks._hooks.append(existing)
    GitLabClient(project=proj).ensure_webhook("https://x/webhook", "newsec")
    assert existing.saved is True
    assert existing.token == "newsec"
    assert proj.hooks.created is None  # updated, not re-created
