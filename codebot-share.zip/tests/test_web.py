from cryptography.fernet import Fernet
from fastapi import FastAPI
from fastapi.testclient import TestClient

from orchestrator.config import Settings
from orchestrator.registry import Registry
from orchestrator.web import add_onboarding_routes


def _app(tmp_path, onboard_fn=None):
    settings = Settings(_env_file=None, admin_token="adminpw",
                        public_base_url="https://cb.example", gitlab_url="https://gitlab.com")
    reg = Registry(tmp_path / "r.db", Fernet.generate_key())
    app = FastAPI()
    add_onboarding_routes(app, settings, reg, onboard_fn=onboard_fn)
    return app, reg


def test_onboard_form_requires_admin(tmp_path):
    app, _ = _app(tmp_path)
    c = TestClient(app)
    assert c.get("/onboard").status_code == 401
    r = c.get("/onboard", auth=("admin", "adminpw"))
    assert r.status_code == 200 and "<form" in r.text.lower()


class _Res:
    project_id = "1"
    project_path = "g/p"
    webhook_url = "https://cb.example/webhook"
    scaffold_mr_url = "https://gitlab.com/g/p/-/merge_requests/9"
    status = "active"


def test_onboard_submit_calls_service(tmp_path):
    calls = []

    def fake_onboard(path, token, *, settings, registry):
        calls.append((path, token))
        return _Res()

    app, _ = _app(tmp_path, fake_onboard)
    c = TestClient(app)
    r = c.post("/onboard", data={"project_path": "g/p", "token": "glpat-x"}, auth=("admin", "adminpw"))
    assert r.status_code == 200 and "connected" in r.text.lower()
    assert "merge_requests/9" in r.text
    assert calls == [("g/p", "glpat-x")]


def test_status_lists_repos_without_exposing_token(tmp_path):
    app, reg = _app(tmp_path)
    reg.register("1", "group/project", "glpat-SECRET", "wh")
    c = TestClient(app)
    r = c.get("/status", auth=("admin", "adminpw"))
    assert r.status_code == 200
    assert "group/project" in r.text
    assert "glpat-SECRET" not in r.text  # token never shown
