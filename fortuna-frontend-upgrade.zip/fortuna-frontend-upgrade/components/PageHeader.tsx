"use client";

import React from "react";
import { Box, Typography, Chip, Divider, Breadcrumbs } from "@mui/material";
import Link from "next/link";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  currentDebtor?: string | null;
  showDebtorBadge?: boolean;
  actions?: React.ReactNode;
  breadcrumbs?: Array<{ label: string; href?: string }>;
}

const PageHeader: React.FC<PageHeaderProps> = ({
  title,
  subtitle,
  currentDebtor,
  showDebtorBadge = true,
  actions,
  breadcrumbs,
}) => {
  return (
    <Box sx={{ mb: 3 }}>
      {/* Optional Breadcrumbs */}
      {breadcrumbs && breadcrumbs.length > 0 && (
        <Breadcrumbs
          separator={<NavigateNextIcon sx={{ fontSize: 16, color: "#A5ADBA" }} />}
          sx={{ mb: 1.5 }}
        >
          <Link href="/" style={{ textDecoration: "none" }}>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                gap: 0.5,
                color: "#6B778C",
                "&:hover": { color: "#26890D" },
              }}
            >
              <HomeOutlinedIcon sx={{ fontSize: 16 }} />
              <Typography variant="caption">Home</Typography>
            </Box>
          </Link>
          {breadcrumbs.map((crumb, idx) =>
            crumb.href ? (
              <Link key={idx} href={crumb.href} style={{ textDecoration: "none" }}>
                <Typography
                  variant="caption"
                  sx={{ color: "#6B778C", "&:hover": { color: "#26890D" } }}
                >
                  {crumb.label}
                </Typography>
              </Link>
            ) : (
              <Typography key={idx} variant="caption" sx={{ color: "#000", fontWeight: 500 }}>
                {crumb.label}
              </Typography>
            )
          )}
        </Breadcrumbs>
      )}

      {/* Main Header Row */}
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          mb: 2,
        }}
      >
        <Box>
          <Typography
            variant="h4"
            sx={{
              fontWeight: 700,
              color: "#000000",
              mb: 0.5,
              fontSize: { xs: "1.5rem", md: "2rem" },
            }}
          >
            {title}
          </Typography>
          {subtitle && (
            <Typography
              variant="body2"
              sx={{
                color: "#6B778C",
                maxWidth: 600,
              }}
            >
              {subtitle}
            </Typography>
          )}
        </Box>

        <Box sx={{ display: "flex", alignItems: "center", gap: 2, flexShrink: 0 }}>
          {showDebtorBadge && (
            <Chip
              label={
                currentDebtor ? (
                  <Box sx={{ display: "flex", alignItems: "center", gap: 0.75 }}>
                    <Box
                      sx={{
                        width: 6,
                        height: 6,
                        borderRadius: "50%",
                        bgcolor: "#86BC25",
                      }}
                    />
                    {currentDebtor}
                  </Box>
                ) : (
                  "No debtor selected"
                )
              }
              sx={{
                bgcolor: currentDebtor
                  ? "rgba(134, 188, 37, 0.08)"
                  : "rgba(0, 0, 0, 0.04)",
                color: currentDebtor ? "#26890D" : "#6B778C",
                fontWeight: currentDebtor ? 600 : 400,
                border: currentDebtor
                  ? "1px solid rgba(134, 188, 37, 0.25)"
                  : "1px solid rgba(0, 0, 0, 0.08)",
                borderRadius: 1.5,
                height: 32,
                "& .MuiChip-label": {
                  px: 1.5,
                },
              }}
            />
          )}
          {actions}
        </Box>
      </Box>

      <Divider sx={{ bgcolor: "rgba(0, 0, 0, 0.06)" }} />
    </Box>
  );
};

export default PageHeader;
