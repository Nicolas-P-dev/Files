"use client";

import React, { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Box,
  Typography,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Divider,
  Collapse,
  Badge,
} from "@mui/material";
import SettingsIcon from "@mui/icons-material/Settings";
import HelpOutlineIcon from "@mui/icons-material/HelpOutline";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import AssessmentOutlinedIcon from "@mui/icons-material/AssessmentOutlined";
import FolderOutlinedIcon from "@mui/icons-material/FolderOutlined";
import HistoryIcon from "@mui/icons-material/History";
import DashboardOutlinedIcon from "@mui/icons-material/DashboardOutlined";
import SourceOutlinedIcon from "@mui/icons-material/SourceOutlined";
import SwapHorizIcon from "@mui/icons-material/SwapHoriz";
import BookmarkBorderIcon from "@mui/icons-material/BookmarkBorder";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";
import InsertDriveFileOutlinedIcon from "@mui/icons-material/InsertDriveFileOutlined";
import AccountTreeOutlinedIcon from "@mui/icons-material/AccountTreeOutlined";

interface SidebarProps {
  currentDebtor: string | null;
}

const Sidebar: React.FC<SidebarProps> = ({ currentDebtor }) => {
  const pathname = usePathname();
  const [projectsOpen, setProjectsOpen] = useState(true);

  // Main workflow navigation
  const workflowItems = [
    {
      label: "Dashboard",
      path: "/",
      icon: <DashboardOutlinedIcon />,
      enabled: true,
    },
    {
      label: "Configurations",
      path: "/modules/upload-document",
      icon: <SettingsIcon />,
      enabled: true,
    },
    {
      label: "Attributions",
      path: "/modules/attributions",
      icon: <SourceOutlinedIcon />,
      enabled: true,
      badge: currentDebtor ? "Ready" : null,
    },
    {
      label: "Report Preview",
      path: "/modules/report-preview",
      icon: <DescriptionOutlinedIcon />,
      enabled: true,
    },
  ];

  // Data management section
  const dataItems = [
    {
      label: "Data Exchanges",
      path: "/modules/data-exchanges",
      icon: <SwapHorizIcon />,
      enabled: true,
    },
    {
      label: "Saved Documents",
      path: "/modules/saved-documents",
      icon: <BookmarkBorderIcon />,
      enabled: false,
      badge: "3",
    },
    {
      label: "History",
      path: "/modules/history",
      icon: <HistoryIcon />,
      enabled: false,
    },
  ];

  // Recent projects (mock data for demo)
  const recentProjects = [
    { name: "Demo Debtor 2024", id: "1234567", active: currentDebtor === "1234567_Demo Debtor" },
    { name: "Sample Corp Q3", id: "7654321", active: false },
    { name: "Test Holdings", id: "9876543", active: false },
  ];

  const isSelected = (path: string) => {
    if (path === "/" && pathname === "/") return true;
    if (path !== "/" && pathname.startsWith(path)) return true;
    return false;
  };

  const NavItem = ({ item }: { item: typeof workflowItems[0] }) => (
    <ListItem disablePadding sx={{ mb: 0.25 }}>
      {item.enabled ? (
        <Link href={item.path} style={{ textDecoration: "none", width: "100%" }}>
          <ListItemButton
            selected={isSelected(item.path)}
            sx={{
              borderRadius: 1.5,
              py: 1,
              px: 1.5,
              "&.Mui-selected": {
                bgcolor: "rgba(134, 188, 37, 0.15)",
                borderLeft: "3px solid #86BC25",
                "& .MuiListItemIcon-root": { color: "#86BC25" },
                "& .MuiListItemText-primary": {
                  color: "#FFFFFF",
                  fontWeight: 600,
                },
              },
              "&:hover": {
                bgcolor: "rgba(255, 255, 255, 0.06)",
              },
            }}
          >
            <ListItemIcon
              sx={{
                minWidth: 36,
                color: isSelected(item.path) ? "#86BC25" : "rgba(255,255,255,0.7)",
              }}
            >
              {item.icon}
            </ListItemIcon>
            <ListItemText
              primary={item.label}
              sx={{
                "& .MuiListItemText-primary": {
                  color: "rgba(255,255,255,0.9)",
                  fontSize: "0.875rem",
                  fontWeight: isSelected(item.path) ? 600 : 400,
                },
              }}
            />
            {item.badge && (
              <Badge
                badgeContent={item.badge}
                sx={{
                  "& .MuiBadge-badge": {
                    bgcolor: "#86BC25",
                    color: "#000",
                    fontSize: "0.65rem",
                    fontWeight: 600,
                    height: 18,
                    minWidth: 18,
                  },
                }}
              />
            )}
          </ListItemButton>
        </Link>
      ) : (
        <ListItemButton
          disabled
          sx={{
            borderRadius: 1.5,
            py: 1,
            px: 1.5,
            opacity: 0.4,
          }}
        >
          <ListItemIcon sx={{ minWidth: 36, color: "rgba(255,255,255,0.4)" }}>
            {item.icon}
          </ListItemIcon>
          <ListItemText
            primary={item.label}
            secondary="Coming soon"
            sx={{
              "& .MuiListItemText-primary": {
                color: "rgba(255,255,255,0.5)",
                fontSize: "0.875rem",
              },
              "& .MuiListItemText-secondary": {
                color: "rgba(255,255,255,0.3)",
                fontSize: "0.7rem",
              },
            }}
          />
        </ListItemButton>
      )}
    </ListItem>
  );

  return (
    <Box
      sx={{
        width: 260,
        height: "100vh",
        background: "linear-gradient(180deg, #0a0a0a 0%, #1a1a1a 100%)",
        color: "#FFFFFF",
        display: "flex",
        flexDirection: "column",
        position: "fixed",
        left: 0,
        top: 0,
        zIndex: 1200,
        borderRight: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      {/* Logo and App Title - Compact */}
      <Box sx={{ pt: 2.5, px: 2.5, pb: 2 }}>
        <Image
          src="/Deloitte_Logo.png"
          width={110}
          height={28}
          alt="Deloitte Logo"
          style={{ marginBottom: "12px" }}
        />
        <Box sx={{ display: "flex", alignItems: "baseline", gap: 1 }}>
          <Typography
            variant="caption"
            sx={{
              fontWeight: 400,
              color: "rgba(255,255,255,0.5)",
              textTransform: "uppercase",
              letterSpacing: "0.1em",
              fontSize: "0.65rem",
            }}
          >
            aiStudio
          </Typography>
          <Typography
            variant="h6"
            sx={{
              fontWeight: 700,
              color: "#FFFFFF",
              fontSize: "1.1rem",
              letterSpacing: "0.05em",
            }}
          >
            FORTUNA
          </Typography>
        </Box>
      </Box>

      <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.08)", mx: 2 }} />

      {/* Current Debtor Status */}
      <Box sx={{ px: 2, py: 1.5 }}>
        <Typography
          variant="caption"
          sx={{
            color: "rgba(255,255,255,0.4)",
            textTransform: "uppercase",
            letterSpacing: "0.08em",
            fontSize: "0.65rem",
            fontWeight: 500,
          }}
        >
          Active Debtor
        </Typography>
        <Box
          sx={{
            mt: 0.75,
            p: 1.25,
            borderRadius: 1.5,
            bgcolor: currentDebtor
              ? "rgba(134, 188, 37, 0.12)"
              : "rgba(255, 255, 255, 0.03)",
            border: currentDebtor
              ? "1px solid rgba(134, 188, 37, 0.3)"
              : "1px solid rgba(255, 255, 255, 0.08)",
            transition: "all 0.2s ease",
          }}
        >
          <Typography
            variant="body2"
            sx={{
              color: currentDebtor ? "#86BC25" : "rgba(255,255,255,0.4)",
              fontWeight: currentDebtor ? 600 : 400,
              fontSize: "0.8rem",
            }}
          >
            {currentDebtor || "No debtor selected"}
          </Typography>
          {currentDebtor && (
            <Typography
              variant="caption"
              sx={{ color: "rgba(134, 188, 37, 0.7)", fontSize: "0.7rem" }}
            >
              Ready for processing
            </Typography>
          )}
        </Box>
      </Box>

      <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.08)", mx: 2 }} />

      {/* Workflow Navigation */}
      <Box sx={{ py: 1, px: 1 }}>
        <Typography
          variant="caption"
          sx={{
            color: "rgba(255,255,255,0.4)",
            textTransform: "uppercase",
            letterSpacing: "0.08em",
            fontSize: "0.65rem",
            fontWeight: 500,
            px: 1.5,
            display: "block",
            mb: 0.5,
          }}
        >
          Workflow
        </Typography>
        <List component="nav" disablePadding>
          {workflowItems.map((item) => (
            <NavItem key={item.label} item={item} />
          ))}
        </List>
      </Box>

      <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.08)", mx: 2 }} />

      {/* Data Management */}
      <Box sx={{ py: 1, px: 1 }}>
        <Typography
          variant="caption"
          sx={{
            color: "rgba(255,255,255,0.4)",
            textTransform: "uppercase",
            letterSpacing: "0.08em",
            fontSize: "0.65rem",
            fontWeight: 500,
            px: 1.5,
            display: "block",
            mb: 0.5,
          }}
        >
          Data
        </Typography>
        <List component="nav" disablePadding>
          {dataItems.map((item) => (
            <NavItem key={item.label} item={item} />
          ))}
        </List>
      </Box>

      <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.08)", mx: 2 }} />

      {/* Recent Projects - Collapsible */}
      <Box sx={{ py: 1, px: 1, flex: 1, overflow: "auto" }}>
        <ListItemButton
          onClick={() => setProjectsOpen(!projectsOpen)}
          sx={{
            borderRadius: 1.5,
            py: 0.75,
            px: 1.5,
            "&:hover": { bgcolor: "rgba(255,255,255,0.04)" },
          }}
        >
          <ListItemIcon sx={{ minWidth: 36, color: "rgba(255,255,255,0.5)" }}>
            <AccountTreeOutlinedIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText
            primary="Recent Projects"
            sx={{
              "& .MuiListItemText-primary": {
                color: "rgba(255,255,255,0.6)",
                fontSize: "0.75rem",
                textTransform: "uppercase",
                letterSpacing: "0.05em",
              },
            }}
          />
          {projectsOpen ? (
            <ExpandLess sx={{ color: "rgba(255,255,255,0.4)", fontSize: 18 }} />
          ) : (
            <ExpandMore sx={{ color: "rgba(255,255,255,0.4)", fontSize: 18 }} />
          )}
        </ListItemButton>
        <Collapse in={projectsOpen} timeout="auto" unmountOnExit>
          <List component="div" disablePadding sx={{ pl: 1 }}>
            {recentProjects.map((project) => (
              <ListItemButton
                key={project.id}
                sx={{
                  borderRadius: 1,
                  py: 0.5,
                  pl: 4,
                  "&:hover": { bgcolor: "rgba(255,255,255,0.04)" },
                }}
              >
                <InsertDriveFileOutlinedIcon
                  sx={{
                    fontSize: 14,
                    mr: 1,
                    color: project.active ? "#86BC25" : "rgba(255,255,255,0.4)",
                  }}
                />
                <ListItemText
                  primary={project.name}
                  sx={{
                    "& .MuiListItemText-primary": {
                      fontSize: "0.8rem",
                      color: project.active ? "#86BC25" : "rgba(255,255,255,0.6)",
                      fontWeight: project.active ? 500 : 400,
                    },
                  }}
                />
                {project.active && (
                  <Box
                    sx={{
                      width: 6,
                      height: 6,
                      borderRadius: "50%",
                      bgcolor: "#86BC25",
                    }}
                  />
                )}
              </ListItemButton>
            ))}
          </List>
        </Collapse>
      </Box>

      {/* Bottom Section */}
      <Box sx={{ mt: "auto" }}>
        <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.08)", mx: 2 }} />
        <List component="nav" sx={{ px: 1, py: 1 }}>
          <ListItem disablePadding>
            <ListItemButton
              sx={{
                borderRadius: 1.5,
                py: 0.75,
                px: 1.5,
                opacity: 0.6,
                "&:hover": { bgcolor: "rgba(255, 255, 255, 0.04)" },
              }}
            >
              <ListItemIcon sx={{ minWidth: 36, color: "rgba(255,255,255,0.5)" }}>
                <HelpOutlineIcon fontSize="small" />
              </ListItemIcon>
              <ListItemText
                primary="Help & Docs"
                sx={{
                  "& .MuiListItemText-primary": {
                    color: "rgba(255,255,255,0.6)",
                    fontSize: "0.8rem",
                  },
                }}
              />
            </ListItemButton>
          </ListItem>
        </List>
        
        {/* Version footer */}
        <Box sx={{ px: 2.5, py: 1.5, borderTop: "1px solid rgba(255,255,255,0.05)" }}>
          <Typography
            variant="caption"
            sx={{ color: "rgba(255,255,255,0.25)", fontSize: "0.65rem" }}
          >
            FORTUNA v1.0.0 • CFR Automation
          </Typography>
        </Box>
      </Box>
    </Box>
  );
};

export default Sidebar;
