// Backend URL configuration
// Adjust this based on your deployment environment

export const backend_url = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";

// Feature flags
export const features = {
  enableChat: true,
  enableExcelPreview: true,
  enableDataExchanges: true,
  enableHistory: false, // Coming soon
  enableSavedDocuments: false, // Coming soon
};

// API endpoints
export const endpoints = {
  getCurrentDebtor: `${backend_url}/get_current_debtor`,
  getDebtorInfo: `${backend_url}/get_debtor_info`,
  getDocsList: `${backend_url}/get_docs_list`,
  processDocumentList: `${backend_url}/process_document_list`,
  startAgentProcessing: `${backend_url}/start_agent_processing`,
  agentProcessingStatus: (jobId: string) => `${backend_url}/agent_processing_status/${jobId}`,
  getAgentLogs: `${backend_url}/get_agent_logs`,
  downloadReport: `${backend_url}/download_report`,
  getReportPreview: `${backend_url}/get_report_preview`,
  chat: `${backend_url}/chat`,
};
