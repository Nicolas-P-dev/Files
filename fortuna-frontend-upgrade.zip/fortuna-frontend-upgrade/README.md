# FORTUNA Frontend Upgrade

## Overview
This package contains a complete frontend redesign for FORTUNA with the following improvements:

### Key Changes

#### 1. **New Dashboard Home Page**
- Welcome screen with project overview
- Quick stats (documents processed, fields extracted, reports generated)
- Quick action cards for navigation
- Workflow progress indicator
- Recent activity timeline

#### 2. **Sidebar Enhancements**
- Renamed "Report Generation" → "Attributions"
- Added "Data Exchanges" navigation item
- Added "Recent Projects" collapsible section
- Added "Saved Documents" (coming soon placeholder)
- Deloitte branding preserved and refined
- Better visual hierarchy with section labels

#### 3. **Attributions Page (formerly Report Generation)**
- Improved expand/collapse controls with visual depth indicator
- Auto-expands first 2 levels on load (data visible immediately)
- Better field value display with:
  - Value (bold, highlighted)
  - Sources (as chips)
  - Page numbers (as badges)
  - Explanation (collapsible)
- Category filter tabs
- Download button moved to fixed position (bottom-right)

#### 4. **Chat Panel Integration**
- Removed robot/AI icons (replaced with "F" branding)
- Context-aware responses based on agent logs
- Falls back gracefully when backend chat endpoint unavailable
- Source references displayed as chips

#### 5. **Report Preview Page**
- Excel spreadsheet preview with tabs (Balance Sheet, P&L, Cash Flow)
- Financial data formatted with color coding (green positive, red negative)
- Source and page number columns
- Fullscreen mode
- Fixed download button

#### 6. **Data Exchanges Page**
- Import from directory feature
- Export to cloud configuration
- Exchange history table
- Status indicators

#### 7. **Visual Improvements**
- Consistent Deloitte color palette (#86BC25 green, #007CB0 blue)
- Professional typography
- Smooth animations
- Better empty states
- Custom scrollbars
- Improved loading indicators

---

## Installation Instructions

### Option 1: Full Replacement
1. Backup your current frontend:
   ```bash
   cp -r fortuna/frontend fortuna/frontend_backup
   ```

2. Extract this package to replace frontend files:
   ```bash
   # Copy components
   cp -r components/* fortuna/frontend/src/components/
   
   # Copy pages
   cp -r app/* fortuna/frontend/src/app/
   
   # Copy contexts
   cp -r contexts/* fortuna/frontend/src/contexts/
   
   # Copy UI components
   cp -r ui/* fortuna/frontend/src/ui/
   
   # Copy config
   cp config.ts fortuna/frontend/src/config.ts
   ```

### Option 2: Selective Integration
Copy only the files you need:

**For Sidebar changes:**
```bash
cp components/Sidebar.tsx fortuna/frontend/src/components/
```

**For Attributions page:**
```bash
cp app/\(main\)/modules/attributions/* fortuna/frontend/src/app/\(main\)/modules/attributions/
```

**For Dashboard:**
```bash
cp app/\(main\)/page.tsx fortuna/frontend/src/app/\(main\)/
```

---

## File Structure

```
fortuna-frontend-upgrade/
├── app/
│   ├── (main)/
│   │   ├── app.tsx                    # App wrapper
│   │   ├── layout.tsx                 # Root layout
│   │   ├── page.tsx                   # Dashboard (home page)
│   │   └── modules/
│   │       ├── attributions/
│   │       │   ├── page.tsx           # Attributions page
│   │       │   └── agentLogs.tsx      # Improved accordion
│   │       ├── report-preview/
│   │       │   └── page.tsx           # Excel preview
│   │       ├── data-exchanges/
│   │       │   └── page.tsx           # Data exchanges
│   │       └── upload-document/
│   │           ├── page.tsx           # Configurations
│   │           ├── templateSelections.tsx
│   │           └── documentsList.tsx
│   ├── globals.css                    # Global styles
│   └── theme.ts                       # MUI theme
├── components/
│   ├── Sidebar.tsx                    # Navigation sidebar
│   ├── MainLayout.tsx                 # Layout wrapper
│   ├── PageHeader.tsx                 # Page header component
│   └── ChatPanel.tsx                  # Chat assistant
├── contexts/
│   └── AgentLogsContext.tsx           # Agent logs state
├── ui/
│   ├── circularLoader.tsx             # Loading overlay
│   └── alert.tsx                      # Alert notifications
├── config.ts                          # Backend URL config
└── README.md                          # This file
```

---

## Configuration

### Backend URL
Edit `config.ts` to set your backend URL:

```typescript
export const backend_url = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000";
```

Or set environment variable:
```bash
NEXT_PUBLIC_BACKEND_URL=http://your-backend:8000
```

---

## Backend Endpoints Used

The frontend expects these endpoints:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/get_current_debtor` | GET | Get active debtor |
| `/get_debtor_info` | GET | Get debtor list |
| `/get_docs_list` | POST | Get documents for debtor |
| `/process_document_list` | POST | Submit documents |
| `/start_agent_processing` | POST | Start extraction |
| `/agent_processing_status/{job_id}` | GET | Check processing status |
| `/get_agent_logs` | GET | Get extraction results |
| `/download_report` | GET | Download Excel report |
| `/get_report_preview` | GET | (Optional) Get report preview data |
| `/chat` | POST | (Optional) Chat with assistant |

---

## Troubleshooting

### Agent logs not showing
1. Check if debtor is selected
2. Verify `/get_agent_logs` endpoint returns data
3. Check browser console for errors
4. Data should be an object (not array)

### Chat not working
The chat has built-in fallback responses. If backend `/chat` endpoint is unavailable, it will use context-aware local responses based on the agent logs.

### Download not working
Ensure `/download_report` endpoint returns a valid Excel file with proper headers:
```
Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet
Content-Disposition: attachment; filename="report.xlsx"
```

---

## Notes

- Deloitte branding is preserved (logo, colors)
- All existing backend API compatibility maintained
- No breaking changes to data structures
- Graceful fallbacks for missing endpoints
