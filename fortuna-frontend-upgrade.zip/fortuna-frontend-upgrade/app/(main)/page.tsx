"use client";

import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Paper,
  Button,
  Chip,
  LinearProgress,
  IconButton,
  Tooltip,
} from "@mui/material";
import Grid from "@mui/material/Grid2";
import { useRouter } from "next/navigation";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import ScheduleIcon from "@mui/icons-material/Schedule";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import FolderOpenIcon from "@mui/icons-material/FolderOpen";
import PlayArrowIcon from "@mui/icons-material/PlayArrow";
import RefreshIcon from "@mui/icons-material/Refresh";
import { backend_url } from "@/config";

// Metric Card Component
const MetricCard = ({
  title,
  value,
  subtitle,
  icon,
  color = "#86BC25",
  trend,
}: {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
  color?: string;
  trend?: string;
}) => (
  <Paper
    elevation={0}
    sx={{
      p: 2.5,
      height: "100%",
      border: "1px solid rgba(0,0,0,0.06)",
      borderRadius: 2,
      transition: "all 0.2s ease",
      "&:hover": {
        borderColor: "rgba(134, 188, 37, 0.3)",
        boxShadow: "0 4px 20px rgba(0,0,0,0.06)",
      },
    }}
  >
    <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
      <Box>
        <Typography
          variant="caption"
          sx={{
            color: "#6B778C",
            textTransform: "uppercase",
            letterSpacing: "0.05em",
            fontWeight: 500,
            fontSize: "0.7rem",
          }}
        >
          {title}
        </Typography>
        <Typography
          variant="h4"
          sx={{
            fontWeight: 700,
            color: "#000",
            mt: 0.5,
            mb: 0.25,
          }}
        >
          {value}
        </Typography>
        {subtitle && (
          <Typography variant="caption" sx={{ color: "#6B778C" }}>
            {subtitle}
          </Typography>
        )}
        {trend && (
          <Chip
            size="small"
            icon={<TrendingUpIcon sx={{ fontSize: 12 }} />}
            label={trend}
            sx={{
              mt: 1,
              height: 20,
              bgcolor: "rgba(134, 188, 37, 0.1)",
              color: "#26890D",
              "& .MuiChip-icon": { color: "#26890D" },
              fontSize: "0.7rem",
            }}
          />
        )}
      </Box>
      <Box
        sx={{
          p: 1.25,
          borderRadius: 2,
          bgcolor: `${color}15`,
          color: color,
        }}
      >
        {icon}
      </Box>
    </Box>
  </Paper>
);

// Quick Action Card
const QuickActionCard = ({
  title,
  description,
  icon,
  onClick,
  disabled = false,
  highlight = false,
}: {
  title: string;
  description: string;
  icon: React.ReactNode;
  onClick: () => void;
  disabled?: boolean;
  highlight?: boolean;
}) => (
  <Paper
    elevation={0}
    onClick={disabled ? undefined : onClick}
    sx={{
      p: 2.5,
      cursor: disabled ? "not-allowed" : "pointer",
      border: highlight ? "2px solid #86BC25" : "1px solid rgba(0,0,0,0.06)",
      borderRadius: 2,
      opacity: disabled ? 0.5 : 1,
      transition: "all 0.2s ease",
      bgcolor: highlight ? "rgba(134, 188, 37, 0.03)" : "#fff",
      "&:hover": disabled
        ? {}
        : {
            borderColor: "#86BC25",
            transform: "translateY(-2px)",
            boxShadow: "0 8px 24px rgba(0,0,0,0.08)",
          },
    }}
  >
    <Box sx={{ display: "flex", alignItems: "flex-start", gap: 2 }}>
      <Box
        sx={{
          p: 1.5,
          borderRadius: 2,
          bgcolor: highlight ? "#86BC25" : "rgba(0,0,0,0.04)",
          color: highlight ? "#fff" : "#6B778C",
        }}
      >
        {icon}
      </Box>
      <Box sx={{ flex: 1 }}>
        <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 0.5 }}>
          {title}
        </Typography>
        <Typography variant="caption" sx={{ color: "#6B778C", lineHeight: 1.4 }}>
          {description}
        </Typography>
      </Box>
      <ArrowForwardIcon sx={{ color: highlight ? "#86BC25" : "#D0D0CE", fontSize: 20 }} />
    </Box>
  </Paper>
);

// Activity Item
const ActivityItem = ({
  title,
  time,
  status,
}: {
  title: string;
  time: string;
  status: "completed" | "processing" | "pending";
}) => (
  <Box
    sx={{
      display: "flex",
      alignItems: "center",
      gap: 2,
      py: 1.5,
      borderBottom: "1px solid rgba(0,0,0,0.04)",
      "&:last-child": { borderBottom: "none" },
    }}
  >
    <Box
      sx={{
        width: 8,
        height: 8,
        borderRadius: "50%",
        bgcolor:
          status === "completed"
            ? "#86BC25"
            : status === "processing"
            ? "#ED8B00"
            : "#D0D0CE",
      }}
    />
    <Box sx={{ flex: 1 }}>
      <Typography variant="body2" sx={{ fontWeight: 500 }}>
        {title}
      </Typography>
    </Box>
    <Typography variant="caption" sx={{ color: "#6B778C" }}>
      {time}
    </Typography>
  </Box>
);

export default function DashboardPage() {
  const router = useRouter();
  const [currentDebtor, setCurrentDebtor] = useState<string | null>(null);
  const [stats, setStats] = useState({
    documentsProcessed: 0,
    fieldsExtracted: 0,
    reportsGenerated: 0,
    accuracy: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch current debtor
        const debtorResponse = await fetch(`${backend_url}/get_current_debtor`);
        if (debtorResponse.ok) {
          const debtor = await debtorResponse.json();
          setCurrentDebtor(debtor);
        }

        // Mock stats for demo - in production these would come from backend
        setStats({
          documentsProcessed: currentDebtor ? 12 : 0,
          fieldsExtracted: currentDebtor ? 847 : 0,
          reportsGenerated: currentDebtor ? 3 : 0,
          accuracy: currentDebtor ? 94.2 : 0,
        });
      } catch (error) {
        console.error("Error fetching dashboard data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [currentDebtor]);

  // Recent activity mock data
  const recentActivity = [
    { title: "Financial statements processed", time: "2 min ago", status: "completed" as const },
    { title: "Balance sheet data extracted", time: "5 min ago", status: "completed" as const },
    { title: "P&L analysis in progress", time: "12 min ago", status: "processing" as const },
    { title: "Document upload queued", time: "1 hour ago", status: "pending" as const },
  ];

  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "#F8F9FA",
        p: 3,
      }}
    >
      {/* Header */}
      <Box sx={{ mb: 4 }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <Box>
            <Typography
              variant="h4"
              sx={{
                fontWeight: 700,
                color: "#000",
                mb: 0.5,
              }}
            >
              Welcome to FORTUNA
            </Typography>
            <Typography variant="body1" sx={{ color: "#6B778C" }}>
              AI-powered Credit File Review automation
            </Typography>
          </Box>
          <Tooltip title="Refresh data">
            <IconButton
              onClick={() => window.location.reload()}
              sx={{
                bgcolor: "rgba(0,0,0,0.04)",
                "&:hover": { bgcolor: "rgba(0,0,0,0.08)" },
              }}
            >
              <RefreshIcon />
            </IconButton>
          </Tooltip>
        </Box>

        {/* Current Session Banner */}
        {currentDebtor ? (
          <Paper
            elevation={0}
            sx={{
              mt: 3,
              p: 2.5,
              borderRadius: 2,
              background: "linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%)",
              color: "#fff",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
              <Box
                sx={{
                  width: 48,
                  height: 48,
                  borderRadius: 2,
                  bgcolor: "rgba(134, 188, 37, 0.2)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <FolderOpenIcon sx={{ color: "#86BC25" }} />
              </Box>
              <Box>
                <Typography variant="caption" sx={{ color: "rgba(255,255,255,0.6)" }}>
                  Active Project
                </Typography>
                <Typography variant="h6" sx={{ fontWeight: 600 }}>
                  {currentDebtor}
                </Typography>
              </Box>
            </Box>
            <Button
              variant="contained"
              endIcon={<PlayArrowIcon />}
              onClick={() => router.push("/modules/attributions")}
              sx={{
                bgcolor: "#86BC25",
                color: "#000",
                fontWeight: 600,
                px: 3,
                "&:hover": {
                  bgcolor: "#9acd32",
                },
              }}
            >
              Continue Review
            </Button>
          </Paper>
        ) : (
          <Paper
            elevation={0}
            sx={{
              mt: 3,
              p: 3,
              borderRadius: 2,
              border: "2px dashed rgba(0,0,0,0.1)",
              textAlign: "center",
            }}
          >
            <Typography variant="body1" sx={{ color: "#6B778C", mb: 2 }}>
              No active project. Start by selecting a debtor in Configurations.
            </Typography>
            <Button
              variant="contained"
              onClick={() => router.push("/modules/upload-document")}
              sx={{
                bgcolor: "#86BC25",
                color: "#000",
                fontWeight: 600,
                "&:hover": { bgcolor: "#9acd32" },
              }}
            >
              Get Started
            </Button>
          </Paper>
        )}
      </Box>

      {/* Metrics Row */}
      <Grid container spacing={2.5} sx={{ mb: 4 }}>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard
            title="Documents Processed"
            value={stats.documentsProcessed}
            subtitle="This session"
            icon={<DescriptionOutlinedIcon />}
            color="#007CB0"
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard
            title="Fields Extracted"
            value={stats.fieldsExtracted}
            subtitle="With attributions"
            icon={<CheckCircleOutlineIcon />}
            color="#86BC25"
            trend="+12% accuracy"
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard
            title="Reports Generated"
            value={stats.reportsGenerated}
            subtitle="Ready for download"
            icon={<FolderOpenIcon />}
            color="#26890D"
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}>
          <MetricCard
            title="Extraction Accuracy"
            value={`${stats.accuracy}%`}
            subtitle="Confidence score"
            icon={<TrendingUpIcon />}
            color="#ED8B00"
          />
        </Grid>
      </Grid>

      {/* Main Content Grid */}
      <Grid container spacing={3}>
        {/* Quick Actions */}
        <Grid size={{ xs: 12, md: 8 }}>
          <Paper
            elevation={0}
            sx={{
              p: 3,
              border: "1px solid rgba(0,0,0,0.06)",
              borderRadius: 2,
            }}
          >
            <Typography variant="h6" sx={{ fontWeight: 600, mb: 2.5 }}>
              Quick Actions
            </Typography>
            <Grid container spacing={2}>
              <Grid size={{ xs: 12, sm: 6 }}>
                <QuickActionCard
                  title="Start New Review"
                  description="Select a debtor and begin processing documents"
                  icon={<PlayArrowIcon />}
                  onClick={() => router.push("/modules/upload-document")}
                  highlight={!currentDebtor}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <QuickActionCard
                  title="View Attributions"
                  description="Explore extracted data with source references"
                  icon={<CheckCircleOutlineIcon />}
                  onClick={() => router.push("/modules/attributions")}
                  disabled={!currentDebtor}
                  highlight={!!currentDebtor}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <QuickActionCard
                  title="Preview Report"
                  description="View and download the generated Excel report"
                  icon={<DescriptionOutlinedIcon />}
                  onClick={() => router.push("/modules/report-preview")}
                  disabled={!currentDebtor}
                />
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                <QuickActionCard
                  title="Data Exchanges"
                  description="Manage data imports and exports"
                  icon={<FolderOpenIcon />}
                  onClick={() => router.push("/modules/data-exchanges")}
                />
              </Grid>
            </Grid>
          </Paper>
        </Grid>

        {/* Recent Activity */}
        <Grid size={{ xs: 12, md: 4 }}>
          <Paper
            elevation={0}
            sx={{
              p: 3,
              border: "1px solid rgba(0,0,0,0.06)",
              borderRadius: 2,
              height: "100%",
            }}
          >
            <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2 }}>
              <Typography variant="h6" sx={{ fontWeight: 600 }}>
                Recent Activity
              </Typography>
              <ScheduleIcon sx={{ color: "#D0D0CE", fontSize: 20 }} />
            </Box>
            {currentDebtor ? (
              recentActivity.map((item, index) => (
                <ActivityItem key={index} {...item} />
              ))
            ) : (
              <Box sx={{ py: 4, textAlign: "center" }}>
                <Typography variant="body2" sx={{ color: "#6B778C" }}>
                  No recent activity
                </Typography>
                <Typography variant="caption" sx={{ color: "#A5ADBA" }}>
                  Start a review to see activity here
                </Typography>
              </Box>
            )}
          </Paper>
        </Grid>

        {/* Workflow Progress */}
        <Grid size={{ xs: 12 }}>
          <Paper
            elevation={0}
            sx={{
              p: 3,
              border: "1px solid rgba(0,0,0,0.06)",
              borderRadius: 2,
            }}
          >
            <Typography variant="h6" sx={{ fontWeight: 600, mb: 3 }}>
              CFR Workflow Progress
            </Typography>
            <Box sx={{ display: "flex", gap: 2 }}>
              {[
                { step: 1, label: "Configuration", status: currentDebtor ? "complete" : "current" },
                { step: 2, label: "Document Processing", status: currentDebtor ? "complete" : "pending" },
                { step: 3, label: "Data Extraction", status: currentDebtor ? "current" : "pending" },
                { step: 4, label: "Report Generation", status: "pending" },
                { step: 5, label: "Review & Export", status: "pending" },
              ].map((item, index) => (
                <Box key={item.step} sx={{ flex: 1, position: "relative" }}>
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                    }}
                  >
                    <Box
                      sx={{
                        width: 40,
                        height: 40,
                        borderRadius: "50%",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        bgcolor:
                          item.status === "complete"
                            ? "#86BC25"
                            : item.status === "current"
                            ? "#007CB0"
                            : "#E6E6E6",
                        color: item.status === "pending" ? "#6B778C" : "#fff",
                        fontWeight: 600,
                        fontSize: "0.9rem",
                        position: "relative",
                        zIndex: 1,
                      }}
                    >
                      {item.status === "complete" ? "✓" : item.step}
                    </Box>
                    <Typography
                      variant="caption"
                      sx={{
                        mt: 1,
                        color: item.status === "pending" ? "#A5ADBA" : "#000",
                        fontWeight: item.status === "current" ? 600 : 400,
                        textAlign: "center",
                      }}
                    >
                      {item.label}
                    </Typography>
                  </Box>
                  {/* Connector line */}
                  {index < 4 && (
                    <Box
                      sx={{
                        position: "absolute",
                        top: 20,
                        left: "calc(50% + 20px)",
                        right: "calc(-50% + 20px)",
                        height: 2,
                        bgcolor: item.status === "complete" ? "#86BC25" : "#E6E6E6",
                        zIndex: 0,
                      }}
                    />
                  )}
                </Box>
              ))}
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}
