"use client";

import React, { useState, useEffect } from "react";
import { Box } from "@mui/material";
import PageHeader from "@/components/PageHeader";
import TemplateSelections from "./templateSelections";
import DocumentsList from "./documentsList";
import { backend_url } from "@/config";

export default function ConfigurationsPage() {
  const [documentsInformation, setDocumentsInformation] = useState<any>(null);
  const [tableLoading, setTableLoading] = useState(false);
  const [documentTypeOptions, setDocumentTypeOptions] = useState<any>([]);
  const [debtorIdValue, setDebtorIdValue] = useState<string>("None");
  const [currentDebtor, setCurrentDebtor] = useState<string | null>(null);

  useEffect(() => {
    const fetchCurrentDebtor = async () => {
      try {
        const response = await fetch(`${backend_url}/get_current_debtor`);
        if (response.ok) {
          const data = await response.json();
          setCurrentDebtor(data);
        }
      } catch (error) {
        console.error("Error fetching current debtor:", error);
      }
    };
    fetchCurrentDebtor();
  }, []);

  return (
    <Box
      sx={{
        padding: "24px 32px",
        minHeight: "calc(100vh - 48px)",
        backgroundColor: "#F8F9FA",
      }}
    >
      <PageHeader
        title="Configurations"
        subtitle="Select a template and debtor to begin processing documents"
        currentDebtor={currentDebtor}
        showDebtorBadge={true}
      />

      <Box
        sx={{
          backgroundColor: "#FFFFFF",
          borderRadius: 2,
          border: "1px solid rgba(0,0,0,0.06)",
          padding: "24px",
          mb: 3,
        }}
      >
        <TemplateSelections
          setDocumentsInformation={setDocumentsInformation}
          setDocumentTypeOptions={setDocumentTypeOptions}
        />
      </Box>

      <DocumentsList
        DocumentsInformation={documentsInformation}
        DocumentTypeOptions={documentTypeOptions}
        TableLoading={tableLoading}
        DebtorIdValue={debtorIdValue}
      />
    </Box>
  );
}
