"use client";

import React, { useState, useContext, createContext, useEffect } from "react";
import {
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Button,
  Table,
  TableCell,
  TableBody,
  TableRow,
  TableHead,
  Tooltip,
  Box,
  Chip,
  IconButton,
  Paper,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import UnfoldMoreIcon from "@mui/icons-material/UnfoldMore";
import UnfoldLessIcon from "@mui/icons-material/UnfoldLess";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import CircularLoader from "@/ui/circularLoader";
import { AgentLogsContext } from "@/contexts/AgentLogsContext";

interface ExpandContextType {
  manualExpanded: Record<string, boolean>;
  setManualExpanded: React.Dispatch<React.SetStateAction<Record<string, boolean>>>;
  setCurrentExpandedLevel: React.Dispatch<React.SetStateAction<number>>;
}

const ExpandContext = createContext<ExpandContextType | null>(null);

interface RecursiveAccordionProps {
  data: Record<string, any>;
  level: number;
  onClick: (index: number | null, path: string[]) => void;
  path?: string[];
}

// Styled components for better visuals
const StyledAccordion = styled(Accordion)(({ theme }) => ({
  marginBottom: 6,
  borderRadius: "8px !important",
  border: "1px solid rgba(0, 0, 0, 0.06)",
  boxShadow: "none",
  "&:before": { display: "none" },
  "&.Mui-expanded": {
    margin: "0 0 6px 0",
  },
  transition: "all 0.15s ease",
  "&:hover": {
    borderColor: "rgba(134, 188, 37, 0.3)",
  },
}));

const StyledAccordionSummary = styled(AccordionSummary)(({ theme }) => ({
  minHeight: 44,
  padding: "0 12px",
  "& .MuiAccordionSummary-content": {
    margin: "10px 0",
    alignItems: "center",
  },
  "& .MuiAccordionSummary-expandIconWrapper": {
    color: "#86BC25",
  },
}));

// Format field value with better display
const FieldValueDisplay = ({ fieldKey, value }: { fieldKey: string; value: any }) => {
  if (typeof value !== "object" || value === null) {
    return (
      <Box sx={{ py: 0.5 }}>
        <Typography variant="body2" component="span" sx={{ fontWeight: 500, color: "#000" }}>
          {fieldKey}:
        </Typography>{" "}
        <Typography variant="body2" component="span" sx={{ color: "#26890D", fontWeight: 600 }}>
          {String(value).replace(/['"[\]]/g, "")}
        </Typography>
      </Box>
    );
  }

  // Handle object values with Value, Sources, Page Numbers, Explanation
  const displayValue = value.Value || value.value || value;
  const sources = value.Sources || value.sources || value.Source || [];
  const pageNumbers = value["Page Numbers"] || value.page_numbers || value.Pages || [];
  const explanation = value.Explanation || value.explanation || "";

  return (
    <Paper
      elevation={0}
      sx={{
        p: 1.5,
        mb: 1,
        bgcolor: "#FAFBFC",
        border: "1px solid rgba(0,0,0,0.04)",
        borderRadius: 1.5,
      }}
    >
      <Box sx={{ display: "flex", alignItems: "flex-start", gap: 2 }}>
        <Box sx={{ flex: 1 }}>
          <Typography variant="caption" sx={{ color: "#6B778C", fontWeight: 500 }}>
            {fieldKey}
          </Typography>
          <Typography variant="body1" sx={{ fontWeight: 600, color: "#000", mt: 0.25 }}>
            {typeof displayValue === "object"
              ? JSON.stringify(displayValue)
              : String(displayValue).replace(/['"[\]]/g, "")}
          </Typography>
        </Box>
      </Box>

      {/* Source Attribution Row */}
      {(sources.length > 0 || pageNumbers.length > 0) && (
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1,
            mt: 1,
            pt: 1,
            borderTop: "1px dashed rgba(0,0,0,0.08)",
            flexWrap: "wrap",
          }}
        >
          {Array.isArray(sources) && sources.length > 0 && (
            <>
              <DescriptionOutlinedIcon sx={{ fontSize: 14, color: "#007CB0" }} />
              {sources.map((src: string, idx: number) => (
                <Chip
                  key={idx}
                  label={String(src).replace(/['"[\]]/g, "")}
                  size="small"
                  sx={{
                    height: 22,
                    bgcolor: "rgba(0, 124, 176, 0.08)",
                    color: "#007CB0",
                    fontSize: "0.7rem",
                    fontWeight: 500,
                  }}
                />
              ))}
            </>
          )}
          {Array.isArray(pageNumbers) && pageNumbers.length > 0 && (
            <Chip
              label={`Page ${pageNumbers.join(", ")}`}
              size="small"
              sx={{
                height: 22,
                bgcolor: "rgba(38, 137, 13, 0.08)",
                color: "#26890D",
                fontSize: "0.7rem",
                fontWeight: 500,
              }}
            />
          )}
        </Box>
      )}

      {/* Explanation */}
      {explanation && (
        <Typography
          variant="caption"
          sx={{
            display: "block",
            mt: 1,
            color: "#6B778C",
            fontStyle: "italic",
            lineHeight: 1.4,
          }}
        >
          {String(explanation).replace(/['"[\]]/g, "")}
        </Typography>
      )}
    </Paper>
  );
};

function RecursiveAccordion({ data, level, onClick, path = [] }: RecursiveAccordionProps) {
  const context = useContext(ExpandContext);
  if (!context) return null;

  const { manualExpanded, setManualExpanded, setCurrentExpandedLevel } = context;

  const keyWords = ["current liabilities", "non-current liabilities", "current assets", "equity"];
  const currentPath = path.join("/");

  const handleToggle = (key: string) => {
    const newPath = `${currentPath}/${key}`;
    setManualExpanded((prev) => ({
      ...prev,
      [newPath]: !prev[newPath],
    }));

    const newLevel = path.length;
    setCurrentExpandedLevel(newLevel);
    onClick(null, [...path, key]);
  };

  // Level 4+: Render as formatted table/cards
  if (level >= 4) {
    const tableColumns: string[] = [];
    const firstItem = Object.values(data)[0];

    if (typeof firstItem === "object" && firstItem !== null) {
      tableColumns.push(...Object.keys(firstItem));

      return (
        <Box sx={{ mt: 1 }}>
          {Object.entries(data).map(([rowKey, rowValue]: [string, any], rowIndex) => (
            <FieldValueDisplay key={rowIndex} fieldKey={rowKey} value={rowValue} />
          ))}
        </Box>
      );
    }
  }

  // Level indicator colors
  const getLevelColor = (lvl: number) => {
    const colors = ["#1a1a1a", "#26890D", "#007CB0", "#ED8B00"];
    return colors[lvl % colors.length];
  };

  return (
    <Box>
      {Object.entries(data).map(([key, value], i) =>
        typeof value === "object" && value !== null ? (
          <StyledAccordion
            key={i}
            expanded={manualExpanded[`${currentPath}/${key}`] || false}
            onChange={() => handleToggle(key)}
          >
            <StyledAccordionSummary expandIcon={<ExpandMoreIcon />}>
              <Box
                sx={{
                  width: 4,
                  height: 20,
                  borderRadius: 1,
                  bgcolor: getLevelColor(level),
                  mr: 1.5,
                }}
              />
              <Typography variant="body2" sx={{ fontWeight: 600, flex: 1 }}>
                {key}
              </Typography>
              <Chip
                label={`${Object.keys(value).length} items`}
                size="small"
                sx={{
                  height: 20,
                  fontSize: "0.65rem",
                  bgcolor: "rgba(0,0,0,0.04)",
                  color: "#6B778C",
                  mr: 1,
                }}
              />
            </StyledAccordionSummary>
            <AccordionDetails sx={{ pt: 0, pb: 1.5, px: 2 }}>
              <RecursiveAccordion
                data={value}
                level={level + 1}
                onClick={onClick}
                path={[...path, key]}
              />
            </AccordionDetails>
          </StyledAccordion>
        ) : (
          <FieldValueDisplay key={i} fieldKey={key} value={value} />
        )
      )}
    </Box>
  );
}

interface AgentAccordionWithButtonProps {
  onClick: (index: number | null, path: string[]) => void;
  path?: string[];
  filterCategory?: string | null;
}

export default function AgentAccordionWithButton({
  onClick,
  path = [],
  filterCategory = null,
}: AgentAccordionWithButtonProps) {
  const [currentExpandedLevel, setCurrentExpandedLevel] = useState(-1);
  const [manualExpanded, setManualExpanded] = useState<Record<string, boolean>>({});
  const { logs: AgentLogs, logsLoading } = useContext(AgentLogsContext);

  // Auto-expand first two levels on mount
  useEffect(() => {
    if (AgentLogs && typeof AgentLogs === "object" && Object.keys(AgentLogs).length > 0) {
      const initialExpanded: Record<string, boolean> = {};
      
      // Expand level 0
      Object.keys(AgentLogs).forEach((key) => {
        initialExpanded[`/${key}`] = true;
        
        // Expand level 1
        const level1Value = (AgentLogs as Record<string, any>)[key];
        if (typeof level1Value === "object" && level1Value !== null) {
          Object.keys(level1Value).forEach((subKey) => {
            initialExpanded[`/${key}/${subKey}`] = true;
          });
        }
      });
      
      setManualExpanded(initialExpanded);
      setCurrentExpandedLevel(1);
    }
  }, [AgentLogs]);

  if (logsLoading) {
    return <CircularLoader open={logsLoading} />;
  }

  // Check if logs exist
  const hasLogs =
    AgentLogs &&
    typeof AgentLogs === "object" &&
    !Array.isArray(AgentLogs) &&
    Object.keys(AgentLogs).length > 0;

  if (!hasLogs) {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          height: "100%",
          minHeight: "300px",
          color: "#6B778C",
        }}
      >
        <Box
          sx={{
            width: 56,
            height: 56,
            borderRadius: 2,
            bgcolor: "#E6E6E6",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            mb: 2,
          }}
        >
          <DescriptionOutlinedIcon sx={{ fontSize: 28, color: "#A5ADBA" }} />
        </Box>
        <Typography variant="body1" sx={{ fontWeight: 500, mb: 0.5 }}>
          No extraction data available
        </Typography>
        <Typography variant="body2" sx={{ color: "#A5ADBA", textAlign: "center" }}>
          Process documents in Configurations to view extracted fields
        </Typography>
      </Box>
    );
  }

  const handleExpandAll = () => {
    setCurrentExpandedLevel((prevLevel) => {
      const nextLevel = prevLevel + 1;
      const isLastLevel = nextLevel >= 4;

      setManualExpanded((prev) => {
        const updateState = (
          logs: Record<string, any>,
          currentPath: string[],
          level: number,
          currentLevel = 0
        ): Record<string, boolean> => {
          const newState: Record<string, boolean> = {};

          Object.entries(logs).forEach(([key, value]) => {
            const newPath = `${currentPath.join("/")}/${key}`;
            if (currentLevel === level || level === -1) {
              newState[newPath] = true;
            }
            if (typeof value === "object" && value !== null) {
              Object.assign(
                newState,
                updateState(value, [...currentPath, key], level, currentLevel + 1)
              );
            }
          });

          return newState;
        };

        return {
          ...prev,
          ...updateState(AgentLogs, path, isLastLevel ? -1 : nextLevel),
        };
      });

      return isLastLevel ? prevLevel : nextLevel;
    });
  };

  const handleCollapseAll = () => {
    setManualExpanded((prev) => {
      const updateState = (
        logs: Record<string, any>,
        currentPath: string[],
        level: number,
        currentLevel = 0
      ): Record<string, boolean> => {
        const newState: Record<string, boolean> = {};

        Object.entries(logs).forEach(([key, value]) => {
          const newPath = `${currentPath.join("/")}/${key}`;
          if (currentLevel === level) {
            newState[newPath] = false;
          }
          if (typeof value === "object" && value !== null) {
            Object.assign(
              newState,
              updateState(value, [...currentPath, key], level, currentLevel + 1)
            );
          }
        });

        return newState;
      };

      return {
        ...prev,
        ...updateState(AgentLogs, path, currentExpandedLevel),
      };
    });

    setCurrentExpandedLevel((prev) => Math.max(prev - 1, 0));
  };

  // Depth indicator
  const depthLabels = ["Categories", "Sections", "Fields", "Details"];

  return (
    <Box>
      {/* Expand/Collapse Controls - Improved Design */}
      <Paper
        elevation={0}
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 2,
          mb: 2,
          p: 1.5,
          bgcolor: "#FFFFFF",
          border: "1px solid rgba(0,0,0,0.06)",
          borderRadius: 2,
        }}
      >
        <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
          <Typography variant="caption" sx={{ color: "#6B778C", fontWeight: 500 }}>
            Expand depth:
          </Typography>
          <Box sx={{ display: "flex", gap: 0.5 }}>
            {depthLabels.map((label, idx) => (
              <Chip
                key={label}
                label={label}
                size="small"
                sx={{
                  height: 24,
                  fontSize: "0.7rem",
                  bgcolor: idx <= currentExpandedLevel ? "#86BC25" : "rgba(0,0,0,0.04)",
                  color: idx <= currentExpandedLevel ? "#000" : "#6B778C",
                  fontWeight: idx <= currentExpandedLevel ? 600 : 400,
                  transition: "all 0.2s ease",
                }}
              />
            ))}
          </Box>
        </Box>
        <Box sx={{ display: "flex", gap: 1 }}>
          <Tooltip title="Expand one level">
            <Button
              onClick={handleExpandAll}
              variant="outlined"
              size="small"
              startIcon={<UnfoldMoreIcon sx={{ fontSize: 18 }} />}
              sx={{
                minWidth: 100,
                borderColor: "#86BC25",
                color: "#26890D",
                fontWeight: 600,
                fontSize: "0.75rem",
                "&:hover": {
                  borderColor: "#26890D",
                  bgcolor: "rgba(134, 188, 37, 0.04)",
                },
              }}
            >
              Expand
            </Button>
          </Tooltip>
          <Tooltip title="Collapse one level">
            <Button
              onClick={handleCollapseAll}
              variant="outlined"
              size="small"
              startIcon={<UnfoldLessIcon sx={{ fontSize: 18 }} />}
              sx={{
                minWidth: 100,
                borderColor: "#D0D0CE",
                color: "#6B778C",
                fontWeight: 600,
                fontSize: "0.75rem",
                "&:hover": {
                  borderColor: "#A5ADBA",
                  bgcolor: "rgba(0,0,0,0.02)",
                },
              }}
            >
              Collapse
            </Button>
          </Tooltip>
        </Box>
      </Paper>

      {/* Accordion Tree */}
      <ExpandContext.Provider
        value={{ manualExpanded, setManualExpanded, setCurrentExpandedLevel }}
      >
        <RecursiveAccordion data={AgentLogs} level={0} onClick={onClick} />
      </ExpandContext.Provider>
    </Box>
  );
}
