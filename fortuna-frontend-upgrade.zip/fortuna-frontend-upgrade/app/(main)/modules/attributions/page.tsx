"use client";

import React, { useState, useEffect, useContext } from "react";
import {
  Typography,
  Box,
  Button,
  Paper,
  IconButton,
  Tooltip,
  Chip,
  Tabs,
  Tab,
} from "@mui/material";
import { Panel, PanelGroup, PanelResizeHandle } from "react-resizable-panels";
import PageHeader from "@/components/PageHeader";
import ChatPanel from "@/components/ChatPanel";
import CircularLoader from "@/ui/circularLoader";
import AgentAccordionWithButton from "./agentLogs";
import { backend_url } from "@/config";
import DownloadIcon from "@mui/icons-material/Download";
import RefreshIcon from "@mui/icons-material/Refresh";
import FilterListIcon from "@mui/icons-material/FilterList";
import { AgentLogsContext } from "@/contexts/AgentLogsContext";

const loadingMessages = ["Preparing the report for download..."];

export default function AttributionsPage() {
  const [loading, setLoading] = useState(false);
  const [messageIndex, setMessageIndex] = useState(0);
  const [currentDebtor, setCurrentDebtor] = useState<string | null>(null);
  const [hasProcessedData, setHasProcessedData] = useState(false);
  const [activeTab, setActiveTab] = useState(0);
  const { fetchAgentLogs, logsLoading } = useContext(AgentLogsContext);

  useEffect(() => {
    const fetchCurrentDebtor = async () => {
      try {
        const response = await fetch(`${backend_url}/get_current_debtor`);
        if (response.ok) {
          const data = await response.json();
          setCurrentDebtor(data);
          setHasProcessedData(!!data);
        } else {
          setCurrentDebtor(null);
          setHasProcessedData(false);
        }
      } catch (error) {
        console.error("Error fetching current debtor:", error);
        setCurrentDebtor(null);
        setHasProcessedData(false);
      }
    };
    fetchCurrentDebtor();
  }, []);

  const handleRefreshLogs = async () => {
    await fetchAgentLogs();
  };

  const handleDownload = async () => {
    try {
      setLoading(true);
      const response = await fetch(`${backend_url}/download_report`);

      if (!response.ok) {
        throw new Error("Download failed");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${currentDebtor}_Filled_Template.xlsx`;
      document.body.appendChild(link);
      link.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(link);
      setLoading(false);
    } catch (error) {
      console.error("Download error:", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!loading) {
      setMessageIndex(0);
      return;
    }

    const interval = setInterval(() => {
      setMessageIndex((prev) => {
        if (prev >= loadingMessages.length - 1) {
          clearInterval(interval);
          return prev;
        }
        return prev + 1;
      });
    }, 10000);

    return () => clearInterval(interval);
  }, [loading]);

  // Tab labels for different data categories
  const categoryTabs = [
    { label: "All Fields", count: null },
    { label: "Assets", count: null },
    { label: "Liabilities", count: null },
    { label: "Equity", count: null },
    { label: "P&L", count: null },
  ];

  return (
    <Box
      sx={{
        padding: "20px 24px",
        minHeight: "calc(100vh - 48px)",
        backgroundColor: "#F8F9FA",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <PageHeader
        title="Attributions"
        subtitle="Explore extracted data with full source traceability"
        currentDebtor={currentDebtor}
        showDebtorBadge={true}
      />

      {/* Category Filter Tabs */}
      <Paper
        elevation={0}
        sx={{
          mb: 2,
          border: "1px solid rgba(0,0,0,0.06)",
          borderRadius: 2,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            px: 2,
            py: 0.5,
            bgcolor: "#FAFBFC",
            borderBottom: "1px solid rgba(0,0,0,0.06)",
          }}
        >
          <Tabs
            value={activeTab}
            onChange={(_, newValue) => setActiveTab(newValue)}
            sx={{
              minHeight: 40,
              "& .MuiTab-root": {
                minHeight: 40,
                textTransform: "none",
                fontWeight: 500,
                fontSize: "0.8rem",
                color: "#6B778C",
                "&.Mui-selected": {
                  color: "#26890D",
                  fontWeight: 600,
                },
              },
              "& .MuiTabs-indicator": {
                backgroundColor: "#86BC25",
                height: 2,
              },
            }}
          >
            {categoryTabs.map((tab) => (
              <Tab
                key={tab.label}
                label={
                  <Box sx={{ display: "flex", alignItems: "center", gap: 0.75 }}>
                    {tab.label}
                    {tab.count && (
                      <Chip
                        label={tab.count}
                        size="small"
                        sx={{
                          height: 18,
                          fontSize: "0.65rem",
                          bgcolor: "rgba(38, 137, 13, 0.1)",
                          color: "#26890D",
                        }}
                      />
                    )}
                  </Box>
                }
              />
            ))}
          </Tabs>
          <Box sx={{ display: "flex", gap: 1 }}>
            <Tooltip title="Filter fields">
              <IconButton size="small" sx={{ color: "#6B778C" }}>
                <FilterListIcon fontSize="small" />
              </IconButton>
            </Tooltip>
            <Tooltip title="Refresh data">
              <IconButton
                size="small"
                onClick={handleRefreshLogs}
                disabled={logsLoading}
                sx={{ color: "#6B778C" }}
              >
                <RefreshIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Box>
        </Box>
      </Paper>

      {/* Main Content Area */}
      <Box
        sx={{
          flex: 1,
          display: "flex",
          gap: "16px",
          minHeight: "calc(100vh - 280px)",
        }}
      >
        <PanelGroup direction="horizontal" autoSaveId="attributions-panels">
          {/* Main Workspace Panel */}
          <Panel defaultSize={65} minSize={40}>
            <Paper
              elevation={0}
              sx={{
                height: "100%",
                display: "flex",
                flexDirection: "column",
                border: "1px solid rgba(0, 0, 0, 0.06)",
                borderRadius: 2,
                overflow: "hidden",
              }}
            >
              {/* Workspace Header */}
              <Box
                sx={{
                  px: 2.5,
                  py: 1.5,
                  borderBottom: "1px solid rgba(0, 0, 0, 0.06)",
                  bgcolor: "#FFFFFF",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                }}
              >
                <Box>
                  <Typography variant="subtitle1" sx={{ fontWeight: 600, fontSize: "0.95rem" }}>
                    Extraction Results
                  </Typography>
                  <Typography variant="caption" sx={{ color: "#6B778C" }}>
                    Click any field to view source attribution and page references
                  </Typography>
                </Box>
                <Chip
                  label={hasProcessedData ? "Data loaded" : "No data"}
                  size="small"
                  sx={{
                    bgcolor: hasProcessedData
                      ? "rgba(134, 188, 37, 0.1)"
                      : "rgba(0,0,0,0.05)",
                    color: hasProcessedData ? "#26890D" : "#6B778C",
                    fontWeight: 500,
                    fontSize: "0.7rem",
                  }}
                />
              </Box>

              {/* Scrollable Content */}
              <Box
                sx={{
                  flex: 1,
                  overflow: "auto",
                  p: 2,
                  bgcolor: "#FAFBFC",
                }}
              >
                {currentDebtor ? (
                  <AgentAccordionWithButton
                    onClick={() => {}}
                    filterCategory={activeTab === 0 ? null : categoryTabs[activeTab].label.toLowerCase()}
                  />
                ) : (
                  <Box
                    sx={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      justifyContent: "center",
                      height: "100%",
                      color: "#6B778C",
                      py: 8,
                    }}
                  >
                    <Box
                      sx={{
                        width: 64,
                        height: 64,
                        borderRadius: 3,
                        bgcolor: "#E6E6E6",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        mb: 2,
                      }}
                    >
                      <Typography sx={{ fontSize: 28, fontWeight: 700, color: "#A5ADBA" }}>
                        ?
                      </Typography>
                    </Box>
                    <Typography variant="body1" sx={{ fontWeight: 500, mb: 0.5 }}>
                      No extraction data available
                    </Typography>
                    <Typography variant="body2" sx={{ color: "#A5ADBA", textAlign: "center" }}>
                      Process documents in Configurations to view attributions
                    </Typography>
                  </Box>
                )}
              </Box>
            </Paper>
          </Panel>

          {/* Resize Handle */}
          <PanelResizeHandle
            style={{
              width: "8px",
              background: "transparent",
              cursor: "col-resize",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Box
              sx={{
                width: "3px",
                height: "48px",
                bgcolor: "#E6E6E6",
                borderRadius: "2px",
                transition: "all 0.2s",
                "&:hover": {
                  bgcolor: "#86BC25",
                  height: "64px",
                },
              }}
            />
          </PanelResizeHandle>

          {/* Chat Panel */}
          <Panel defaultSize={35} minSize={25}>
            <ChatPanel
              title="Fortuna Assistant"
              placeholder="Ask about extractions, sources, or methodology..."
              welcomeMessage="I can help you understand the extracted data. Ask me about specific fields, their source documents, page references, or how the extraction agents work."
              disabled={!hasProcessedData}
              disabledMessage="Process documents to enable the assistant"
              mode="attributions"
            />
          </Panel>
        </PanelGroup>
      </Box>

      {/* Fixed Download Button - Bottom Right */}
      <Box
        sx={{
          position: "fixed",
          bottom: 24,
          right: 24,
          zIndex: 1000,
        }}
      >
        <Tooltip title={currentDebtor ? "Download Excel report" : "No data to download"}>
          <span>
            <Button
              variant="contained"
              onClick={handleDownload}
              disabled={!currentDebtor || loading}
              startIcon={<DownloadIcon />}
              sx={{
                bgcolor: "#1a1a1a",
                color: "#fff",
                fontWeight: 600,
                px: 3,
                py: 1.25,
                borderRadius: 2,
                boxShadow: "0 4px 14px rgba(0,0,0,0.25)",
                "&:hover": {
                  bgcolor: "#2d2d2d",
                  boxShadow: "0 6px 20px rgba(0,0,0,0.3)",
                },
                "&:disabled": {
                  bgcolor: "#E6E6E6",
                  color: "#A5ADBA",
                },
              }}
            >
              Download Report
            </Button>
          </span>
        </Tooltip>
      </Box>

      {loading && (
        <CircularLoader open={loading} loadingMessage={loadingMessages[messageIndex]} />
      )}
    </Box>
  );
}
