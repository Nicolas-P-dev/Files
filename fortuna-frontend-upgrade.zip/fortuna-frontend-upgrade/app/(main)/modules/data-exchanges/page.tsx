"use client";

import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Paper,
  Button,
  Chip,
  IconButton,
  Tooltip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  LinearProgress,
  Alert,
} from "@mui/material";
import Grid from "@mui/material/Grid2";
import PageHeader from "@/components/PageHeader";
import { backend_url } from "@/config";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import CloudDownloadIcon from "@mui/icons-material/CloudDownload";
import FolderOpenIcon from "@mui/icons-material/FolderOpen";
import RefreshIcon from "@mui/icons-material/Refresh";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ErrorIcon from "@mui/icons-material/Error";
import ScheduleIcon from "@mui/icons-material/Schedule";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";

interface DataExchange {
  id: string;
  name: string;
  type: "import" | "export";
  status: "completed" | "processing" | "failed" | "pending";
  timestamp: string;
  size: string;
  source?: string;
}

// Status icon component
const StatusIcon = ({ status }: { status: string }) => {
  switch (status) {
    case "completed":
      return <CheckCircleIcon sx={{ color: "#86BC25", fontSize: 18 }} />;
    case "processing":
      return <ScheduleIcon sx={{ color: "#ED8B00", fontSize: 18 }} />;
    case "failed":
      return <ErrorIcon sx={{ color: "#DA291C", fontSize: 18 }} />;
    default:
      return <ScheduleIcon sx={{ color: "#A5ADBA", fontSize: 18 }} />;
  }
};

// Action Card Component
const ActionCard = ({
  title,
  description,
  icon,
  buttonText,
  onClick,
  disabled = false,
  highlight = false,
}: {
  title: string;
  description: string;
  icon: React.ReactNode;
  buttonText: string;
  onClick: () => void;
  disabled?: boolean;
  highlight?: boolean;
}) => (
  <Paper
    elevation={0}
    sx={{
      p: 3,
      height: "100%",
      border: highlight ? "2px solid #86BC25" : "1px solid rgba(0,0,0,0.06)",
      borderRadius: 2,
      bgcolor: highlight ? "rgba(134, 188, 37, 0.02)" : "#fff",
      transition: "all 0.2s ease",
      "&:hover": {
        borderColor: "rgba(134, 188, 37, 0.5)",
        boxShadow: "0 4px 12px rgba(0,0,0,0.06)",
      },
    }}
  >
    <Box
      sx={{
        width: 48,
        height: 48,
        borderRadius: 2,
        bgcolor: highlight ? "#86BC25" : "rgba(0,0,0,0.04)",
        color: highlight ? "#000" : "#6B778C",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        mb: 2,
      }}
    >
      {icon}
    </Box>
    <Typography variant="h6" sx={{ fontWeight: 600, mb: 1 }}>
      {title}
    </Typography>
    <Typography variant="body2" sx={{ color: "#6B778C", mb: 3, minHeight: 40 }}>
      {description}
    </Typography>
    <Button
      variant={highlight ? "contained" : "outlined"}
      onClick={onClick}
      disabled={disabled}
      sx={{
        bgcolor: highlight ? "#86BC25" : "transparent",
        color: highlight ? "#000" : "#26890D",
        borderColor: "#86BC25",
        fontWeight: 600,
        "&:hover": {
          bgcolor: highlight ? "#9acd32" : "rgba(134, 188, 37, 0.04)",
          borderColor: "#26890D",
        },
      }}
    >
      {buttonText}
    </Button>
  </Paper>
);

export default function DataExchangesPage() {
  const [currentDebtor, setCurrentDebtor] = useState<string | null>(null);
  const [exchanges, setExchanges] = useState<DataExchange[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(`${backend_url}/get_current_debtor`);
        if (response.ok) {
          const data = await response.json();
          setCurrentDebtor(data);
        }
      } catch (error) {
        console.error("Error fetching current debtor:", error);
      }
    };
    fetchData();

    // Mock exchange history for demo
    setExchanges([
      {
        id: "1",
        name: "Financial_Statements_2023.pdf",
        type: "import",
        status: "completed",
        timestamp: "2024-01-15 14:32",
        size: "2.4 MB",
        source: "Local Upload",
      },
      {
        id: "2",
        name: "Annual_Report_2023.pdf",
        type: "import",
        status: "completed",
        timestamp: "2024-01-15 14:30",
        size: "8.1 MB",
        source: "Local Upload",
      },
      {
        id: "3",
        name: "CFR_Report_Demo_Debtor.xlsx",
        type: "export",
        status: "completed",
        timestamp: "2024-01-15 15:45",
        size: "156 KB",
      },
      {
        id: "4",
        name: "Management_Accounts_Q4.pdf",
        type: "import",
        status: "processing",
        timestamp: "2024-01-15 16:00",
        size: "1.2 MB",
        source: "Azure Blob",
      },
    ]);
  }, []);

  const handleImportFromDirectory = () => {
    // This would open a file dialog or directory picker
    alert("This feature allows pointing FORTUNA to a directory for document ingestion. Integration pending.");
  };

  const handleExportToAzure = () => {
    alert("Export to Azure Blob Storage. Integration pending.");
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "#F8F9FA",
        p: 3,
      }}
    >
      <PageHeader
        title="Data Exchanges"
        subtitle="Manage document imports and report exports"
        currentDebtor={currentDebtor}
        showDebtorBadge={true}
      />

      {/* Action Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid size={{ xs: 12, md: 4 }}>
          <ActionCard
            title="Import from Directory"
            description="Point FORTUNA to a local or network directory to automatically ingest documents"
            icon={<FolderOpenIcon />}
            buttonText="Select Directory"
            onClick={handleImportFromDirectory}
            highlight
          />
        </Grid>
        <Grid size={{ xs: 12, md: 4 }}>
          <ActionCard
            title="Upload Documents"
            description="Upload individual files directly through the Configurations page"
            icon={<CloudUploadIcon />}
            buttonText="Go to Configurations"
            onClick={() => window.location.href = "/modules/upload-document"}
          />
        </Grid>
        <Grid size={{ xs: 12, md: 4 }}>
          <ActionCard
            title="Export to Cloud"
            description="Export generated reports to Azure Blob Storage or other cloud destinations"
            icon={<CloudDownloadIcon />}
            buttonText="Configure Export"
            onClick={handleExportToAzure}
            disabled={!currentDebtor}
          />
        </Grid>
      </Grid>

      {/* Exchange History */}
      <Paper
        elevation={0}
        sx={{
          border: "1px solid rgba(0,0,0,0.06)",
          borderRadius: 2,
          overflow: "hidden",
        }}
      >
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            px: 3,
            py: 2,
            borderBottom: "1px solid rgba(0,0,0,0.06)",
            bgcolor: "#FAFBFC",
          }}
        >
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            Exchange History
          </Typography>
          <Tooltip title="Refresh">
            <IconButton size="small">
              <RefreshIcon />
            </IconButton>
          </Tooltip>
        </Box>

        <TableContainer>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell sx={{ fontWeight: 600, bgcolor: "#F5F7F9" }}>File Name</TableCell>
                <TableCell sx={{ fontWeight: 600, bgcolor: "#F5F7F9" }}>Type</TableCell>
                <TableCell sx={{ fontWeight: 600, bgcolor: "#F5F7F9" }}>Source/Dest</TableCell>
                <TableCell sx={{ fontWeight: 600, bgcolor: "#F5F7F9" }}>Size</TableCell>
                <TableCell sx={{ fontWeight: 600, bgcolor: "#F5F7F9" }}>Timestamp</TableCell>
                <TableCell sx={{ fontWeight: 600, bgcolor: "#F5F7F9" }}>Status</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {exchanges.map((exchange) => (
                <TableRow
                  key={exchange.id}
                  sx={{
                    "&:hover": { bgcolor: "rgba(134, 188, 37, 0.04)" },
                  }}
                >
                  <TableCell>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                      <DescriptionOutlinedIcon sx={{ color: "#6B778C", fontSize: 18 }} />
                      <Typography variant="body2" sx={{ fontWeight: 500 }}>
                        {exchange.name}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={exchange.type === "import" ? "Import" : "Export"}
                      size="small"
                      sx={{
                        bgcolor: exchange.type === "import"
                          ? "rgba(0, 124, 176, 0.1)"
                          : "rgba(134, 188, 37, 0.1)",
                        color: exchange.type === "import" ? "#007CB0" : "#26890D",
                        fontWeight: 500,
                        fontSize: "0.7rem",
                      }}
                    />
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" sx={{ color: "#6B778C" }}>
                      {exchange.source || "Generated Report"}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2">{exchange.size}</Typography>
                  </TableCell>
                  <TableCell>
                    <Typography variant="body2" sx={{ color: "#6B778C" }}>
                      {exchange.timestamp}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                      <StatusIcon status={exchange.status} />
                      <Typography
                        variant="body2"
                        sx={{
                          color:
                            exchange.status === "completed"
                              ? "#26890D"
                              : exchange.status === "failed"
                              ? "#DA291C"
                              : "#6B778C",
                          fontWeight: 500,
                          textTransform: "capitalize",
                        }}
                      >
                        {exchange.status}
                      </Typography>
                    </Box>
                    {exchange.status === "processing" && (
                      <LinearProgress
                        sx={{
                          mt: 0.5,
                          height: 2,
                          borderRadius: 1,
                          bgcolor: "rgba(237, 139, 0, 0.1)",
                          "& .MuiLinearProgress-bar": { bgcolor: "#ED8B00" },
                        }}
                      />
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>

        {exchanges.length === 0 && (
          <Box sx={{ py: 6, textAlign: "center" }}>
            <Typography variant="body1" sx={{ color: "#6B778C" }}>
              No exchange history yet
            </Typography>
            <Typography variant="body2" sx={{ color: "#A5ADBA" }}>
              Import or export data to see activity here
            </Typography>
          </Box>
        )}
      </Paper>

      {/* Info Alert */}
      <Alert
        severity="info"
        sx={{
          mt: 3,
          bgcolor: "rgba(0, 124, 176, 0.05)",
          border: "1px solid rgba(0, 124, 176, 0.2)",
          "& .MuiAlert-icon": { color: "#007CB0" },
        }}
      >
        <Typography variant="body2">
          <strong>Tip:</strong> For bulk document processing, use the "Import from Directory" feature
          to point FORTUNA to a folder containing all debtor documents. The system will automatically
          categorize and process relevant files.
        </Typography>
      </Alert>
    </Box>
  );
}
