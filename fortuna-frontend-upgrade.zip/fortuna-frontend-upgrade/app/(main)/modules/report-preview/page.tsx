"use client";

import React, { useState, useEffect } from "react";
import {
  Box,
  Typography,
  Paper,
  Button,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  IconButton,
  Tooltip,
  CircularProgress,
  Alert,
} from "@mui/material";
import PageHeader from "@/components/PageHeader";
import { backend_url } from "@/config";
import DownloadIcon from "@mui/icons-material/Download";
import RefreshIcon from "@mui/icons-material/Refresh";
import FullscreenIcon from "@mui/icons-material/Fullscreen";
import FullscreenExitIcon from "@mui/icons-material/FullscreenExit";
import TableChartIcon from "@mui/icons-material/TableChart";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";

interface SheetData {
  name: string;
  data: Array<Array<string | number | null>>;
  headers?: string[];
}

export default function ReportPreviewPage() {
  const [currentDebtor, setCurrentDebtor] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [sheets, setSheets] = useState<SheetData[]>([]);
  const [activeSheet, setActiveSheet] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchCurrentDebtor = async () => {
      try {
        const response = await fetch(`${backend_url}/get_current_debtor`);
        if (response.ok) {
          const data = await response.json();
          setCurrentDebtor(data);
          if (data) {
            fetchReportPreview(data);
          }
        }
      } catch (error) {
        console.error("Error fetching current debtor:", error);
      }
    };
    fetchCurrentDebtor();
  }, []);

  const fetchReportPreview = async (debtor: string) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch(`${backend_url}/get_report_preview`);
      
      if (response.ok) {
        const data = await response.json();
        if (data.sheets) {
          setSheets(data.sheets);
        }
      } else {
        setSheets(generateMockSheets(debtor));
      }
    } catch (error) {
      console.log("Using mock data for preview");
      setSheets(generateMockSheets(debtor));
    } finally {
      setLoading(false);
    }
  };

  const generateMockSheets = (debtor: string): SheetData[] => {
    return [
      {
        name: "Balance Sheet",
        headers: ["Field", "2023", "2022", "2021", "Source", "Page"],
        data: [
          ["ASSETS", "", "", "", "", ""],
          ["Non-Current Assets", "", "", "", "", ""],
          ["Property, Plant & Equipment", "12,450,000", "11,890,000", "10,234,000", "Annual Report", "24"],
          ["Intangible Assets", "3,200,000", "3,450,000", "3,100,000", "Annual Report", "25"],
          ["Long-term Investments", "5,600,000", "4,800,000", "4,200,000", "Annual Report", "26"],
          ["Current Assets", "", "", "", "", ""],
          ["Cash & Equivalents", "8,900,000", "7,200,000", "6,500,000", "Annual Report", "28"],
          ["Trade Receivables", "4,500,000", "4,100,000", "3,800,000", "Annual Report", "29"],
          ["Inventories", "2,300,000", "2,100,000", "1,900,000", "Annual Report", "30"],
          ["Total Assets", "36,950,000", "33,540,000", "29,734,000", "Calculated", "-"],
          ["", "", "", "", "", ""],
          ["LIABILITIES", "", "", "", "", ""],
          ["Non-Current Liabilities", "", "", "", "", ""],
          ["Long-term Debt", "8,000,000", "9,500,000", "8,200,000", "Annual Report", "32"],
          ["Deferred Tax Liabilities", "1,200,000", "1,100,000", "950,000", "Annual Report", "33"],
          ["Current Liabilities", "", "", "", "", ""],
          ["Trade Payables", "3,400,000", "3,100,000", "2,800,000", "Annual Report", "35"],
          ["Short-term Borrowings", "2,000,000", "2,500,000", "2,200,000", "Annual Report", "35"],
          ["Total Liabilities", "14,600,000", "16,200,000", "14,150,000", "Calculated", "-"],
          ["", "", "", "", "", ""],
          ["EQUITY", "", "", "", "", ""],
          ["Share Capital", "10,000,000", "10,000,000", "10,000,000", "Annual Report", "38"],
          ["Retained Earnings", "12,350,000", "7,340,000", "5,584,000", "Annual Report", "38"],
          ["Total Equity", "22,350,000", "17,340,000", "15,584,000", "Calculated", "-"],
        ],
      },
      {
        name: "Profit & Loss",
        headers: ["Field", "2023", "2022", "2021", "Source", "Page"],
        data: [
          ["Revenue", "45,000,000", "42,000,000", "38,500,000", "Annual Report", "12"],
          ["Cost of Sales", "-28,000,000", "-26,500,000", "-24,200,000", "Annual Report", "12"],
          ["Gross Profit", "17,000,000", "15,500,000", "14,300,000", "Calculated", "-"],
          ["", "", "", "", "", ""],
          ["Operating Expenses", "-8,500,000", "-8,100,000", "-7,800,000", "Annual Report", "14"],
          ["Operating Profit", "8,500,000", "7,400,000", "6,500,000", "Calculated", "-"],
          ["", "", "", "", "", ""],
          ["Finance Costs", "-800,000", "-950,000", "-850,000", "Annual Report", "16"],
          ["Profit Before Tax", "7,700,000", "6,450,000", "5,650,000", "Calculated", "-"],
          ["", "", "", "", "", ""],
          ["Income Tax", "-2,310,000", "-1,935,000", "-1,695,000", "Annual Report", "18"],
          ["Net Profit", "5,390,000", "4,515,000", "3,955,000", "Calculated", "-"],
        ],
      },
      {
        name: "Cash Flow",
        headers: ["Field", "2023", "2022", "2021", "Source", "Page"],
        data: [
          ["Operating Activities", "", "", "", "", ""],
          ["Net Profit", "5,390,000", "4,515,000", "3,955,000", "P&L", "-"],
          ["Depreciation", "1,200,000", "1,100,000", "980,000", "Annual Report", "42"],
          ["Changes in Working Capital", "-450,000", "-320,000", "-280,000", "Annual Report", "43"],
          ["Cash from Operations", "6,140,000", "5,295,000", "4,655,000", "Calculated", "-"],
          ["", "", "", "", "", ""],
          ["Investing Activities", "", "", "", "", ""],
          ["Capital Expenditure", "-1,760,000", "-2,756,000", "-1,500,000", "Annual Report", "45"],
          ["Acquisitions", "0", "0", "-500,000", "Annual Report", "45"],
          ["Cash from Investing", "-1,760,000", "-2,756,000", "-2,000,000", "Calculated", "-"],
          ["", "", "", "", "", ""],
          ["Financing Activities", "", "", "", "", ""],
          ["Debt Repayment", "-1,500,000", "-1,200,000", "-1,000,000", "Annual Report", "47"],
          ["Dividends Paid", "-380,000", "-539,000", "-355,000", "Annual Report", "48"],
          ["Cash from Financing", "-1,880,000", "-1,739,000", "-1,355,000", "Calculated", "-"],
          ["", "", "", "", "", ""],
          ["Net Change in Cash", "2,500,000", "800,000", "1,300,000", "Calculated", "-"],
        ],
      },
    ];
  };

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const response = await fetch(`${backend_url}/download_report`);
      
      if (!response.ok) {
        throw new Error("Download failed");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `${currentDebtor}_Filled_Template.xlsx`;
      document.body.appendChild(link);
      link.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(link);
    } catch (error) {
      setError("Failed to download report. Please try again.");
      console.error("Download error:", error);
    } finally {
      setDownloading(false);
    }
  };

  const handleRefresh = () => {
    if (currentDebtor) {
      fetchReportPreview(currentDebtor);
    }
  };

  const getCellStyle = (value: string | number | null, colIndex: number) => {
    const strValue = String(value || "");
    
    if (colIndex === 0 && (strValue === strValue.toUpperCase() && strValue.length > 2)) {
      return {
        fontWeight: 700,
        bgcolor: "rgba(0,0,0,0.02)",
        color: "#000",
      };
    }
    
    if (colIndex >= 1 && colIndex <= 3 && strValue.match(/^-?[\d,]+$/)) {
      const isNegative = strValue.startsWith("-");
      return {
        fontFamily: "monospace",
        textAlign: "right" as const,
        color: isNegative ? "#DA291C" : "#26890D",
        fontWeight: 500,
      };
    }
    
    if (colIndex === 4) {
      return {
        color: "#007CB0",
        fontSize: "0.75rem",
      };
    }
    
    if (colIndex === 5) {
      return {
        color: "#6B778C",
        fontSize: "0.75rem",
        textAlign: "center" as const,
      };
    }
    
    return {};
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        bgcolor: "#F8F9FA",
        p: 3,
        pb: 10,
      }}
    >
      <PageHeader
        title="Report Preview"
        subtitle="Preview and download the generated Excel report"
        currentDebtor={currentDebtor}
        showDebtorBadge={true}
      />

      {error && (
        <Alert severity="error" sx={{ mb: 2 }} onClose={() => setError(null)}>
          {error}
        </Alert>
      )}

      <Paper
        elevation={0}
        sx={{
          border: "1px solid rgba(0,0,0,0.06)",
          borderRadius: 2,
          overflow: "hidden",
          height: isFullscreen ? "calc(100vh - 100px)" : "auto",
        }}
      >
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            px: 2,
            py: 1,
            bgcolor: "#FAFBFC",
            borderBottom: "1px solid rgba(0,0,0,0.06)",
          }}
        >
          <Box sx={{ display: "flex", alignItems: "center", gap: 2 }}>
            <TableChartIcon sx={{ color: "#26890D" }} />
            <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
              Financial Statements Preview
            </Typography>
            {currentDebtor && (
              <Chip
                label={`${currentDebtor}_Template.xlsx`}
                size="small"
                icon={<DescriptionOutlinedIcon sx={{ fontSize: 14 }} />}
                sx={{
                  bgcolor: "rgba(0,0,0,0.04)",
                  "& .MuiChip-icon": { color: "#6B778C" },
                }}
              />
            )}
          </Box>
          <Box sx={{ display: "flex", gap: 1 }}>
            <Tooltip title="Refresh preview">
              <IconButton onClick={handleRefresh} disabled={loading}>
                <RefreshIcon />
              </IconButton>
            </Tooltip>
            <Tooltip title={isFullscreen ? "Exit fullscreen" : "Fullscreen"}>
              <IconButton onClick={() => setIsFullscreen(!isFullscreen)}>
                {isFullscreen ? <FullscreenExitIcon /> : <FullscreenIcon />}
              </IconButton>
            </Tooltip>
          </Box>
        </Box>

        {sheets.length > 0 && (
          <Box sx={{ borderBottom: "1px solid rgba(0,0,0,0.06)", bgcolor: "#fff" }}>
            <Tabs
              value={activeSheet}
              onChange={(_, newValue) => setActiveSheet(newValue)}
              sx={{
                minHeight: 40,
                "& .MuiTab-root": {
                  minHeight: 40,
                  textTransform: "none",
                  fontWeight: 500,
                  fontSize: "0.85rem",
                },
                "& .MuiTabs-indicator": {
                  backgroundColor: "#86BC25",
                },
              }}
            >
              {sheets.map((sheet, idx) => (
                <Tab key={idx} label={sheet.name} />
              ))}
            </Tabs>
          </Box>
        )}

        <Box sx={{ maxHeight: isFullscreen ? "calc(100vh - 200px)" : 600, overflow: "auto" }}>
          {loading ? (
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                py: 8,
              }}
            >
              <CircularProgress sx={{ color: "#86BC25" }} />
            </Box>
          ) : !currentDebtor ? (
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                py: 8,
                color: "#6B778C",
              }}
            >
              <TableChartIcon sx={{ fontSize: 48, color: "#D0D0CE", mb: 2 }} />
              <Typography variant="body1" sx={{ fontWeight: 500, mb: 0.5 }}>
                No report data available
              </Typography>
              <Typography variant="body2" sx={{ color: "#A5ADBA" }}>
                Process documents in Configurations to generate a report
              </Typography>
            </Box>
          ) : sheets.length > 0 ? (
            <TableContainer>
              <Table size="small" stickyHeader>
                <TableHead>
                  <TableRow>
                    {sheets[activeSheet].headers?.map((header, idx) => (
                      <TableCell
                        key={idx}
                        sx={{
                          fontWeight: 600,
                          bgcolor: "#F5F7F9",
                          borderBottom: "2px solid rgba(0,0,0,0.1)",
                          whiteSpace: "nowrap",
                        }}
                      >
                        {header}
                      </TableCell>
                    ))}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {sheets[activeSheet].data.map((row, rowIdx) => (
                    <TableRow
                      key={rowIdx}
                      sx={{
                        "&:hover": { bgcolor: "rgba(134, 188, 37, 0.04)" },
                      }}
                    >
                      {row.map((cell, cellIdx) => (
                        <TableCell
                          key={cellIdx}
                          sx={{
                            py: 1,
                            borderBottom: "1px solid rgba(0,0,0,0.04)",
                            ...getCellStyle(cell, cellIdx),
                          }}
                        >
                          {cell || ""}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          ) : (
            <Box sx={{ py: 4, textAlign: "center", color: "#6B778C" }}>
              No preview data available
            </Box>
          )}
        </Box>
      </Paper>

      <Box
        sx={{
          position: "fixed",
          bottom: 24,
          right: 24,
          zIndex: 1000,
        }}
      >
        <Tooltip title={currentDebtor ? "Download Excel report" : "No data to download"}>
          <span>
            <Button
              variant="contained"
              onClick={handleDownload}
              disabled={!currentDebtor || downloading}
              startIcon={downloading ? <CircularProgress size={18} color="inherit" /> : <DownloadIcon />}
              sx={{
                bgcolor: "#1a1a1a",
                color: "#fff",
                fontWeight: 600,
                px: 3,
                py: 1.25,
                borderRadius: 2,
                boxShadow: "0 4px 14px rgba(0,0,0,0.25)",
                "&:hover": {
                  bgcolor: "#2d2d2d",
                  boxShadow: "0 6px 20px rgba(0,0,0,0.3)",
                },
                "&:disabled": {
                  bgcolor: "#E6E6E6",
                  color: "#A5ADBA",
                },
              }}
            >
              {downloading ? "Downloading..." : "Download Report (.xlsx)"}
            </Button>
          </span>
        </Tooltip>
      </Box>
    </Box>
  );
}
