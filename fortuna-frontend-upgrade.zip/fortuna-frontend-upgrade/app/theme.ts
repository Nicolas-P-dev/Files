"use client";

import { Open_Sans } from "next/font/google";
import { createTheme } from "@mui/material/styles";

const opensans = Open_Sans({
  weight: ["400", "500", "600", "700"],
  subsets: ["latin"],
  display: "swap",
});

const theme = createTheme({
  typography: {
    fontFamily: opensans.style.fontFamily,
    fontSize: 13,
    h1: {
      fontWeight: 700,
      letterSpacing: "-0.02em",
    },
    h2: {
      fontWeight: 700,
      letterSpacing: "-0.01em",
    },
    h3: {
      fontWeight: 700,
    },
    h4: {
      fontWeight: 700,
    },
    h5: {
      fontWeight: 600,
    },
    h6: {
      fontWeight: 600,
    },
    subtitle1: {
      fontWeight: 600,
    },
    subtitle2: {
      fontWeight: 600,
    },
    body1: {
      lineHeight: 1.6,
    },
    body2: {
      lineHeight: 1.5,
    },
    button: {
      fontWeight: 600,
      textTransform: "none",
    },
  },
  palette: {
    primary: {
      main: "#86BC25", // Deloitte Green
      light: "#9acd32",
      dark: "#26890D",
      contrastText: "#000000",
    },
    secondary: {
      main: "#007CB0", // Deloitte Blue
      light: "#4da8c7",
      dark: "#005c84",
      contrastText: "#FFFFFF",
    },
    error: {
      main: "#DA291C",
      light: "#e85a50",
      dark: "#a81f15",
    },
    warning: {
      main: "#ED8B00",
      light: "#f5a733",
      dark: "#b86a00",
    },
    success: {
      main: "#86BC25",
      light: "#9acd32",
      dark: "#26890D",
    },
    info: {
      main: "#007CB0",
      light: "#4da8c7",
      dark: "#005c84",
    },
    grey: {
      50: "#FAFBFC",
      100: "#F5F7F9",
      200: "#E6E6E6",
      300: "#D0D0CE",
      400: "#A5ADBA",
      500: "#6B778C",
      600: "#53565A",
      700: "#3f444a",
      800: "#2d2d2d",
      900: "#1a1a1a",
    },
    background: {
      default: "#F8F9FA",
      paper: "#FFFFFF",
    },
    text: {
      primary: "#000000",
      secondary: "#6B778C",
      disabled: "#A5ADBA",
    },
    divider: "rgba(0, 0, 0, 0.06)",
  },
  shape: {
    borderRadius: 8,
  },
  shadows: [
    "none",
    "0 1px 3px rgba(0,0,0,0.04)",
    "0 2px 6px rgba(0,0,0,0.06)",
    "0 4px 12px rgba(0,0,0,0.08)",
    "0 6px 16px rgba(0,0,0,0.1)",
    "0 8px 24px rgba(0,0,0,0.12)",
    "0 12px 32px rgba(0,0,0,0.14)",
    "0 16px 40px rgba(0,0,0,0.16)",
    "0 20px 48px rgba(0,0,0,0.18)",
    "0 24px 56px rgba(0,0,0,0.2)",
    "0 28px 64px rgba(0,0,0,0.22)",
    "0 32px 72px rgba(0,0,0,0.24)",
    "0 36px 80px rgba(0,0,0,0.26)",
    "0 40px 88px rgba(0,0,0,0.28)",
    "0 44px 96px rgba(0,0,0,0.3)",
    "0 48px 104px rgba(0,0,0,0.32)",
    "0 52px 112px rgba(0,0,0,0.34)",
    "0 56px 120px rgba(0,0,0,0.36)",
    "0 60px 128px rgba(0,0,0,0.38)",
    "0 64px 136px rgba(0,0,0,0.4)",
    "0 68px 144px rgba(0,0,0,0.42)",
    "0 72px 152px rgba(0,0,0,0.44)",
    "0 76px 160px rgba(0,0,0,0.46)",
    "0 80px 168px rgba(0,0,0,0.48)",
    "0 84px 176px rgba(0,0,0,0.5)",
  ],
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          margin: 0,
          padding: 0,
          backgroundColor: "#F8F9FA",
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          textTransform: "none",
          fontWeight: 600,
          borderRadius: 8,
          padding: "8px 16px",
        },
        contained: {
          boxShadow: "none",
          "&:hover": {
            boxShadow: "0 2px 8px rgba(0, 0, 0, 0.15)",
          },
        },
        containedPrimary: {
          backgroundColor: "#86BC25",
          color: "#000000",
          "&:hover": {
            backgroundColor: "#9acd32",
          },
        },
        outlined: {
          borderWidth: 1.5,
          "&:hover": {
            borderWidth: 1.5,
          },
        },
        outlinedPrimary: {
          borderColor: "#86BC25",
          color: "#26890D",
          "&:hover": {
            borderColor: "#26890D",
            backgroundColor: "rgba(134, 188, 37, 0.04)",
          },
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: "none",
        },
        elevation0: {
          boxShadow: "none",
        },
        elevation1: {
          boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          boxShadow: "0 1px 3px rgba(0, 0, 0, 0.04)",
          border: "1px solid rgba(0, 0, 0, 0.06)",
        },
      },
    },
    MuiCardContent: {
      styleOverrides: {
        root: {
          padding: 20,
          "&:last-child": {
            paddingBottom: 20,
          },
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          fontWeight: 500,
          borderRadius: 6,
        },
        sizeSmall: {
          height: 24,
          fontSize: "0.75rem",
        },
      },
    },
    MuiAccordion: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          "&:before": {
            display: "none",
          },
          boxShadow: "none",
          border: "1px solid rgba(0, 0, 0, 0.06)",
        },
      },
    },
    MuiAccordionSummary: {
      styleOverrides: {
        root: {
          minHeight: 48,
          "&.Mui-expanded": {
            minHeight: 48,
          },
        },
        content: {
          margin: "12px 0",
          "&.Mui-expanded": {
            margin: "12px 0",
          },
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-root": {
            borderRadius: 8,
            "&:hover .MuiOutlinedInput-notchedOutline": {
              borderColor: "rgba(0, 0, 0, 0.2)",
            },
            "&.Mui-focused .MuiOutlinedInput-notchedOutline": {
              borderColor: "#86BC25",
              borderWidth: 2,
            },
          },
        },
      },
    },
    MuiSelect: {
      styleOverrides: {
        root: {
          borderRadius: 8,
        },
      },
    },
    MuiTabs: {
      styleOverrides: {
        indicator: {
          backgroundColor: "#86BC25",
          height: 3,
          borderRadius: "3px 3px 0 0",
        },
      },
    },
    MuiTab: {
      styleOverrides: {
        root: {
          textTransform: "none",
          fontWeight: 500,
          minHeight: 48,
          "&.Mui-selected": {
            color: "#26890D",
            fontWeight: 600,
          },
        },
      },
      defaultProps: {
        disableRipple: true,
      },
    },
    MuiTooltip: {
      styleOverrides: {
        tooltip: {
          backgroundColor: "#1a1a1a",
          fontSize: "0.75rem",
          padding: "8px 12px",
          borderRadius: 6,
        },
        arrow: {
          color: "#1a1a1a",
        },
      },
    },
    MuiDataGrid: {
      styleOverrides: {
        root: {
          border: "none",
          borderRadius: 8,
          "& .MuiDataGrid-cell:focus": {
            outline: "none",
          },
          "& .MuiDataGrid-row.Mui-selected": {
            backgroundColor: "rgba(134, 188, 37, 0.08)",
            "&:hover": {
              backgroundColor: "rgba(134, 188, 37, 0.12)",
            },
          },
          "& .MuiDataGrid-columnHeaders": {
            backgroundColor: "#F5F7F9",
            borderBottom: "1px solid rgba(0, 0, 0, 0.08)",
          },
        },
      },
    },
    MuiLinearProgress: {
      styleOverrides: {
        root: {
          borderRadius: 4,
          height: 6,
        },
        barColorPrimary: {
          backgroundColor: "#86BC25",
        },
      },
    },
    MuiCircularProgress: {
      styleOverrides: {
        colorPrimary: {
          color: "#86BC25",
        },
      },
    },
    MuiSwitch: {
      styleOverrides: {
        switchBase: {
          "&.Mui-checked": {
            color: "#86BC25",
            "& + .MuiSwitch-track": {
              backgroundColor: "#86BC25",
              opacity: 0.5,
            },
          },
        },
        track: {
          opacity: 0.3,
          backgroundColor: "#6B778C",
        },
      },
    },
    MuiDivider: {
      styleOverrides: {
        root: {
          borderColor: "rgba(0, 0, 0, 0.06)",
        },
      },
    },
    MuiAlert: {
      styleOverrides: {
        root: {
          borderRadius: 8,
        },
        standardSuccess: {
          backgroundColor: "rgba(134, 188, 37, 0.08)",
          "& .MuiAlert-icon": {
            color: "#86BC25",
          },
        },
        standardError: {
          backgroundColor: "rgba(218, 41, 28, 0.08)",
          "& .MuiAlert-icon": {
            color: "#DA291C",
          },
        },
        standardWarning: {
          backgroundColor: "rgba(237, 139, 0, 0.08)",
          "& .MuiAlert-icon": {
            color: "#ED8B00",
          },
        },
        standardInfo: {
          backgroundColor: "rgba(0, 124, 176, 0.08)",
          "& .MuiAlert-icon": {
            color: "#007CB0",
          },
        },
      },
    },
  },
});

export default theme;
