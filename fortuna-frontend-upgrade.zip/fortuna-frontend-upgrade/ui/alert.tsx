"use client";

import React from "react";
import { Alert, AlertTitle, Snackbar, Slide, SlideProps } from "@mui/material";

interface AlertBoxProps {
  message: string;
  severity?: "error" | "warning" | "info" | "success";
  title?: string;
  onClose?: () => void;
  autoHideDuration?: number;
}

function SlideTransition(props: SlideProps) {
  return <Slide {...props} direction="up" />;
}

const AlertBox: React.FC<AlertBoxProps> = ({
  message,
  severity = "error",
  title,
  onClose,
  autoHideDuration = 6000,
}) => {
  const [open, setOpen] = React.useState(true);

  const handleClose = (event?: React.SyntheticEvent | Event, reason?: string) => {
    if (reason === "clickaway") {
      return;
    }
    setOpen(false);
    if (onClose) {
      onClose();
    }
  };

  const getAlertStyles = () => {
    switch (severity) {
      case "error":
        return {
          bgcolor: "rgba(218, 41, 28, 0.05)",
          borderColor: "rgba(218, 41, 28, 0.3)",
          "& .MuiAlert-icon": { color: "#DA291C" },
        };
      case "warning":
        return {
          bgcolor: "rgba(237, 139, 0, 0.05)",
          borderColor: "rgba(237, 139, 0, 0.3)",
          "& .MuiAlert-icon": { color: "#ED8B00" },
        };
      case "success":
        return {
          bgcolor: "rgba(134, 188, 37, 0.05)",
          borderColor: "rgba(134, 188, 37, 0.3)",
          "& .MuiAlert-icon": { color: "#86BC25" },
        };
      case "info":
      default:
        return {
          bgcolor: "rgba(0, 124, 176, 0.05)",
          borderColor: "rgba(0, 124, 176, 0.3)",
          "& .MuiAlert-icon": { color: "#007CB0" },
        };
    }
  };

  return (
    <Snackbar
      open={open}
      autoHideDuration={autoHideDuration}
      onClose={handleClose}
      TransitionComponent={SlideTransition}
      anchorOrigin={{ vertical: "bottom", horizontal: "center" }}
    >
      <Alert
        onClose={handleClose}
        severity={severity}
        variant="outlined"
        sx={{
          ...getAlertStyles(),
          minWidth: 300,
          boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
          borderRadius: 2,
        }}
      >
        {title && <AlertTitle sx={{ fontWeight: 600 }}>{title}</AlertTitle>}
        {message}
      </Alert>
    </Snackbar>
  );
};

export default AlertBox;
