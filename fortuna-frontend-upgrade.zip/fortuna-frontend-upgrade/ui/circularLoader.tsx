"use client";

import React from "react";
import { Box, CircularProgress, Typography, Backdrop, Paper } from "@mui/material";

interface CircularLoaderProps {
  open: boolean;
  loadingMessage?: string;
}

const CircularLoader: React.FC<CircularLoaderProps> = ({
  open,
  loadingMessage = "Processing...",
}) => {
  return (
    <Backdrop
      sx={{
        color: "#fff",
        zIndex: (theme) => theme.zIndex.drawer + 1,
        backdropFilter: "blur(4px)",
        bgcolor: "rgba(0, 0, 0, 0.6)",
      }}
      open={open}
    >
      <Paper
        elevation={0}
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 3,
          p: 4,
          borderRadius: 3,
          bgcolor: "#FFFFFF",
          minWidth: 280,
        }}
      >
        {/* Custom loader with Fortuna branding */}
        <Box sx={{ position: "relative", display: "inline-flex" }}>
          <CircularProgress
            size={64}
            thickness={3}
            sx={{
              color: "#86BC25",
            }}
          />
          <Box
            sx={{
              top: 0,
              left: 0,
              bottom: 0,
              right: 0,
              position: "absolute",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Typography
              variant="h6"
              sx={{
                fontWeight: 700,
                color: "#1a1a1a",
              }}
            >
              F
            </Typography>
          </Box>
        </Box>

        <Box sx={{ textAlign: "center" }}>
          <Typography
            variant="body1"
            sx={{
              fontWeight: 600,
              color: "#000",
              mb: 0.5,
            }}
          >
            {loadingMessage}
          </Typography>
          <Typography
            variant="caption"
            sx={{
              color: "#6B778C",
            }}
          >
            Please wait while FORTUNA processes your request
          </Typography>
        </Box>

        {/* Progress dots animation */}
        <Box sx={{ display: "flex", gap: 0.75 }}>
          {[0, 1, 2].map((idx) => (
            <Box
              key={idx}
              sx={{
                width: 8,
                height: 8,
                borderRadius: "50%",
                bgcolor: "#86BC25",
                animation: "pulse 1.4s ease-in-out infinite",
                animationDelay: `${idx * 0.2}s`,
                "@keyframes pulse": {
                  "0%, 80%, 100%": {
                    opacity: 0.3,
                    transform: "scale(0.8)",
                  },
                  "40%": {
                    opacity: 1,
                    transform: "scale(1)",
                  },
                },
              }}
            />
          ))}
        </Box>
      </Paper>
    </Backdrop>
  );
};

export default CircularLoader;
