"use client";

import React, { useState, useEffect, useContext } from "react";
import { useRouter } from "next/navigation";
import {
  Typography,
  Box,
  Button,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Select,
  MenuItem,
  TextField,
  FormControl,
  Chip,
} from "@mui/material";
import {
  DataGrid,
  GridColDef,
  GridRowSelectionModel,
} from "@mui/x-data-grid";
import { styled } from "@mui/material/styles";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import AlertBox from "@/ui/alert";
import CircularLoader from "@/ui/circularLoader";
import { AgentLogsContext } from "@/contexts/AgentLogsContext";
import { backend_url } from "@/config";

interface DocumentListData {
  ROW_INDEX: number;
  FILE_NAME: string;
  FILE_EXTENSION: string;
  FILE_PATH: string;
  DOC_CLASS_NAME: string;
  DOC_DESCRIPTION: string;
  FILE_UPLOAD_DATE: string;
  PROCESSING_STATE: number;
  DEBTOR_ID: number;
}

interface DocumentsListProps {
  DocumentsInformation: DocumentListData[];
  TableLoading: boolean;
  DocumentTypeOptions: string[];
  DebtorIdValue: string;
}

const StyledDataGrid = styled(DataGrid)(() => ({
  border: "1px solid rgba(0, 0, 0, 0.06)",
  borderRadius: "8px",
  "& .MuiDataGrid-columnHeaders": {
    backgroundColor: "#F8F9FA",
    borderBottom: "1px solid rgba(0, 0, 0, 0.08)",
  },
  "& .MuiDataGrid-columnHeaderTitle": {
    fontWeight: 600,
    color: "#000000",
    fontSize: "0.8rem",
  },
  "& .MuiDataGrid-cell": {
    padding: "8px 12px",
    borderRight: "1px solid rgba(0, 0, 0, 0.03)",
    fontSize: "0.8rem",
  },
  "& .MuiDataGrid-row": {
    "&:hover": {
      backgroundColor: "rgba(38, 137, 13, 0.03)",
    },
  },
  "& .MuiDataGrid-row.Mui-selected": {
    backgroundColor: "rgba(38, 137, 13, 0.06)",
    "&:hover": {
      backgroundColor: "rgba(38, 137, 13, 0.1)",
    },
  },
  "& .MuiCheckbox-root.Mui-checked": {
    color: "#26890D",
  },
}));

const DocumentsList: React.FC<DocumentsListProps> = ({
  DocumentsInformation,
  DocumentTypeOptions,
  TableLoading,
  DebtorIdValue,
}) => {
  const [docRows, setDocRows] = useState<DocumentListData[]>([]);
  const [expandedAccordion, setExpandedAccordion] = useState<boolean>(true);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [rowSelectionModel, setRowSelectionModel] = useState<GridRowSelectionModel>([]);
  const router = useRouter();
  const { fetchAgentLogs } = useContext(AgentLogsContext);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [messageIndex, setMessageIndex] = useState(0);

  const loadingMessages = [
    "Processing documents...",
    "Extracting information...",
    "Analyzing document content...",
    "Running AI agents...",
    "Generating field attributions...",
    "Finalizing report...",
    "Almost done...",
  ];

  useEffect(() => {
    if (DocumentsInformation) {
      setDocRows(DocumentsInformation);
      if (DocumentsInformation.length > 0) {
        const selectedRows = DocumentsInformation.filter(
          (element) => element.PROCESSING_STATE === 1
        ).map((element) => element.ROW_INDEX);
        setRowSelectionModel(selectedRows);
      }
    }
  }, [DocumentsInformation]);

  // Columns showing all file info per boss feedback: name, extension, location, doc type, description
  const columns: GridColDef[] = [
    {
      field: "ROW_INDEX",
      headerName: "#",
      width: 50,
      valueGetter: (value: number) => value + 1,
      headerAlign: "center",
      align: "center",
    },
    {
      field: "FILE_NAME",
      headerName: "File Name",
      flex: 1,
      minWidth: 150,
      valueGetter: (value: string) => value.split(".")[0],
    },
    {
      field: "FILE_EXTENSION",
      headerName: "Type",
      width: 70,
      valueGetter: (value: string) => value.toUpperCase(),
      headerAlign: "center",
      align: "center",
      renderCell: (params) => (
        <Chip
          label={params.value}
          size="small"
          sx={{
            height: 20,
            fontSize: "0.65rem",
            fontWeight: 600,
            bgcolor: "rgba(0, 124, 176, 0.1)",
            color: "#007CB0",
          }}
        />
      ),
    },
    {
      field: "FILE_PATH",
      headerName: "Location",
      flex: 1.2,
      minWidth: 160,
      valueGetter: (value: string) => {
        const regex = /Debtors_Data[\\\/][^\\\/]+[\\\/](.*)/;
        const match = value.match(regex);
        return match ? match[1] : value;
      },
    },
    {
      field: "DOC_CLASS_NAME",
      headerName: "Document Type",
      flex: 1,
      minWidth: 160,
      renderCell: (params) => {
        if (isEditing) {
          return (
            <FormControl fullWidth size="small">
              <Select
                value={params.row.DOC_CLASS_NAME || ""}
                onChange={(event) =>
                  handleUpdateRow(params.id as number, event.target.value as string)
                }
                sx={{ fontSize: "0.8rem" }}
                MenuProps={{
                  PaperProps: {
                    style: { maxHeight: 240, width: 250 },
                  },
                }}
              >
                <MenuItem value="" disabled>
                  Select type
                </MenuItem>
                {DocumentTypeOptions.map((option: string, index: number) => (
                  <MenuItem value={option} key={index} sx={{ fontSize: "0.8rem" }}>
                    {option}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          );
        }
        return (
          <Chip
            label={params.value || "Unclassified"}
            size="small"
            sx={{
              bgcolor: params.value ? "rgba(38, 137, 13, 0.1)" : "rgba(0, 0, 0, 0.04)",
              color: params.value ? "#26890D" : "#6B778C",
              fontWeight: 500,
              fontSize: "0.7rem",
            }}
          />
        );
      },
    },
    {
      field: "DOC_DESCRIPTION",
      headerName: "Description",
      flex: 1.5,
      minWidth: 180,
      renderCell: (params) => {
        if (isEditing) {
          return (
            <TextField
              fullWidth
              size="small"
              defaultValue={params.value}
              onChange={(event) =>
                handleUpdateRowDescription(params.id as number, event.target.value)
              }
              onKeyDown={(event) => event.stopPropagation()}
              sx={{ "& input": { fontSize: "0.8rem" } }}
            />
          );
        }
        return (
          <Typography variant="body2" sx={{ fontSize: "0.8rem", color: "#53565A" }}>
            {params.value || "—"}
          </Typography>
        );
      },
    },
    {
      field: "FILE_UPLOAD_DATE",
      headerName: "Processed",
      width: 140,
      valueGetter: (value: string) => {
        if (!value) return "—";
        return value.split(".")[0].replace("T", " ");
      },
      headerAlign: "center",
    },
  ];

  const updateProcessingState = (
    rows: DocumentListData[],
    selectedIndices: GridRowSelectionModel
  ) => {
    return rows.map((row) => ({
      ...row,
      PROCESSING_STATE: selectedIndices.includes(row.ROW_INDEX) ? 1 : 0,
    }));
  };

  const pollAgentProcessingStatus = async (jobId: string): Promise<boolean> => {
    const maxAttempts = 120;
    let attempts = 0;

    const checkStatus = async (): Promise<boolean> => {
      try {
        const response = await fetch(
          `${backend_url}/agent_processing_status/${jobId}`
        );

        if (!response.ok) {
          throw new Error("Failed to check processing status");
        }

        const status = await response.json();
        console.log("Agent processing status:", status);

        if (status.status === "completed") {
          return true;
        } else if (status.status === "failed") {
          setAlertMessage(`Processing failed: ${status.message || "Unknown error"}`);
          return false;
        }

        attempts++;
        if (attempts >= maxAttempts) {
          setAlertMessage("Processing is taking longer than expected");
          return false;
        }

        await new Promise((resolve) => setTimeout(resolve, 10000));
        return checkStatus();
      } catch (error) {
        console.error("Error checking status:", error);
        attempts++;
        if (attempts < maxAttempts) {
          await new Promise((resolve) => setTimeout(resolve, 10000));
          return checkStatus();
        }
        setAlertMessage("Could not verify processing status");
        return false;
      }
    };

    return checkStatus();
  };

  const handleProcessDocuments = async () => {
    const updatedRows = updateProcessingState(docRows, rowSelectionModel);

    const formData = new FormData();
    formData.append("UpdatedDocumentList", JSON.stringify(updatedRows));
    const apiRoute = `${backend_url}/process_document_list`;

    try {
      setLoading(true);
      setAlertMessage(null);

      const response = await fetch(apiRoute, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Upload failed");
      }

      const result = await response.json();
      console.log("Documents submitted:", result);

      const agentResponse = await fetch(`${backend_url}/start_agent_processing`, {
        method: "POST",
      });

      if (!agentResponse.ok) {
        throw new Error("Failed to start agent processing");
      }

      const agentResult = await agentResponse.json();
      console.log("Agent processing started:", agentResult);

      await new Promise((resolve) => setTimeout(resolve, 2000));
      const success = await pollAgentProcessingStatus(agentResult.job_id);

      setLoading(false);

      if (success) {
        await fetchAgentLogs();
        router.push("/modules/report-planning");
      }
    } catch (error) {
      setLoading(false);
      setAlertMessage("Error processing documents, please try again");
      console.error("Error:", error);
    }
  };

  const toggleEdit = () => setIsEditing(!isEditing);

  const handleSaveChanges = async () => {
    const formData = new FormData();
    formData.append("UpdatedDocumentList", JSON.stringify(docRows));
    const apiRoute = `${backend_url}/update_document_metadata`;

    try {
      const response = await fetch(apiRoute, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        throw new Error("Failed to save changes");
      }

      console.log("Changes saved successfully");
    } catch (error) {
      console.error("Error saving changes:", error);
    }
  };

  const handleUpdateRow = (rowId: number, value: string) => {
    setDocRows((prev) =>
      prev.map((row) =>
        row.ROW_INDEX === rowId ? { ...row, DOC_CLASS_NAME: value } : row
      )
    );
  };

  const handleUpdateRowDescription = (rowId: number, value: string) => {
    setDocRows((prev) =>
      prev.map((row) =>
        row.ROW_INDEX === rowId ? { ...row, DOC_DESCRIPTION: value } : row
      )
    );
  };

  useEffect(() => {
    if (!loading) {
      setMessageIndex(0);
      return;
    }

    const interval = setInterval(() => {
      setMessageIndex((prev) => {
        if (prev >= loadingMessages.length - 1) {
          clearInterval(interval);
          return prev;
        }
        return prev + 1;
      });
    }, 20000);

    return () => clearInterval(interval);
  }, [loading, loadingMessages.length]);

  if (!DocumentsInformation || DocumentsInformation.length === 0) {
    return null;
  }

  return (
    <Box sx={{ mt: 3 }}>
      <Accordion
        expanded={expandedAccordion}
        onChange={() => setExpandedAccordion(!expandedAccordion)}
        sx={{
          boxShadow: "0 1px 3px rgba(0, 0, 0, 0.06)",
          borderRadius: "8px !important",
          "&:before": { display: "none" },
          overflow: "hidden",
        }}
      >
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          sx={{
            bgcolor: "#FFFFFF",
            borderBottom: expandedAccordion ? "1px solid rgba(0, 0, 0, 0.06)" : "none",
            py: 0.5,
          }}
        >
          <Box>
            <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
              Document List
            </Typography>
            <Typography variant="caption" color="textSecondary">
              Review file info: name, type, location, document class, and description before processing
            </Typography>
          </Box>
        </AccordionSummary>

        <AccordionDetails sx={{ p: 0, bgcolor: "#FFFFFF" }}>
          <Box sx={{ p: 2, display: "flex", justifyContent: "flex-end" }}>
            <Button
              variant="outlined"
              onClick={() => {
                if (isEditing) {
                  handleSaveChanges();
                }
                toggleEdit();
              }}
              disabled={docRows.length === 0}
              size="small"
              sx={{
                textTransform: "none",
                fontWeight: 500,
                borderColor: "#26890D",
                color: "#26890D",
                "&:hover": {
                  borderColor: "#1a6609",
                  bgcolor: "rgba(38, 137, 13, 0.04)",
                },
              }}
            >
              {isEditing ? "Save Changes" : "Edit Table"}
            </Button>
          </Box>

          <Box sx={{ height: 420, width: "100%" }}>
            <StyledDataGrid
              loading={TableLoading}
              rows={docRows}
              columns={columns}
              getRowId={(row) => row.ROW_INDEX}
              getRowHeight={() => "auto"}
              checkboxSelection
              disableRowSelectionOnClick
              onRowSelectionModelChange={setRowSelectionModel}
              rowSelectionModel={rowSelectionModel}
              slotProps={{
                loadingOverlay: {
                  variant: "linear-progress",
                  noRowsVariant: "linear-progress",
                },
              }}
              initialState={{
                pagination: { paginationModel: { pageSize: 25 } },
              }}
              pageSizeOptions={[25, 50, 100]}
              sx={{ border: "none" }}
            />
          </Box>
        </AccordionDetails>
      </Accordion>

      <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 2, gap: 2, alignItems: "center" }}>
        <Typography variant="caption" sx={{ color: "#53565A" }}>
          {rowSelectionModel.length} of {docRows.length} documents selected
        </Typography>
        <Button
          variant="contained"
          color="primary"
          onClick={handleProcessDocuments}
          disabled={
            TableLoading ||
            docRows.length === 0 ||
            isEditing ||
            rowSelectionModel.length === 0
          }
          sx={{
            textTransform: "none",
            fontWeight: 600,
            px: 3,
            boxShadow: "none",
            "&:hover": {
              boxShadow: "0 2px 8px rgba(38, 137, 13, 0.25)",
            },
          }}
        >
          Process Documents
        </Button>
      </Box>

      {loading && (
        <CircularLoader open={loading} loadingMessage={loadingMessages[messageIndex]} />
      )}

      {alertMessage && <AlertBox message={alertMessage} severity="error" />}
    </Box>
  );
};

export default DocumentsList;
