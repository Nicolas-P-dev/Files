"use client";

import React, { useState, useEffect } from "react";
import { Box } from "@mui/material";
import PageHeader from "@/components/PageHeader";
import TemplateSelections from "@/app/(main)/modules/upload-document/templateSelections";
import DocumentsList from "@/app/(main)/modules/upload-document/documentsList";
import { backend_url } from "@/config";

export default function ConfigurationsPage() {
  const [documentsInformation, setDocumentsInformation] = useState<any>(null);
  const [tableLoading, setTableLoading] = useState(false);
  const [documentTypeOptions, setDocumentTypeOptions] = useState<any>([]);
  const [debtorIdValue, setDebtorIdValue] = useState<string>("None");
  const [currentDebtor, setCurrentDebtor] = useState<string | null>(null);

  useEffect(() => {
    const fetchCurrentDebtor = async () => {
      try {
        const response = await fetch(`${backend_url}/get_current_debtor`);
        if (response.ok) {
          const data = await response.json();
          setCurrentDebtor(data);
        }
      } catch (error) {
        console.error("Error fetching current debtor:", error);
      }
    };
    fetchCurrentDebtor();
  }, []);

  return (
    <Box
      sx={{
        padding: "20px 24px",
        minHeight: "calc(100vh - 48px)",
        backgroundColor: "#F5F7F9",
      }}
    >
      <PageHeader
        title="Configurations"
        subtitle="Select a template and debtor to load and process documents"
        currentDebtor={currentDebtor}
        showDebtorBadge={true}
      />

      <Box
        sx={{
          backgroundColor: "#FFFFFF",
          borderRadius: 2,
          p: 3,
          boxShadow: "0 1px 3px rgba(0, 0, 0, 0.08)",
        }}
      >
        <TemplateSelections
          setDocumentsInformation={setDocumentsInformation}
          setTableLoading={setTableLoading}
          setDocumentTypeOptions={setDocumentTypeOptions}
          setDebtorIdValue={setDebtorIdValue}
          debtorIdValue={debtorIdValue}
        />
      </Box>

      {/* Document list with file info: name, extension, location, doc type, description */}
      <DocumentsList
        DocumentsInformation={documentsInformation}
        TableLoading={tableLoading}
        DocumentTypeOptions={documentTypeOptions}
        DebtorIdValue={debtorIdValue}
      />
    </Box>
  );
}
