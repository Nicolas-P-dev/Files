"use client";

import React, { useState, useContext, createContext } from "react";
import {
  Typography,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Button,
  Table,
  TableCell,
  TableBody,
  TableRow,
  TableHead,
  Tooltip,
  Box,
  Chip,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ArticleIcon from "@mui/icons-material/Article";
import CircularLoader from "@/ui/circularLoader";
import { AgentLogsContext } from "@/contexts/AgentLogsContext";

interface ExpandContextType {
  manualExpanded: Record<string, boolean>;
  setManualExpanded: React.Dispatch<React.SetStateAction<Record<string, boolean>>>;
  setCurrentExpandedLevel: React.Dispatch<React.SetStateAction<number>>;
}

const ExpandContext = createContext<ExpandContextType | null>(null);

interface RecursiveAccordionProps {
  data: Record<string, any>;
  level: number;
  onClick: (index: number | null, path: string[]) => void;
  path?: string[];
}

// Styled table for better field display
const StyledTable = styled(Table)(() => ({
  "& .MuiTableCell-root": {
    padding: "10px 12px",
    fontSize: "0.8rem",
    borderBottom: "1px solid rgba(0, 0, 0, 0.06)",
  },
  "& .MuiTableCell-head": {
    backgroundColor: "#F8F9FA",
    fontWeight: 600,
    color: "#000000",
  },
}));

// Format field value nicely
const formatFieldValue = (value: any): string => {
  if (value === null || value === undefined) return "—";
  if (typeof value === "number") {
    // Format numbers with thousand separators
    return value.toLocaleString("en-US", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 2,
    });
  }
  if (Array.isArray(value)) {
    return value.map((v) => String(v)).join(", ");
  }
  return String(value);
};

function RecursiveAccordion({ data, level, onClick, path = [] }: RecursiveAccordionProps) {
  const context = useContext(ExpandContext);
  if (!context) return null;

  const { manualExpanded, setManualExpanded, setCurrentExpandedLevel } = context;

  const keyWords = ["current liabilities", "non-current liabilities", "current assets", "equity"];
  const currentPath = path.join("/");

  const handleToggle = (key: string) => {
    const newPath = `${currentPath}/${key}`;
    setManualExpanded((prev) => ({
      ...prev,
      [newPath]: !prev[newPath],
    }));

    const newLevel = path.length;
    setCurrentExpandedLevel(newLevel);
    onClick(null, [...path, key]);
  };

  // At level 4, show detailed table with sources, page numbers, and explanations
  if (level >= 4) {
    const tableColumns: string[] = [];
    const firstItem = Object.values(data)[0];

    if (typeof firstItem === "object" && firstItem !== null) {
      tableColumns.push(...Object.keys(firstItem));

      // Reorder columns to prioritize important info
      const priorityOrder = ["value", "field_name", "explanation", "sources", "page_numbers", "used_fields"];
      tableColumns.sort((a, b) => {
        const aIdx = priorityOrder.indexOf(a.toLowerCase());
        const bIdx = priorityOrder.indexOf(b.toLowerCase());
        if (aIdx === -1 && bIdx === -1) return 0;
        if (aIdx === -1) return 1;
        if (bIdx === -1) return -1;
        return aIdx - bIdx;
      });

      return (
        <Box sx={{ overflowX: "auto" }}>
          <StyledTable size="small">
            <TableHead>
              <TableRow>
                <TableCell sx={{ fontWeight: 600, bgcolor: "#F5F7F9", minWidth: 140 }}>
                  Field Name
                </TableCell>
                {tableColumns.map((column, columnIndex) => (
                  <TableCell 
                    key={columnIndex} 
                    sx={{ 
                      fontWeight: 600, 
                      bgcolor: "#F5F7F9",
                      minWidth: column.toLowerCase() === "explanation" ? 200 : 120,
                    }}
                  >
                    {/* Improve column header names */}
                    {column === "used_fields" ? "Source Fields" :
                     column === "page_numbers" ? "Page #" :
                     column.charAt(0).toUpperCase() + column.slice(1).replace(/_/g, " ")}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {Object.entries(data).map(([rowKey, rowValue]: [string, any], rowIndex) => (
                <TableRow 
                  key={rowIndex}
                  sx={{
                    "&:hover": { bgcolor: "rgba(38, 137, 13, 0.04)" },
                    "&:nth-of-type(odd)": { bgcolor: "rgba(0, 0, 0, 0.01)" },
                  }}
                >
                  <TableCell
                    onClick={() => {
                      if (keyWords.includes(rowKey.toLowerCase())) {
                        onClick(rowIndex, [...path, rowKey]);
                      }
                    }}
                    sx={{
                      cursor: keyWords.includes(rowKey.toLowerCase()) ? "pointer" : "default",
                      color: keyWords.includes(rowKey.toLowerCase()) ? "#26890D" : "inherit",
                      fontWeight: 600,
                    }}
                  >
                    {rowKey}
                  </TableCell>
                  {tableColumns.map((column) => (
                    <TableCell key={column} sx={{ whiteSpace: "pre-line" }}>
                      {(() => {
                        const cellValue = rowValue[column];
                        
                        // Special formatting for different column types
                        if (column.toLowerCase() === "value") {
                          return (
                            <Typography 
                              variant="body2" 
                              sx={{ 
                                fontWeight: 600, 
                                color: "#26890D",
                                fontFamily: "monospace",
                              }}
                            >
                              {formatFieldValue(cellValue)}
                            </Typography>
                          );
                        }
                        
                        if (column.toLowerCase() === "sources" || column.toLowerCase() === "used_fields") {
                          if (Array.isArray(cellValue)) {
                            return (
                              <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.5 }}>
                                {cellValue.map((item, idx) => (
                                  <Chip
                                    key={idx}
                                    label={String(item).replace(/['"[\]]/g, "")}
                                    size="small"
                                    icon={<ArticleIcon sx={{ fontSize: 14 }} />}
                                    sx={{
                                      height: 22,
                                      fontSize: "0.7rem",
                                      bgcolor: "rgba(0, 124, 176, 0.08)",
                                      color: "#007CB0",
                                      "& .MuiChip-icon": { color: "#007CB0" },
                                    }}
                                  />
                                ))}
                              </Box>
                            );
                          }
                        }
                        
                        if (column.toLowerCase() === "page_numbers" || column.toLowerCase() === "page") {
                          return (
                            <Chip
                              label={`p. ${formatFieldValue(cellValue)}`}
                              size="small"
                              sx={{
                                height: 20,
                                fontSize: "0.7rem",
                                bgcolor: "rgba(237, 139, 0, 0.1)",
                                color: "#ED8B00",
                              }}
                            />
                          );
                        }
                        
                        if (column.toLowerCase() === "explanation") {
                          return (
                            <Typography variant="body2" sx={{ fontSize: "0.75rem", color: "#53565A" }}>
                              {formatFieldValue(cellValue)}
                            </Typography>
                          );
                        }

                        // Default formatting
                        if (Array.isArray(cellValue)) {
                          return cellValue
                            .map((item) => `• ${String(item).replace(/['"[\]]/g, "")}`)
                            .join("\n");
                        } else if (typeof cellValue === "object" && cellValue !== null) {
                          return Object.values(cellValue)
                            .map((item) => `• ${String(item).replace(/['"[\]]/g, "")}`)
                            .join("\n");
                        } else {
                          return formatFieldValue(cellValue);
                        }
                      })()}
                    </TableCell>
                  ))}
                </TableRow>
              ))}
            </TableBody>
          </StyledTable>
        </Box>
      );
    }
  }

  return (
    <Box>
      {Object.entries(data).map(([key, value], i) =>
        typeof value === "object" && value !== null ? (
          <Accordion
            key={i}
            expanded={manualExpanded[`${currentPath}/${key}`] || false}
            onChange={() => handleToggle(key)}
            sx={{
              ml: 0,
              mb: 1,
              boxShadow: "0 1px 3px rgba(0,0,0,0.06)",
              borderRadius: "6px !important",
              "&:before": { display: "none" },
              transition: "all 0.2s ease",
              border: "1px solid rgba(0, 0, 0, 0.06)",
            }}
          >
            <AccordionSummary
              expandIcon={<ExpandMoreIcon />}
              sx={{
                minHeight: 44,
                "& .MuiAccordionSummary-content": { my: 0.75 },
                "&:hover": { bgcolor: "rgba(38, 137, 13, 0.02)" },
              }}
            >
              <Typography variant="body2" sx={{ fontWeight: 600, fontSize: "0.85rem" }}>
                {key}
              </Typography>
            </AccordionSummary>
            <AccordionDetails sx={{ pt: 0, pb: 1.5 }}>
              <RecursiveAccordion
                data={value}
                level={level + 1}
                onClick={onClick}
                path={[...path, key]}
              />
            </AccordionDetails>
          </Accordion>
        ) : (
          <Box 
            key={i} 
            sx={{ 
              py: 0.75, 
              px: 1.5,
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              borderBottom: "1px solid rgba(0, 0, 0, 0.04)",
              "&:last-child": { borderBottom: "none" },
            }}
            onClick={() => onClick(i, [...path, key])}
          >
            <Typography variant="body2" sx={{ fontWeight: 500, color: "#53565A" }}>
              {key}
            </Typography>
            <Typography variant="body2" sx={{ fontWeight: 600, color: "#26890D" }}>
              {formatFieldValue(value)}
            </Typography>
          </Box>
        )
      )}
    </Box>
  );
}

interface AgentAccordionWithButtonProps {
  onClick: (index: number | null, path: string[]) => void;
  path?: string[];
}

export default function AgentAccordionwithButton({ onClick, path = [] }: AgentAccordionWithButtonProps) {
  const [currentExpandedLevel, setCurrentExpandedLevel] = useState(-1);
  const [manualExpanded, setManualExpanded] = useState<Record<string, boolean>>({});
  const { logs: AgentLogs, logsLoading } = useContext(AgentLogsContext);

  if (logsLoading) {
    return <CircularLoader open={logsLoading} />;
  }

  // FIX: Check if logs exist and have content (works for both objects and arrays)
  const hasLogs = AgentLogs && 
    typeof AgentLogs === 'object' && 
    !Array.isArray(AgentLogs) && 
    Object.keys(AgentLogs).length > 0;

  // Show empty state if no logs
  if (!hasLogs) {
    return (
      <Box
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          height: "100%",
          minHeight: "200px",
          color: "#53565A",
        }}
      >
        <Typography variant="body1" sx={{ fontWeight: 500, mb: 1 }}>
          No extraction data available
        </Typography>
        <Typography variant="body2" color="textSecondary">
          Process documents in Configurations to view field attributions
        </Typography>
      </Box>
    );
  }

  const handleExpandAllNextLevel = () => {
    setCurrentExpandedLevel((prevLevel) => {
      const nextLevel = prevLevel + 1;
      const isLastLevel = nextLevel >= 4;

      setManualExpanded((prev) => {
        const updateState = (
          logs: Record<string, any>,
          currentPath: string[],
          level: number,
          currentLevel = 0
        ): Record<string, boolean> => {
          const newState: Record<string, boolean> = {};

          Object.entries(logs).forEach(([key, value]) => {
            const newPath = `${currentPath.join("/")}/${key}`;
            if (currentLevel === level || level === -1) {
              newState[newPath] = true;
            }
            if (typeof value === "object" && value !== null) {
              Object.assign(
                newState,
                updateState(value, [...currentPath, key], level, currentLevel + 1)
              );
            }
          });

          return newState;
        };

        return {
          ...prev,
          ...updateState(AgentLogs, path, isLastLevel ? -1 : nextLevel),
        };
      });

      return isLastLevel ? prevLevel : nextLevel;
    });
  };

  const handleCollapseCurrentLevel = () => {
    setManualExpanded((prev) => {
      const updateState = (
        logs: Record<string, any>,
        currentPath: string[],
        level: number,
        currentLevel = 0
      ): Record<string, boolean> => {
        const newState: Record<string, boolean> = {};

        Object.entries(logs).forEach(([key, value]) => {
          const newPath = `${currentPath.join("/")}/${key}`;
          if (currentLevel === level) {
            newState[newPath] = false;
          }
          if (typeof value === "object" && value !== null) {
            Object.assign(
              newState,
              updateState(value, [...currentPath, key], level, currentLevel + 1)
            );
          }
        });

        return newState;
      };

      return {
        ...prev,
        ...updateState(AgentLogs, path, currentExpandedLevel),
      };
    });

    setCurrentExpandedLevel((prev) => Math.max(prev - 1, 0));
  };

  const CustomTooltip = styled(({ className, ...props }: any) => (
    <Tooltip {...props} classes={{ tooltip: className }} />
  ))(() => ({
    "&.MuiTooltip-tooltip": {
      fontSize: "0.7rem",
      padding: "4px 8px",
      backgroundColor: "#000000",
      color: "#FFFFFF",
      borderRadius: "4px",
    },
  }));

  return (
    <Box>
      <Box sx={{ display: "flex", gap: 1, mb: 2 }}>
        <CustomTooltip title="Expand one level">
          <Button
            onClick={handleExpandAllNextLevel}
            variant="outlined"
            size="small"
            sx={{
              minWidth: 36,
              height: 32,
              borderColor: "#26890D",
              color: "#26890D",
              fontWeight: 700,
              "&:hover": {
                borderColor: "#1a6609",
                bgcolor: "rgba(38, 137, 13, 0.04)",
              },
            }}
          >
            +
          </Button>
        </CustomTooltip>
        <CustomTooltip title="Collapse one level">
          <Button
            onClick={handleCollapseCurrentLevel}
            variant="outlined"
            size="small"
            sx={{
              minWidth: 36,
              height: 32,
              borderColor: "#26890D",
              color: "#26890D",
              fontWeight: 700,
              "&:hover": {
                borderColor: "#1a6609",
                bgcolor: "rgba(38, 137, 13, 0.04)",
              },
            }}
          >
            −
          </Button>
        </CustomTooltip>
      </Box>

      <ExpandContext.Provider
        value={{ manualExpanded, setManualExpanded, setCurrentExpandedLevel }}
      >
        <RecursiveAccordion data={AgentLogs} level={0} onClick={onClick} />
      </ExpandContext.Provider>
    </Box>
  );
}
