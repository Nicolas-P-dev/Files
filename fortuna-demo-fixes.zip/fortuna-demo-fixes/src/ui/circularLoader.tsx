import React from "react";
import { Backdrop, CircularProgress, Typography, Box, Paper } from "@mui/material";

interface CircularLoaderProps {
  open: boolean;
  loadingMessage?: string;
}

const CircularLoader: React.FC<CircularLoaderProps> = ({ open, loadingMessage }) => {
  if (!open) return null;

  return (
    <Backdrop
      sx={{
        color: "#FFFFFF",
        zIndex: (theme) => theme.zIndex.drawer + 1,
        backgroundColor: "rgba(0, 0, 0, 0.7)",
      }}
      open={open}
    >
      <Paper
        elevation={0}
        sx={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          padding: 3,
          borderRadius: 2,
          backgroundColor: "rgba(255, 255, 255, 0.98)",
          minWidth: "280px",
          textAlign: "center",
        }}
      >
        <CircularProgress
          size={40}
          thickness={4}
          sx={{
            color: "#26890D",
          }}
        />
        {loadingMessage && (
          <Box sx={{ mt: 2.5 }}>
            <Typography
              variant="body2"
              sx={{
                color: "#000000",
                fontWeight: 500,
              }}
            >
              {loadingMessage}
            </Typography>
            <Typography
              variant="caption"
              sx={{
                color: "#53565A",
                mt: 0.5,
                display: "block",
              }}
            >
              Please wait...
            </Typography>
          </Box>
        )}
      </Paper>
    </Backdrop>
  );
};

export default CircularLoader;
