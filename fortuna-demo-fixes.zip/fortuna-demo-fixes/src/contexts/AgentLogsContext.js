import React, { createContext, useState, useEffect } from "react";
import { backend_url } from "../config";

export const AgentLogsContext = createContext();

export const AgentLogsProvider = ({ children }) => {
  // FIX: Initialize as empty object, not array - backend returns object structure
  const [logs, setLogs] = useState({});
  const [logsLoading, setLogsLoading] = useState(false);
  const [hasDebtor, setHasDebtor] = useState(false);

  const fetchAgentLogs = async () => {
    setLogsLoading(true);

    try {
      const debtorCheckRoute = `${backend_url}/get_current_debtor`;
      const debtorResponse = await fetch(debtorCheckRoute, { method: "GET" });

      if (!debtorResponse.ok) {
        console.log("No debtor selected yet, skipping agent logs fetch");
        setLogsLoading(false);
        setHasDebtor(false);
        return;
      }

      setHasDebtor(true);

      const apiRoute = `${backend_url}/get_agent_logs`;
      const response = await fetch(apiRoute, { method: "GET" });

      if (!response.ok) {
        console.error("Failed to fetch agent logs:", response.statusText);
        setLogsLoading(false);
        return;
      }

      const data = await response.json();
      console.log("Fetched agent logs from server", data);

      if (data.status === "no_debtor") {
        console.log("No debtor selected, cannot fetch logs");
        // FIX: Use empty object instead of empty array
        setLogs({});
      } else {
        setLogs(data);
        localStorage.setItem("agentLogs", JSON.stringify(data));
        console.log("Saved agent logs in cache");
      }
    } catch (error) {
      console.error("Error fetching agent logs:", error);
      // FIX: Use empty object instead of empty array
      setLogs({});
    } finally {
      setLogsLoading(false);
    }
  };

  const validateCachedLogs = async () => {
    try {
      const response = await fetch(`${backend_url}/get_current_debtor`);
      if (!response.ok) {
        localStorage.removeItem("agentLogs");
        return false;
      }
      return true;
    } catch {
      return false;
    }
  };

  useEffect(() => {
    if (typeof window !== "undefined") {
      const cachedLogs = localStorage.getItem("agentLogs");
      if (cachedLogs !== null) {
        try {
          const parsedLogs = JSON.parse(cachedLogs);
          // Validate that parsed logs is an object (not array)
          if (parsedLogs && typeof parsedLogs === 'object' && !Array.isArray(parsedLogs)) {
            setLogs(parsedLogs);
            console.log("Loaded agent logs from cache");
            setHasDebtor(true);
          } else {
            console.log("Cached logs invalid format, fetching fresh");
            localStorage.removeItem("agentLogs");
            fetchAgentLogs();
          }
        } catch (e) {
          console.error("Error parsing cached logs:", e);
          localStorage.removeItem("agentLogs");
          fetchAgentLogs();
        }
      } else {
        console.log("No cached logs found, fetching from server");
        fetchAgentLogs();
      }
    }
  }, []);

  // Validate cached logs periodically
  useEffect(() => {
    const interval = setInterval(async () => {
      const isValid = await validateCachedLogs();
      if (!isValid) {
        // FIX: Use empty object instead of empty array
        setLogs({});
        setHasDebtor(false);
      }
    }, 30000); // Check every 30 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <AgentLogsContext.Provider
      value={{
        logs,
        setLogs,
        logsLoading,
        setLogsLoading,
        hasDebtor,
        fetchAgentLogs,
      }}
    >
      {children}
    </AgentLogsContext.Provider>
  );
};
