"use client";

import React from "react";
import { Box, Typography, Chip } from "@mui/material";

interface PageHeaderProps {
  title: string;
  subtitle?: string;
  currentDebtor?: string | null;
  showDebtorBadge?: boolean;
  actions?: React.ReactNode;
}

const PageHeader: React.FC<PageHeaderProps> = ({
  title,
  subtitle,
  currentDebtor,
  showDebtorBadge = false,
  actions,
}) => {
  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "flex-start",
        mb: 3,
      }}
    >
      <Box>
        <Box sx={{ display: "flex", alignItems: "center", gap: 2, mb: 0.5 }}>
          <Typography
            variant="h5"
            sx={{
              fontWeight: 700,
              color: "#000000",
            }}
          >
            {title}
          </Typography>
          {showDebtorBadge && currentDebtor && (
            <Chip
              label={currentDebtor}
              size="small"
              sx={{
                bgcolor: "rgba(38, 137, 13, 0.1)",
                color: "#26890D",
                fontWeight: 600,
                fontSize: "0.75rem",
                height: 24,
              }}
            />
          )}
        </Box>
        {subtitle && (
          <Typography
            variant="body2"
            sx={{
              color: "#53565A",
              mt: 0.5,
            }}
          >
            {subtitle}
          </Typography>
        )}
      </Box>
      {actions && <Box sx={{ display: "flex", gap: 1 }}>{actions}</Box>}
    </Box>
  );
};

export default PageHeader;
