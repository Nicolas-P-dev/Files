"use client";

import React, { useState, useRef, useEffect } from "react";
import {
  Box,
  Typography,
  TextField,
  IconButton,
  Paper,
  InputAdornment,
  Avatar,
} from "@mui/material";
import SendIcon from "@mui/icons-material/Send";
import SmartToyIcon from "@mui/icons-material/SmartToy";
import PersonIcon from "@mui/icons-material/Person";

interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: Date;
}

interface ChatPanelProps {
  title?: string;
  placeholder?: string;
  welcomeMessage?: string;
  disabled?: boolean;
  disabledMessage?: string;
}

const ChatPanel: React.FC<ChatPanelProps> = ({
  title = "Report Assistant",
  placeholder = "Ask about field extractions...",
  welcomeMessage = "I can help you understand how the report was generated. Ask me about specific field values, their source documents, or the extraction methodology.",
  disabled = false,
  disabledMessage = "Process documents first to enable chat",
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Add welcome message on mount
    if (messages.length === 0 && !disabled) {
      setMessages([
        {
          id: "welcome",
          role: "assistant",
          content: welcomeMessage,
          timestamp: new Date(),
        },
      ]);
    }
  }, [disabled, welcomeMessage, messages.length]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || disabled || isLoading) return;

    const userMessage: Message = {
      id: `user_${Date.now()}`,
      role: "user",
      content: inputValue.trim(),
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);

    // Level #1 only: Understanding how report was generated
    // TODO: Connect to backend chat endpoint for actual Q&A
    setTimeout(() => {
      const assistantMessage: Message = {
        id: `assistant_${Date.now()}`,
        role: "assistant",
        content:
          "I can help explain how specific field values were extracted. This feature is being integrated with the extraction system. For now, you can explore the attribution details in the workspace panel on the left - each field shows its value, source documents, page numbers, and extraction explanation.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, assistantMessage]);
      setIsLoading(false);
    }, 1000);
  };

  const handleKeyPress = (event: React.KeyboardEvent) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Paper
      elevation={0}
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        border: "1px solid rgba(0, 0, 0, 0.08)",
        borderRadius: 2,
        overflow: "hidden",
      }}
    >
      {/* Header */}
      <Box
        sx={{
          px: 2,
          py: 1.25,
          bgcolor: "#000000",
          color: "#FFFFFF",
          display: "flex",
          alignItems: "center",
          gap: 1,
        }}
      >
        <SmartToyIcon sx={{ fontSize: 18 }} />
        <Typography variant="subtitle2" sx={{ fontWeight: 600, fontSize: "0.85rem" }}>
          {title}
        </Typography>
      </Box>

      {/* Messages Area */}
      <Box
        sx={{
          flex: 1,
          overflow: "auto",
          p: 1.5,
          bgcolor: "#FAFAFA",
          display: "flex",
          flexDirection: "column",
          gap: 1.5,
        }}
      >
        {disabled ? (
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              height: "100%",
              textAlign: "center",
              color: "#53565A",
            }}
          >
            <SmartToyIcon sx={{ fontSize: 40, mb: 1.5, color: "#D0D0CE" }} />
            <Typography variant="body2" sx={{ fontWeight: 500 }}>
              {disabledMessage}
            </Typography>
            <Typography variant="caption" sx={{ mt: 0.5, color: "#A5ADBA" }}>
              Complete document processing to enable
            </Typography>
          </Box>
        ) : (
          <>
            {messages.map((message) => (
              <Box
                key={message.id}
                sx={{
                  display: "flex",
                  flexDirection: message.role === "user" ? "row-reverse" : "row",
                  gap: 1,
                  alignItems: "flex-start",
                }}
              >
                <Avatar
                  sx={{
                    width: 28,
                    height: 28,
                    bgcolor: message.role === "user" ? "#26890D" : "#000000",
                  }}
                >
                  {message.role === "user" ? (
                    <PersonIcon sx={{ fontSize: 16 }} />
                  ) : (
                    <SmartToyIcon sx={{ fontSize: 16 }} />
                  )}
                </Avatar>
                <Box
                  sx={{
                    maxWidth: "85%",
                    p: 1.25,
                    borderRadius: 1.5,
                    bgcolor: message.role === "user" ? "#26890D" : "#FFFFFF",
                    color: message.role === "user" ? "#FFFFFF" : "#000000",
                    border:
                      message.role === "user"
                        ? "none"
                        : "1px solid rgba(0, 0, 0, 0.08)",
                    boxShadow:
                      message.role === "user"
                        ? "0 1px 4px rgba(38, 137, 13, 0.2)"
                        : "0 1px 2px rgba(0, 0, 0, 0.04)",
                  }}
                >
                  <Typography variant="body2" sx={{ lineHeight: 1.5, fontSize: "0.8rem" }}>
                    {message.content}
                  </Typography>
                </Box>
              </Box>
            ))}

            {isLoading && (
              <Box sx={{ display: "flex", gap: 1, alignItems: "flex-start" }}>
                <Avatar sx={{ width: 28, height: 28, bgcolor: "#000000" }}>
                  <SmartToyIcon sx={{ fontSize: 16 }} />
                </Avatar>
                <Box
                  sx={{
                    p: 1.25,
                    borderRadius: 1.5,
                    bgcolor: "#FFFFFF",
                    border: "1px solid rgba(0, 0, 0, 0.08)",
                  }}
                >
                  <Typography variant="body2" sx={{ color: "#53565A", fontSize: "0.8rem" }}>
                    Thinking...
                  </Typography>
                </Box>
              </Box>
            )}

            <div ref={messagesEndRef} />
          </>
        )}
      </Box>

      {/* Input Area */}
      <Box sx={{ p: 1.5, bgcolor: "#FFFFFF", borderTop: "1px solid rgba(0, 0, 0, 0.08)" }}>
        <TextField
          fullWidth
          size="small"
          placeholder={disabled ? "Chat disabled" : placeholder}
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyPress={handleKeyPress}
          disabled={disabled || isLoading}
          InputProps={{
            endAdornment: (
              <InputAdornment position="end">
                <IconButton
                  onClick={handleSendMessage}
                  disabled={disabled || isLoading || !inputValue.trim()}
                  size="small"
                  sx={{
                    color: "#26890D",
                    "&:disabled": { color: "#D0D0CE" },
                  }}
                >
                  <SendIcon fontSize="small" />
                </IconButton>
              </InputAdornment>
            ),
            sx: {
              borderRadius: 1.5,
              bgcolor: disabled ? "#F5F5F5" : "#FFFFFF",
              fontSize: "0.8rem",
            },
          }}
        />
      </Box>
    </Paper>
  );
};

export default ChatPanel;
