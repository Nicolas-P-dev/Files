"use client";

import React from "react";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Box,
  Typography,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Divider,
} from "@mui/material";
import SettingsIcon from "@mui/icons-material/Settings";
import HelpIcon from "@mui/icons-material/Help";
import DescriptionIcon from "@mui/icons-material/Description";
import AssessmentIcon from "@mui/icons-material/Assessment";
import FolderIcon from "@mui/icons-material/Folder";
import HistoryIcon from "@mui/icons-material/History";
import AccountTreeIcon from "@mui/icons-material/AccountTree";

interface SidebarProps {
  currentDebtor: string | null;
}

const Sidebar: React.FC<SidebarProps> = ({ currentDebtor }) => {
  const pathname = usePathname();

  const navigationItems = [
    {
      label: "Configurations",
      path: "/modules/upload-document",
      icon: <SettingsIcon />,
      enabled: true,
    },
    {
      // RENAMED from "Report Generation" to "Attributions" per boss feedback
      label: "Attributions",
      path: "/modules/report-planning",
      icon: <AccountTreeIcon />,
      enabled: true,
    },
    {
      label: "Report Preview",
      path: "/modules/report-generation",
      icon: <DescriptionIcon />,
      enabled: true,
    },
    {
      label: "Saved Reports",
      path: "/modules/saved-reports",
      icon: <FolderIcon />,
      enabled: false,
    },
    {
      label: "History",
      path: "/modules/history",
      icon: <HistoryIcon />,
      enabled: false,
    },
  ];

  const isSelected = (path: string) => pathname === path;

  return (
    <Box
      sx={{
        width: 240, // Slightly narrower
        height: "100vh",
        backgroundColor: "#000000",
        color: "#FFFFFF",
        display: "flex",
        flexDirection: "column",
        position: "fixed",
        left: 0,
        top: 0,
        zIndex: 1200,
      }}
    >
      {/* Logo and App Title Section - REDUCED SIZES per boss feedback */}
      <Box sx={{ pt: 3, px: 2.5, mb: 1.5 }}>
        {/* Smaller Deloitte logo - was 140x35, now 100x25 */}
        <Image
          src="/Deloitte_Logo.png"
          width={100}
          height={25}
          alt="Deloitte Logo"
          style={{ marginBottom: "12px" }}
        />
        {/* Smaller aiStudio text */}
        <Typography
          variant="body2"
          sx={{
            fontWeight: 500,
            color: "#A5ADBA",
            mb: 0.25,
            fontSize: "0.75rem",
          }}
        >
          aiStudio
        </Typography>
        {/* Slightly smaller FORTUNA */}
        <Typography
          variant="h6"
          sx={{
            fontWeight: 700,
            color: "#FFFFFF",
            mb: 0.5,
            letterSpacing: "0.5px",
          }}
        >
          FORTUNA
        </Typography>
        <Typography
          variant="caption"
          sx={{
            color: "#6B778C",
            lineHeight: 1.4,
            display: "block",
            fontSize: "0.7rem",
          }}
        >
          AI-powered CFR Report Generation
        </Typography>
      </Box>

      <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.1)", mx: 2 }} />

      {/* Current Debtor Display */}
      <Box sx={{ px: 2, py: 1.5 }}>
        <Typography
          variant="caption"
          sx={{
            color: "#6B778C",
            textTransform: "uppercase",
            letterSpacing: "0.5px",
            fontSize: "0.65rem",
            mb: 0.5,
            display: "block",
          }}
        >
          Active Debtor
        </Typography>
        <Box
          sx={{
            bgcolor: currentDebtor
              ? "rgba(38, 137, 13, 0.12)"
              : "rgba(255, 255, 255, 0.03)",
            p: 1.25,
            borderRadius: 1,
            border: currentDebtor
              ? "1px solid rgba(38, 137, 13, 0.3)"
              : "1px solid rgba(255, 255, 255, 0.08)",
          }}
        >
          <Typography
            variant="body2"
            sx={{
              color: currentDebtor ? "#86BC25" : "#6B778C",
              fontWeight: currentDebtor ? 600 : 400,
              fontStyle: currentDebtor ? "normal" : "italic",
              fontSize: "0.8rem",
            }}
          >
            {currentDebtor || "No debtor selected"}
          </Typography>
        </Box>
      </Box>

      <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.1)", mx: 2 }} />

      {/* Main Navigation */}
      <Box sx={{ flex: 1, py: 1 }}>
        <Typography
          variant="caption"
          sx={{
            color: "#6B778C",
            textTransform: "uppercase",
            letterSpacing: "0.5px",
            fontSize: "0.65rem",
            px: 2.5,
            py: 0.75,
            display: "block",
          }}
        >
          Navigation
        </Typography>
        <List component="nav" sx={{ px: 1 }}>
          {navigationItems.map((item) => (
            <ListItem key={item.label} disablePadding sx={{ mb: 0.25 }}>
              {item.enabled ? (
                <Link
                  href={item.path}
                  style={{ textDecoration: "none", width: "100%" }}
                >
                  <ListItemButton
                    selected={isSelected(item.path)}
                    sx={{
                      borderRadius: 1,
                      py: 1,
                      "&.Mui-selected": {
                        bgcolor: "rgba(38, 137, 13, 0.15)",
                        "& .MuiListItemIcon-root": { color: "#86BC25" },
                        "& .MuiListItemText-primary": {
                          color: "#FFFFFF",
                          fontWeight: 600,
                        },
                      },
                      "&:hover": {
                        bgcolor: "rgba(255, 255, 255, 0.05)",
                      },
                    }}
                  >
                    <ListItemIcon
                      sx={{
                        minWidth: 36,
                        color: isSelected(item.path) ? "#86BC25" : "#A5ADBA",
                      }}
                    >
                      {item.icon}
                    </ListItemIcon>
                    <ListItemText
                      primary={item.label}
                      sx={{
                        "& .MuiListItemText-primary": {
                          color: isSelected(item.path) ? "#FFFFFF" : "#D0D0CE",
                          fontSize: "0.85rem",
                        },
                      }}
                    />
                  </ListItemButton>
                </Link>
              ) : (
                <ListItemButton
                  disabled
                  sx={{
                    borderRadius: 1,
                    py: 1,
                    opacity: 0.4,
                  }}
                >
                  <ListItemIcon sx={{ minWidth: 36, color: "#6B778C" }}>
                    {item.icon}
                  </ListItemIcon>
                  <ListItemText
                    primary={item.label}
                    secondary="Coming soon"
                    sx={{
                      "& .MuiListItemText-primary": {
                        color: "#6B778C",
                        fontSize: "0.85rem",
                      },
                      "& .MuiListItemText-secondary": {
                        color: "#53565A",
                        fontSize: "0.65rem",
                      },
                    }}
                  />
                </ListItemButton>
              )}
            </ListItem>
          ))}
        </List>
      </Box>

      {/* Bottom Section */}
      <Box sx={{ mt: "auto" }}>
        <Divider sx={{ bgcolor: "rgba(255, 255, 255, 0.1)", mx: 2 }} />
        <List component="nav" sx={{ px: 1, py: 1 }}>
          <ListItem disablePadding>
            <ListItemButton
              disabled
              sx={{
                borderRadius: 1,
                py: 0.75,
                opacity: 0.4,
              }}
            >
              <ListItemIcon sx={{ minWidth: 36, color: "#6B778C" }}>
                <HelpIcon fontSize="small" />
              </ListItemIcon>
              <ListItemText
                primary="Help"
                sx={{
                  "& .MuiListItemText-primary": {
                    color: "#6B778C",
                    fontSize: "0.8rem",
                  },
                }}
              />
            </ListItemButton>
          </ListItem>
        </List>
      </Box>
    </Box>
  );
};

export default Sidebar;
