import { useState, useEffect, useMemo } from 'react';
import { Box, CircularProgress, Collapse, TextField, Autocomplete } from '@mui/material';
import UploadFileIcon from '@mui/icons-material/UploadFile';
import RocketLaunchIcon from '@mui/icons-material/RocketLaunch';
import TuneIcon from '@mui/icons-material/Tune';
import LinkIcon from '@mui/icons-material/Link';
import SearchIcon from '@mui/icons-material/Search';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import { apiFetch } from '../../../utils/api';
import { P, SANS } from './constants';
import { Lbl } from './microComponents';
import UploadSection from './UploadSection';

function generateButtonLabel({ anyUploading, hasReadyDocs }) {
  if (anyUploading) return 'Uploading files…';
  if (!hasReadyDocs) return 'Add at least one document';
  return 'Generate breakdown';
}

/**
 * Empty / setup state. Clean, single-accent layout: hero → DOCUMENTS → PREVIEW →
 * OPTIONS (Jira link + custom instructions), with a sticky Generate footer.
 * All original props/callbacks preserved.
 */
export default function ProjectUploadSetup({
  sessionId,
  selectedProject,
  onProjectChange,
  customInstructions,
  onCustomInstructionsChange,
  onGenerate,
  sessionMissing = false,
}) {
  const [projects, setProjects]   = useState([]);
  const [fetchState, setFetchState] = useState('loading');
  const [retryKey, setRetryKey]   = useState(0);
  const [showInstructions, setShowInstructions] = useState(false);
  const [uploadDocs, setUploadDocs] = useState([]);

  useEffect(() => {
    let cancelled = false;
    setFetchState('loading');
    apiFetch('/api/projects/jira')
      .then(r => r.ok ? r.json() : Promise.reject(r.status))
      .then(data => { if (!cancelled) { setProjects(data.projects || []); setFetchState('ready'); } })
      .catch(() => { if (!cancelled) setFetchState('error'); });
    return () => { cancelled = true; };
  }, [retryKey]);

  const projectOptions = useMemo(() => projects.map(p => ({
    platform: 'jira', key: p.key, name: p.name, label: `${p.key} — ${p.name}`,
  })), [projects]);

  const anyUploading = uploadDocs.some(d => d.status === 'uploading' || d.status === 'processing');
  const hasReadyDocs = uploadDocs.some(d => d.status === 'ready' && d.id);
  const readyCount = uploadDocs.filter(d => d.status === 'ready' && d.id).length;
  const canGenerate = hasReadyDocs && !anyUploading && !sessionMissing;

  const handlePrimaryGenerate = () => {
    if (!canGenerate) return;
    onGenerate(uploadDocs.filter(d => d.status === 'ready' && d.id));
  };

  return (
    <Box sx={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden', bgcolor: P.surface }}>
      {sessionMissing && (
        <Box sx={{ m: '16px', p: '12px', borderRadius: '8px', bgcolor: P.dangerMuted, border: `1px solid rgba(196,52,43,0.2)` }}>
          <Box sx={{ fontFamily: SANS, fontSize: 12, fontWeight: 600, color: P.danger }}>
            No chat session is linked to this panel. Open Upload Requirements from the sidebar or switch to a chat session.
          </Box>
        </Box>
      )}

      {/* scrolling body */}
      <Box sx={{ flex: 1, minHeight: 0, overflowY: 'auto', p: '20px' }}>
        {/* hero */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: '13px', mb: '22px' }}>
          <Box sx={{ width: 42, height: 42, borderRadius: '11px', bgcolor: P.accentMuted, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <UploadFileIcon sx={{ fontSize: 23, color: P.accent }} />
          </Box>
          <Box sx={{ minWidth: 0 }}>
            <Box sx={{ fontFamily: SANS, fontSize: 17, fontWeight: 700, color: P.text1, lineHeight: 1.25 }}>Extract requirements from documents</Box>
            <Box sx={{ fontFamily: SANS, fontSize: 12.5, color: P.text3, mt: '2px' }}>Upload your documents — we'll turn them into epics, stories, and tasks.</Box>
          </Box>
        </Box>

        {/* DOCUMENTS + PREVIEW — UploadSection renders file rows + PDF preview */}
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: '9px' }}>
          <Lbl>DOCUMENTS</Lbl>
        </Box>
        <UploadSection
          sessionId={sessionId}
          layout="panel"
          hideGenerateFooter
          onDocumentsChange={setUploadDocs}
          onGenerate={() => {}}
        />

        {/* OPTIONS */}
        <Lbl sx={{ display: 'block', mt: '20px', mb: '9px' }}>OPTIONS</Lbl>
        <Box sx={{ border: `1px solid ${P.border}`, borderRadius: '9px', overflow: 'hidden', bgcolor: '#fff' }}>
          {/* Jira project link */}
          <Box sx={{ p: '13px 14px', borderBottom: `1px solid ${P.border}` }}>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: '8px', mb: '9px' }}>
              <LinkIcon sx={{ fontSize: 17, color: P.blue }} />
              <Box sx={{ fontFamily: SANS, fontSize: 12.5, fontWeight: 600, color: P.text1 }}>Link a Jira project</Box>
              <Box sx={{ fontFamily: SANS, fontSize: 11, color: P.text4 }}>Optional</Box>
            </Box>
            {fetchState === 'loading' && (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: '8px', height: 34 }}>
                <CircularProgress size={14} sx={{ color: P.accent }} />
                <Box sx={{ fontFamily: SANS, fontSize: 12, color: P.text3 }}>Loading Jira projects…</Box>
              </Box>
            )}
            {fetchState === 'error' && (
              <Box sx={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Box sx={{ fontFamily: SANS, fontSize: 12, color: P.danger }}>Could not load projects.</Box>
                <Box component="button" onClick={() => setRetryKey(k => k + 1)} sx={{ all: 'unset', cursor: 'pointer', fontFamily: SANS, fontSize: 12, fontWeight: 600, color: P.accent }}>Retry</Box>
              </Box>
            )}
            {fetchState === 'ready' && (
              <Autocomplete
                options={projectOptions}
                value={selectedProject ? projectOptions.find(o => o.key === selectedProject.key) || selectedProject : null}
                onChange={(_, v) => onProjectChange(v ? { platform: 'jira', key: v.key, name: v.name } : null)}
                getOptionLabel={o => (o && o.key ? `${o.key} — ${o.name}` : '')}
                isOptionEqualToValue={(a, b) => !!a && !!b && a.key === b.key}
                renderInput={params => (
                  <TextField {...params} size="small" placeholder="Search or select a project…"
                    InputProps={{ ...params.InputProps, startAdornment: <SearchIcon sx={{ fontSize: 16, color: P.text4, mr: '4px' }} /> }}
                    sx={{ bgcolor: P.surface, '& .MuiOutlinedInput-root': { minHeight: 34, fontSize: 12, '&:hover fieldset': { borderColor: P.accent }, '&.Mui-focused fieldset': { borderColor: P.accent } } }} />
                )}
                noOptionsText={projects.length === 0 ? 'No Jira projects found' : 'No matches'}
              />
            )}
          </Box>

          {/* custom instructions */}
          <Box sx={{ p: '13px 14px' }}>
            <Box component="button" onClick={() => setShowInstructions(s => !s)}
              sx={{ all: 'unset', cursor: 'pointer', boxSizing: 'border-box', width: '100%', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <TuneIcon sx={{ fontSize: 17, color: P.accent }} />
              <Box sx={{ fontFamily: SANS, fontSize: 12.5, fontWeight: 600, color: P.text1 }}>Custom extraction instructions</Box>
              <Box sx={{ fontFamily: SANS, fontSize: 11, color: P.text4 }}>Optional</Box>
              <Box sx={{ flex: 1 }} />
              {showInstructions ? <ExpandLessIcon sx={{ fontSize: 18, color: P.text4 }} /> : <ExpandMoreIcon sx={{ fontSize: 18, color: P.text4 }} />}
            </Box>
            <Collapse in={showInstructions}>
              <TextField
                fullWidth multiline rows={4}
                placeholder={'Examples:\n• Focus on action items in the "Next Steps" section\n• Assign work to teams\n• Set high priority for security-related items'}
                value={customInstructions}
                onChange={e => onCustomInstructionsChange(e.target.value)}
                sx={{ mt: '11px', bgcolor: P.surface, '& .MuiOutlinedInput-root': { fontSize: 12, '&:hover fieldset': { borderColor: P.accent }, '&.Mui-focused fieldset': { borderColor: P.accent } } }}
              />
            </Collapse>
          </Box>
        </Box>
      </Box>

      {/* sticky footer */}
      <Box sx={{ flexShrink: 0, p: '14px 18px', borderTop: `1px solid ${P.border}`, bgcolor: '#fff' }}>
        <Box
          component="button"
          onClick={handlePrimaryGenerate}
          disabled={!canGenerate}
          sx={{
            all: 'unset', boxSizing: 'border-box', width: '100%',
            cursor: canGenerate ? 'pointer' : 'not-allowed',
            display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
            height: 46, borderRadius: '8px',
            bgcolor: canGenerate ? P.accent : '#e0e0e0',
            color: canGenerate ? '#fff' : '#9e9e9e',
            fontFamily: SANS, fontSize: 14.5, fontWeight: 600,
            '&:hover': canGenerate ? { bgcolor: P.accentDark } : {},
          }}
        >
          {anyUploading ? <CircularProgress size={18} color="inherit" /> : <RocketLaunchIcon sx={{ fontSize: 18 }} />}
          {generateButtonLabel({ anyUploading, hasReadyDocs })}
        </Box>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '6px', mt: '10px' }}>
          {hasReadyDocs && <CheckCircleIcon sx={{ fontSize: 14, color: P.accent }} />}
          <Box sx={{ fontFamily: SANS, fontSize: 11, color: P.text3 }}>
            {hasReadyDocs ? `${readyCount} document${readyCount !== 1 ? 's' : ''} ready · ` : ''}PDF, DOCX, PPTX, XLSX, TXT, CSV, JPG, PNG
          </Box>
        </Box>
      </Box>
    </Box>
  );
}
