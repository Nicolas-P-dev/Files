import { Box, CircularProgress } from '@mui/material';
import { P, SANS, TOOLBAR_H } from './constants';

// Minimal generation fallback shown when PanelProgress has no trace steps yet.
export default function LoadingBar() {
  return (
    <Box sx={{
      display: 'flex', alignItems: 'center', gap: '8px',
      height: TOOLBAR_H, px: '12px', borderBottom: `1px solid ${P.border}`,
      bgcolor: P.surface,
    }}>
      <CircularProgress size={12} thickness={3} sx={{ color: P.accent }} />
      <Box sx={{ fontFamily: SANS, fontSize: 12, color: P.text2 }}>Generating breakdown…</Box>
      <Box sx={{ fontFamily: SANS, fontSize: 11, color: P.text4 }}>Follow progress in chat</Box>
    </Box>
  );
}
