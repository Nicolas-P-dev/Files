import { useState, useMemo } from 'react';
import { Box, Collapse } from '@mui/material';
import ProgressActivityIcon from '@mui/icons-material/Autorenew';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import RadioButtonUncheckedIcon from '@mui/icons-material/RadioButtonUnchecked';
import ForumOutlinedIcon from '@mui/icons-material/ForumOutlined';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import { P, SANS } from './constants';

const spinKeyframes = {
  '@keyframes pp_spin': { to: { transform: 'rotate(360deg)' } },
  '@keyframes pp_indet': { '0%': { left: '-35%' }, '60%': { left: '100%' }, '100%': { left: '100%' } },
};

function formatStepLabel(step) {
  if (!step) return '';
  if (step.message) return step.message;
  if (step.step) return String(step.step).replace(/_/g, ' ');
  if (step.type) return String(step.type).replace(/_/g, ' ');
  return 'Working…';
}

/**
 * In-panel generation progress. Renders a confident hero (animated indicator +
 * live status + % complete), an indeterminate top bar, and an expandable vertical
 * stepper that ticks each trace step from pending → active (spinner) → done (check).
 * Progress is derived from `traceSteps` (the real generation signal).
 */
export default function PanelProgress({ traceSteps = [] }) {
  const [expanded, setExpanded] = useState(true);

  const visibleSteps = useMemo(
    () => (traceSteps || []).filter(s => s && s.step !== 'thinking' && s.step !== 'discover'),
    [traceSteps],
  );

  // each step is "done" unless it's the latest one (which is in-flight)
  const lastIdx = visibleSteps.length - 1;
  const doneCount = Math.max(0, lastIdx);
  const total = Math.max(visibleSteps.length, 1);
  const pctNum = Math.round((doneCount / total) * 100);
  const latest = visibleSteps[lastIdx];
  const statusLine = latest ? formatStepLabel(latest) : 'Generating breakdown…';

  return (
    <Box sx={{ flexShrink: 0, bgcolor: P.surface, borderBottom: `1px solid ${P.border}`, ...spinKeyframes }}>
      {/* indeterminate bar */}
      <Box sx={{ height: 3, bgcolor: '#e3f0de', overflow: 'hidden', position: 'relative' }}>
        <Box sx={{ position: 'absolute', top: 0, left: 0, width: '35%', height: '100%', bgcolor: P.accent, animation: 'pp_indet 1.5s ease-in-out infinite' }} />
      </Box>

      {/* hero */}
      <Box sx={{ p: '18px 20px 16px', bgcolor: '#fff', borderBottom: `1px solid ${P.border}` }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <Box sx={{ width: 44, height: 44, borderRadius: '11px', bgcolor: P.accentMuted, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
            <ProgressActivityIcon sx={{ fontSize: 24, color: P.accent, animation: 'pp_spin 1.1s linear infinite' }} />
          </Box>
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Box sx={{ fontFamily: SANS, fontSize: 17, fontWeight: 700, color: P.text1, lineHeight: 1.25 }}>Generating breakdown</Box>
            <Box sx={{ fontFamily: SANS, fontSize: 13, color: P.text3, mt: '3px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{statusLine}</Box>
          </Box>
          <Box sx={{ textAlign: 'right', flexShrink: 0 }}>
            <Box sx={{ fontFamily: SANS, fontSize: 20, fontWeight: 700, color: P.accent, lineHeight: 1 }}>{pctNum}%</Box>
            <Box sx={{ fontFamily: SANS, fontSize: 11, color: P.text4, mt: '3px' }}>{doneCount} of {total} steps</Box>
          </Box>
        </Box>
        <Box sx={{ mt: '15px', height: 8, borderRadius: '5px', bgcolor: '#eceef0', overflow: 'hidden' }}>
          <Box sx={{ width: `${pctNum}%`, height: '100%', bgcolor: P.accent, transition: 'width .4s ease' }} />
        </Box>
      </Box>

      {/* steps */}
      {visibleSteps.length > 0 && (
        <>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', p: '13px 18px 7px' }}>
            <Box sx={{ fontFamily: SANS, fontSize: 11, fontWeight: 700, color: P.text4, letterSpacing: '.04em' }}>STEPS</Box>
            <Box component="button" onClick={() => setExpanded(p => !p)}
              sx={{ all: 'unset', cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: '4px', fontFamily: SANS, fontSize: 11, fontWeight: 600, color: P.text3 }}>
              {expanded ? 'Hide' : 'Show'}{expanded ? <ExpandLessIcon sx={{ fontSize: 15 }} /> : <ExpandMoreIcon sx={{ fontSize: 15 }} />}
            </Box>
          </Box>
          <Collapse in={expanded}>
            <Box sx={{ px: '18px', pb: '12px', maxHeight: 220, overflowY: 'auto' }}>
              {visibleSteps.map((step, i) => {
                const active = i === lastIdx;
                const done = i < lastIdx;
                return (
                  <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: '12px', minHeight: 32 }}>
                    {done ? <CheckCircleIcon sx={{ fontSize: 19, color: P.accent }} />
                      : active ? <ProgressActivityIcon sx={{ fontSize: 19, color: P.accent, animation: 'pp_spin 1.1s linear infinite' }} />
                      : <RadioButtonUncheckedIcon sx={{ fontSize: 19, color: '#c9ccd1' }} />}
                    <Box sx={{ fontFamily: SANS, fontSize: 13, fontWeight: active ? 700 : (done ? 600 : 500), color: done ? P.text2 : (active ? P.text1 : P.text4) }}>
                      {formatStepLabel(step)}
                    </Box>
                  </Box>
                );
              })}
            </Box>
          </Collapse>
        </>
      )}

      {/* footer hint */}
      <Box sx={{ display: 'flex', alignItems: 'center', gap: '8px', height: 36, px: '16px', borderTop: `1px solid ${P.border}`, bgcolor: '#fff' }}>
        <ForumOutlinedIcon sx={{ fontSize: 16, color: P.text4 }} />
        <Box sx={{ fontFamily: SANS, fontSize: 12, color: P.text3 }}>Follow detailed progress in chat</Box>
      </Box>
    </Box>
  );
}
