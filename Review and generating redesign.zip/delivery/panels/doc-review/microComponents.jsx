import { Box } from '@mui/material';
import { P, SANS, NODE_DOT, STATUS } from './constants';

// 7px type dot — epic / story / task hierarchy cue.
export function TypeDot({ type, size = 7 }) {
  return (
    <Box component="span" sx={{
      width: size, height: size, borderRadius: '50%', flexShrink: 0,
      bgcolor: NODE_DOT[type] || P.text4,
    }} />
  );
}

// Solid level pill — blue EPIC / green STORY / grey TASK.
const PILL = {
  epic:  { bg: P.blue,   color: '#fff' },
  story: { bg: P.accent, color: '#fff' },
  task:  { bg: '#8a8f98', color: '#fff' },
};
export function TypePill({ type }) {
  const p = PILL[type] || PILL.task;
  return (
    <Box component="span" sx={{
      display: 'inline-flex', alignItems: 'center', flexShrink: 0,
      bgcolor: p.bg, color: p.color,
      px: '7px', py: '1px', borderRadius: '4px',
      fontFamily: SANS, fontSize: 9, fontWeight: 700, letterSpacing: '.06em',
    }}>
      {String(type || '').toUpperCase()}
    </Box>
  );
}

// Outlined status badge (filled for deploying/deployed).
export function StatusBadge({ status, compact = false }) {
  const s = STATUS[status] || STATUS.pending;
  return (
    <Box component="span" sx={{
      fontFamily: SANS, fontSize: compact ? 9 : 9.5, fontWeight: 600,
      lineHeight: 1.4, letterSpacing: '.01em',
      px: '7px', py: '2px', borderRadius: '4px', flexShrink: 0,
      whiteSpace: 'nowrap',
      color: s.fill ? '#fff' : s.color,
      bgcolor: s.fill ? s.bg : 'transparent',
      border: `1px solid ${s.border}`,
    }}>
      {s.label}
    </Box>
  );
}

// Round initials avatar; dashed-ring placeholder when unassigned.
const AV_COLORS = ['#2684FF', '#26890D', '#c47a0a', '#7B61FF', '#0aa2c0', '#c4342b'];
function initials(name) {
  if (!name) return '?';
  const p = name.trim().split(/\s+/);
  return ((p[0][0] || '') + (p[1] ? p[1][0] : '')).toUpperCase();
}
function avatarColor(name) {
  let h = 0;
  for (const c of (name || '')) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return AV_COLORS[h % AV_COLORS.length];
}
export function Avatar({ name, size = 20 }) {
  if (!name) {
    return (
      <Box sx={{
        width: size, height: size, borderRadius: '50%',
        border: '1.5px dashed rgba(0,0,0,0.18)',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        color: P.text4, fontSize: size * 0.6,
      }}>
        ·
      </Box>
    );
  }
  return (
    <Box sx={{
      width: size, height: size, borderRadius: '50%',
      bgcolor: avatarColor(name), color: '#fff',
      fontFamily: SANS, fontSize: size * 0.42, fontWeight: 700,
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
    }}>
      {initials(name)}
    </Box>
  );
}

// Muted section / field micro-label.
export function Lbl({ children, sx: sxProp = {} }) {
  return (
    <Box component="span" sx={{
      fontFamily: SANS, fontSize: 11, fontWeight: 700, color: P.text4,
      lineHeight: 1, letterSpacing: '.04em', ...sxProp,
    }}>
      {children}
    </Box>
  );
}

// Light, spreadsheet-style action button (toolbar / bulk bar).
export function TinyBtn({ children, onClick, active, color, disabled, sx: sxProp = {} }) {
  return (
    <Box
      component="button"
      onClick={disabled ? undefined : onClick}
      sx={{
        all: 'unset', cursor: disabled ? 'not-allowed' : 'pointer', boxSizing: 'border-box',
        fontFamily: SANS, fontSize: 11, fontWeight: 600,
        color: disabled ? P.text4 : (active ? P.accent : (color || P.text3)),
        opacity: disabled ? 0.5 : 1,
        display: 'inline-flex', alignItems: 'center', gap: '4px',
        px: '7px', height: 24, borderRadius: '4px',
        transition: 'background .1s, color .1s',
        '&:hover': disabled ? {} : { bgcolor: 'rgba(0,0,0,0.04)' },
        ...sxProp,
      }}
    >
      {children}
    </Box>
  );
}
