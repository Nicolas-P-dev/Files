import { useState, useCallback, useEffect, useRef, useMemo } from 'react';
import { apiFetch } from '../../../utils/api';
import { Box, Button, IconButton, Tooltip, Dialog, DialogContent } from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import RocketLaunchIcon from '@mui/icons-material/RocketLaunch';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import DeleteOutlineIcon from '@mui/icons-material/DeleteOutline';
import DoneAllIcon from '@mui/icons-material/DoneAll';
import UndoIcon from '@mui/icons-material/Undo';
import LockIcon from '@mui/icons-material/Lock';
import { P, SANS, MONO } from './constants';
import { TypeDot, Lbl } from './microComponents';
import {
  collectStructureIds,
  flattenBreakdownOrdered,
  buildNodeById,
} from './treeHelpers';
import useStructureMutation from './useStructureMutation';
import UploadSection from './UploadSection';
import BreakdownItemCard from './BreakdownItemCard';
import ConflictPane from './ConflictPane';
import DeployModal from './DeployModal';
import StructureItemDetailDialog from './StructureItemDetailDialog';

export default function WorkspaceView({
  structure,
  sessionId,
  selectedProject,
  onStructureChange,
  onSendChat = () => {},
  isStreaming = false,
}) {
  const [teamMembers, setTeamMembers] = useState([]);
  const [selectedId,    setSelectedId]    = useState(null);
  const [showConflicts, setShowConflicts] = useState(false);
  const [showDeploy,    setShowDeploy]    = useState(false);
  const [showUpload,    setShowUpload]    = useState(false);
  const [checked,       setChecked]       = useState(new Set());   // selection set drives bulk actions
  const [collapsed,     setCollapsed]     = useState(new Set());   // collapsed epic/story ids
  const [highlightKey,  setHighlightKey]  = useState('');
  const [detailTarget,  setDetailTarget]  = useState(null);
  const structureIdsRef = useRef(new Set());
  const firstStructRef  = useRef(false);
  const nodeSigRef      = useRef(new Map());

  const {
    undoStack,
    error: mutationError,
    patchNodesStatus,
    patchSingleStatus,
    approveAllPending,
    deleteNode,
    handleUndo,
    saveStructureUpdate,
  } = useStructureMutation(sessionId, structure, onStructureChange);

  useEffect(() => {
    firstStructRef.current = false;
    structureIdsRef.current = new Set();
    nodeSigRef.current = new Map();
  }, [sessionId]);

  // pulse-highlight on streamed changes (unchanged logic)
  useEffect(() => {
    const epics = structure?.epics;
    if (!epics?.length) return;
    const ids = collectStructureIds(epics);
    const nextSig = new Map();
    const walkSig = (nodes) => {
      for (const n of nodes || []) {
        nextSig.set(n.id, `${n.title}\t${n.status}\t${String(n.description || '').slice(0, 120)}`);
        if (n.children?.length) walkSig(n.children);
      }
    };
    walkSig(epics);
    const prevIds = structureIdsRef.current;
    const prevSig = nodeSigRef.current;
    if (!firstStructRef.current) {
      firstStructRef.current = true;
      structureIdsRef.current = new Set(ids);
      nodeSigRef.current = nextSig;
      return undefined;
    }
    const toPulse = new Set();
    for (const id of ids) {
      if (!prevIds.has(id)) toPulse.add(id);
      else if (prevSig.get(id) !== nextSig.get(id)) toPulse.add(id);
    }
    structureIdsRef.current = new Set(ids);
    nodeSigRef.current = nextSig;
    let t;
    if (toPulse.size > 0) {
      setHighlightKey([...toPulse].sort().join('|'));
      t = setTimeout(() => setHighlightKey(''), 1400);
    }
    return () => { if (t) clearTimeout(t); };
  }, [structure]);

  useEffect(() => {
    if (!sessionId) return;
    (async () => {
      try {
        const r = await apiFetch('/api/team/members');
        if (r.ok) { const d = await r.json(); setTeamMembers(d.members || []); }
      } catch { /* ignore */ }
    })();
  }, [sessionId]);

  const memberById = useMemo(() => {
    const m = {};
    for (const x of teamMembers) if (x?.id) m[x.id] = x;
    return m;
  }, [teamMembers]);

  const nodeById = useMemo(() => buildNodeById(structure), [structure]);

  const toggleChk = useCallback(id => setChecked(p => {
    const s = new Set(p); s.has(id) ? s.delete(id) : s.add(id); return s;
  }), []);
  const toggleCollapse = useCallback(id => setCollapsed(p => {
    const s = new Set(p); s.has(id) ? s.delete(id) : s.add(id); return s;
  }), []);
  const clearSelection = useCallback(() => setChecked(new Set()), []);

  const flatOrdered = useMemo(() => flattenBreakdownOrdered(structure?.epics || []), [structure]);

  // group flat-ordered nodes into { epic, children:[story|task] }, honouring collapse
  const groups = useMemo(() => {
    const out = [];
    let cur = null, epicCol = false, storyCol = false;
    for (const { node } of flatOrdered) {
      if (node.type === 'epic') {
        epicCol = collapsed.has(node.id); storyCol = false;
        cur = { epic: node, children: [] };
        out.push(cur);
      } else if (node.type === 'story') {
        storyCol = collapsed.has(node.id);
        if (epicCol || !cur) continue;
        cur.children.push({ node, variant: 'story' });
      } else {
        if (epicCol || storyCol || !cur) continue;
        cur.children.push({ node, variant: 'task' });
      }
    }
    return out;
  }, [flatOrdered, collapsed]);

  const handleDeleteNode = useCallback((nodeId) => {
    deleteNode(nodeId, () => { if (selectedId === nodeId) setSelectedId(null); });
  }, [deleteNode, selectedId]);

  const resolvConflict = (cid, choice) => {
    onSendChat(choice === 'custom'
      ? `Resolve conflict ${cid} with a custom resolution`
      : `Resolve conflict ${cid} by accepting source ${choice.toUpperCase()}`);
  };

  // selection-driven bulk actions
  const bulkApprove = async () => { if (!checked.size || isStreaming) return; await patchNodesStatus([...checked], 'approved'); clearSelection(); };
  const bulkReject  = async () => { if (!checked.size || isStreaming) return; await patchNodesStatus([...checked], 'rejected'); clearSelection(); };
  const bulkDelete  = () => { if (!checked.size || isStreaming) return; [...checked].forEach(id => deleteNode(id, () => {})); clearSelection(); };

  const handleDeploy = async (proj) => {
    setShowDeploy(false);
    const next = { ...structure, target_project: proj };
    try {
      await saveStructureUpdate(next);
      onSendChat(`Deploy approved project structure to jira project "${proj.key}"`);
    } catch { /* error shown via mutationError */ }
  };

  // counts + rollups
  const counts = { epic: 0, story: 0, task: 0 };
  const walk = ns => ns.forEach(n => { counts[n.type] = (counts[n.type] || 0) + 1; if (n.children) walk(n.children); });
  walk(structure.epics || []);

  const tp = structure.target_project || selectedProject;
  const conflicts = structure.conflicts || [];
  const critUn = conflicts.filter(c => c.severity === 'critical' && !c.resolved).length;

  const flatAll = [];
  const walkFlat = ns => ns.forEach(n => { flatAll.push(n); if (n.children) walkFlat(n.children); });
  walkFlat(structure.epics || []);
  const approvedN = flatAll.filter(n => n.status === 'approved' || n.status === 'deploying').length;
  const deployedN = flatAll.filter(n => n.status === 'deployed').length;
  const rejectedN = flatAll.filter(n => n.status === 'rejected').length;
  const allDep = deployedN > 0 && approvedN === 0;
  const totalN = flatAll.length;
  const pct = (n) => (totalN ? `${(n / totalN) * 100}%` : '0%');

  // epic rollup (approved children / total descendants) for the card header
  const epicRollup = useMemo(() => {
    const m = {};
    for (const e of (structure.epics || [])) {
      const kids = [];
      const w = ns => ns.forEach(n => { kids.push(n); if (n.children) w(n.children); });
      w(e.children || []);
      const a = kids.filter(k => k.status === 'approved' || k.status === 'deploying' || k.status === 'deployed').length;
      m[e.id] = { a, t: kids.length };
    }
    return m;
  }, [structure]);

  const deployTooltip = critUn > 0
    ? `${critUn} critical conflict${critUn > 1 ? 's' : ''} must be resolved before deploy`
    : allDep ? 'All approved items have been deployed'
    : approvedN === 0 ? 'Approve items before deploying to Jira'
    : `Deploy ${approvedN} approved item${approvedN !== 1 ? 's' : ''} to Jira`;

  const iconBtn = {
    width: 32, height: 32, borderRadius: '7px', color: P.text3,
    '&:hover': { bgcolor: 'rgba(0,0,0,0.05)' },
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden', bgcolor: P.surfaceRaised }}>

      {/* error bar */}
      {mutationError && (
        <Box sx={{ px: '16px', py: '6px', flexShrink: 0, bgcolor: P.dangerMuted, borderBottom: `1px solid rgba(196,52,43,0.15)`, fontFamily: SANS, fontSize: 11, color: P.danger }}>
          {mutationError}
        </Box>
      )}

      {/* ===== HEADER ===== */}
      <Box sx={{ flexShrink: 0, p: '15px 18px 16px', borderBottom: `1px solid ${P.border}`, bgcolor: '#fff' }}>
        {/* context + primary actions */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: '9px', mb: '16px' }}>
          {tp && <Box sx={{ fontFamily: MONO, fontSize: 11, fontWeight: 700, color: '#fff', bgcolor: P.blue, px: '7px', py: '3px', borderRadius: '4px', letterSpacing: '.03em' }}>{tp.key}</Box>}
          <Box sx={{ fontFamily: SANS, fontSize: 14, fontWeight: 700, color: P.text1 }}>{tp?.name || 'Review extracted items'}</Box>
          <Box sx={{ flex: 1 }} />
          {undoStack.length > 0 && (
            <Tooltip title={`Undo (${undoStack.length})`}>
              <span><IconButton onClick={handleUndo} disabled={isStreaming} sx={iconBtn}><UndoIcon sx={{ fontSize: 18 }} /></IconButton></span>
            </Tooltip>
          )}
          <Tooltip title="Add documents">
            <IconButton onClick={() => setShowUpload(p => !p)} disabled={isStreaming} sx={iconBtn}><CloudUploadIcon sx={{ fontSize: 18 }} /></IconButton>
          </Tooltip>
          <Button onClick={() => setShowConflicts(p => !p)}
            startIcon={critUn > 0 ? <WarningAmberIcon sx={{ fontSize: 15 }} /> : <CheckCircleIcon sx={{ fontSize: 15 }} />}
            sx={{
              textTransform: 'none', height: 32, px: '11px', borderRadius: '7px', fontFamily: SANS, fontSize: 12, fontWeight: 600,
              color: critUn > 0 ? P.danger : P.text3,
              bgcolor: critUn > 0 ? 'rgba(196,52,43,0.06)' : 'transparent',
              border: `1px solid ${critUn > 0 ? 'rgba(196,52,43,0.3)' : P.borderStrong}`,
              '&:hover': { bgcolor: critUn > 0 ? 'rgba(196,52,43,0.1)' : 'rgba(0,0,0,0.04)' },
            }}>
            {critUn > 0 ? `${critUn} critical` : `${conflicts.length} conflict${conflicts.length !== 1 ? 's' : ''}`}
          </Button>
          <Tooltip title={deployTooltip}>
            <span>
              <Button variant="contained" disableElevation
                disabled={isStreaming || critUn > 0 || allDep}
                startIcon={critUn > 0 ? <LockIcon sx={{ fontSize: 15 }} /> : <RocketLaunchIcon sx={{ fontSize: 15 }} />}
                onClick={() => critUn === 0 && !allDep && !isStreaming && setShowDeploy(true)}
                sx={{
                  textTransform: 'none', height: 32, px: '15px', borderRadius: '7px', fontFamily: SANS, fontSize: 13, fontWeight: 600,
                  bgcolor: allDep ? P.blue : P.accent,
                  '&:hover': { bgcolor: allDep ? '#1a6cd4' : P.accentDark },
                  '&.Mui-disabled': { bgcolor: P.text4, color: '#fff', opacity: 0.5 },
                }}>
                {critUn > 0 ? 'Blocked' : allDep ? 'Deployed' : 'Deploy'}
              </Button>
            </span>
          </Tooltip>
        </Box>

        {/* progress */}
        <Box sx={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', mb: '7px' }}>
          <Box sx={{ fontFamily: SANS, fontSize: 12, fontWeight: 600, color: P.text2 }}>Review progress</Box>
          <Box sx={{ fontFamily: SANS, fontSize: 12, color: P.text3 }}>
            <Box component="span" sx={{ fontWeight: 700, color: P.accent }}>{approvedN}</Box> of {totalN} approved
          </Box>
        </Box>
        <Box sx={{ height: 8, borderRadius: '5px', bgcolor: '#eceef0', overflow: 'hidden', display: 'flex' }}>
          <Box sx={{ width: pct(approvedN), bgcolor: P.accent, transition: 'width .25s' }} />
          <Box sx={{ width: pct(deployedN), bgcolor: P.blue, transition: 'width .25s' }} />
          <Box sx={{ width: pct(rejectedN), bgcolor: P.danger, transition: 'width .25s' }} />
        </Box>

        {/* counts + approve all */}
        <Box sx={{ display: 'flex', alignItems: 'center', gap: '18px', mt: '14px' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
            {[['epic', counts.epic, counts.epic === 1 ? 'Epic' : 'Epics'],
              ['story', counts.story, counts.story === 1 ? 'Story' : 'Stories'],
              ['task', counts.task, counts.task === 1 ? 'Task' : 'Tasks']].map(([t, n, label]) => (
              <Box key={t} sx={{ display: 'inline-flex', alignItems: 'center', gap: '6px', fontFamily: SANS, fontSize: 12, fontWeight: 600, color: P.text2 }}>
                <TypeDot type={t} />{n} {label}
              </Box>
            ))}
          </Box>
          <Box sx={{ flex: 1 }} />
          <Button onClick={() => !isStreaming && approveAllPending()} disabled={isStreaming}
            startIcon={<DoneAllIcon sx={{ fontSize: 16 }} />}
            sx={{ textTransform: 'none', height: 28, px: '11px', borderRadius: '7px', fontFamily: SANS, fontSize: 12, fontWeight: 600, color: P.accent, border: `1px solid rgba(38,137,13,0.3)`, '&:hover': { bgcolor: P.accentHover } }}>
            Approve all
          </Button>
        </Box>
      </Box>

      {/* inline add-documents */}
      {showUpload && (
        <Box sx={{ px: '16px', py: '10px', borderBottom: `1px solid ${P.border}`, flexShrink: 0, bgcolor: '#fff' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: '8px' }}>
            <Lbl>Add documents</Lbl>
            <IconButton size="small" onClick={() => setShowUpload(false)} sx={{ p: '2px', color: P.text4 }}><CloseIcon sx={{ fontSize: 14 }} /></IconButton>
          </Box>
          <UploadSection sessionId={sessionId} onGenerate={docs => {
            setShowUpload(false);
            onSendChat('Generate additional project items from the uploaded documents.', { document_ids: docs.map(d => d.id).filter(Boolean) });
          }} />
        </Box>
      )}

      {/* ===== SELECTION ACTION BAR ===== */}
      {checked.size > 0 && (
        <Box sx={{ display: 'flex', alignItems: 'center', gap: '8px', height: 40, px: '16px', bgcolor: P.accentMuted, borderBottom: `1px solid rgba(38,137,13,0.14)`, flexShrink: 0 }}>
          <Box sx={{ fontFamily: SANS, fontSize: 12, fontWeight: 700, color: P.accent }}>{checked.size} selected</Box>
          <Box sx={{ flex: 1 }} />
          <Button onClick={bulkApprove} disabled={isStreaming} startIcon={<CheckIcon sx={{ fontSize: 15 }} />}
            sx={{ textTransform: 'none', height: 28, px: '12px', borderRadius: '6px', fontFamily: SANS, fontSize: 12, fontWeight: 600, color: '#fff', bgcolor: P.accent, '&:hover': { bgcolor: P.accentDark } }}>Approve</Button>
          <Button onClick={bulkReject} disabled={isStreaming} startIcon={<CloseIcon sx={{ fontSize: 15 }} />}
            sx={{ textTransform: 'none', height: 28, px: '11px', borderRadius: '6px', fontFamily: SANS, fontSize: 12, fontWeight: 600, color: P.danger, border: `1px solid rgba(196,52,43,0.3)`, '&:hover': { bgcolor: P.dangerMuted } }}>Reject</Button>
          <Tooltip title="Delete selected">
            <span><IconButton onClick={bulkDelete} disabled={isStreaming} sx={{ width: 28, height: 28, borderRadius: '6px', color: P.text4, '&:hover': { color: P.danger, bgcolor: P.dangerMuted } }}><DeleteOutlineIcon sx={{ fontSize: 16 }} /></IconButton></span>
          </Tooltip>
          <Box sx={{ width: 1, height: 18, bgcolor: 'rgba(38,137,13,0.25)' }} />
          <Button onClick={clearSelection} sx={{ textTransform: 'none', height: 28, px: '6px', fontFamily: SANS, fontSize: 12, fontWeight: 500, color: P.text3, minWidth: 0 }}>Clear</Button>
        </Box>
      )}

      {/* ===== GROUPED LIST ===== */}
      <Box sx={{ flex: 1, overflowY: 'auto', p: '16px', boxSizing: 'border-box', bgcolor: P.surface }}>
        <Box sx={{ display: 'flex', alignItems: 'baseline', gap: '8px', mb: '12px' }}>
          <Box sx={{ fontFamily: SANS, fontSize: 14, fontWeight: 700, color: P.text1 }}>Extracted items</Box>
          <Box sx={{ fontFamily: MONO, fontSize: 11, fontWeight: 600, color: P.text4 }}>{totalN}</Box>
        </Box>

        <Box sx={{ display: 'flex', flexDirection: 'column', gap: '13px' }}>
          {groups.map(({ epic, children }) => (
            <Box key={epic.id} sx={{ border: `1px solid ${P.borderStrong}`, borderRadius: '10px', overflow: 'hidden', boxShadow: '0 1px 2px rgba(0,0,0,0.04)' }}>
              <BreakdownItemCard
                variant="epic"
                node={epic}
                checked={checked}
                onToggleSelect={toggleChk}
                onCheck={toggleChk}
                memberById={memberById}
                epicApproved={epicRollup[epic.id]}
                onApprove={nid => patchSingleStatus(nid, 'approved')}
                onReject={nid => patchSingleStatus(nid, 'rejected')}
                onDeleteNode={handleDeleteNode}
                onOpenDetail={setDetailTarget}
                isHighlighted={highlightKey.includes(epic.id)}
                disableDestructive={isStreaming}
              />
              {/* single continuous guide line for the children block */}
              <Box sx={{ ml: '24px', borderLeft: `2px solid #e4e7ec` }}>
                {children.map(({ node, variant }, i) => (
                  <BreakdownItemCard
                    key={node.id}
                    variant={variant}
                    node={node}
                    parentStory={variant === 'task' ? epic : undefined}
                    taskIndex={i}
                    checked={checked}
                    onToggleSelect={toggleChk}
                    onCheck={toggleChk}
                    memberById={memberById}
                    onApprove={nid => patchSingleStatus(nid, 'approved')}
                    onReject={nid => patchSingleStatus(nid, 'rejected')}
                    onDeleteNode={handleDeleteNode}
                    onOpenDetail={setDetailTarget}
                    isHighlighted={highlightKey.includes(node.id)}
                    disableDestructive={isStreaming}
                  />
                ))}
              </Box>
            </Box>
          ))}
        </Box>
      </Box>

      <Dialog open={showConflicts} onClose={() => setShowConflicts(false)} maxWidth="md" fullWidth scroll="paper">
        <DialogContent sx={{ p: 0 }}>
          <ConflictPane conflicts={conflicts} nodeById={nodeById} onResolve={resolvConflict} onClose={() => setShowConflicts(false)} />
        </DialogContent>
      </Dialog>

      {showDeploy && (
        <DeployModal structure={structure} selectedProject={selectedProject} onClose={() => setShowDeploy(false)} onDeploy={handleDeploy} />
      )}

      <StructureItemDetailDialog open={Boolean(detailTarget)} payload={detailTarget} memberById={memberById} onClose={() => setDetailTarget(null)} />
    </Box>
  );
}
