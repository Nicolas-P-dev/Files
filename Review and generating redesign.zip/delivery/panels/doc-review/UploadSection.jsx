import { useState, useEffect, useRef, useMemo } from 'react';
import { Box, CircularProgress, IconButton } from '@mui/material';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import ArticleIcon from '@mui/icons-material/Article';
import SlideshowIcon from '@mui/icons-material/Slideshow';
import TableChartIcon from '@mui/icons-material/TableChart';
import ImageIcon from '@mui/icons-material/Image';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import RocketLaunchIcon from '@mui/icons-material/RocketLaunch';
import { P, SANS, MONO, ROW_H, ALLOWED_EXTS } from './constants';
import { fmtSize } from './treeHelpers';
import { uploadDocuments, matchUploadedDocuments } from './uploadApi';

// tinted type tile per extension
function fileVisual(name) {
  const ext = (name.split('.').pop() || '').toLowerCase();
  if (ext === 'pdf') return { Icon: PictureAsPdfIcon, tint: '#DA291C' };
  if (ext === 'docx' || ext === 'doc' || ext === 'txt') return { Icon: ArticleIcon, tint: '#2684FF' };
  if (ext === 'pptx' || ext === 'ppt') return { Icon: SlideshowIcon, tint: '#ED8B00' };
  if (ext === 'xlsx' || ext === 'csv') return { Icon: TableChartIcon, tint: '#26890D' };
  if (['png', 'jpg', 'jpeg', 'tiff'].includes(ext)) return { Icon: ImageIcon, tint: '#7B61FF' };
  return { Icon: InsertDriveFileIcon, tint: P.text4 };
}

function statusPill(status) {
  if (status === 'ready')      return { label: 'Ready',      color: P.accent, bg: 'rgba(38,137,13,0.10)' };
  if (status === 'processing') return { label: 'Processing', color: P.warn,   bg: 'rgba(196,122,10,0.10)' };
  if (status === 'error')      return { label: 'Error',      color: P.danger, bg: 'rgba(196,52,43,0.10)' };
  return { label: 'Uploading', color: P.text4, bg: 'rgba(0,0,0,0.05)' };
}

export default function UploadSection({
  sessionId,
  onGenerate = () => {},
  onDocumentsChange,
  hideGenerateFooter = false,
  layout = 'compact',
}) {
  const [docs, setDocs] = useState([]);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState('');
  const [selectedPreviewId, setSelectedPreviewId] = useState('');
  const inputRef = useRef(null);

  const isPanel = layout === 'panel';
  const anyUp = docs.some(d => d.status === 'uploading' || d.status === 'processing');
  const hasReady = docs.some(d => d.status === 'ready' && d.id);
  const ready = hasReady && !anyUp;

  const selectedPdfDoc = useMemo(() => {
    const picked = docs.find(d => d.localId === selectedPreviewId && d.is_pdf && d.preview_url && d.status === 'ready');
    if (picked) return picked;
    return docs.find(d => d.is_pdf && d.preview_url && d.status === 'ready') || null;
  }, [docs, selectedPreviewId]);

  useEffect(() => { onDocumentsChange?.(docs); }, [docs, onDocumentsChange]);

  useEffect(() => () => {
    docs.forEach(d => { if (d.preview_url && d.preview_url.startsWith('blob:')) URL.revokeObjectURL(d.preview_url); });
  }, [docs]);

  const removeDoc = id => setDocs(p => {
    const target = p.find(d => d.localId === id);
    if (target?.preview_url && target.preview_url.startsWith('blob:')) URL.revokeObjectURL(target.preview_url);
    return p.filter(d => d.localId !== id);
  });

  const handleFiles = async fileList => {
    const files = Array.from(fileList);
    if (!files.length) return;
    if (!sessionId) { setError('No session — open or start a chat session before uploading.'); return; }
    setError('');
    const isPdf = f => (f.type || '').toLowerCase() === 'application/pdf' || /\.pdf$/i.test(f.name || '');
    const pending = files.map(f => ({
      localId: crypto.randomUUID(), name: f.name, size_bytes: f.size, type: 'other',
      status: 'uploading', id: null, file: f, is_pdf: isPdf(f),
      preview_url: isPdf(f) ? URL.createObjectURL(f) : '', original_url: '',
    }));
    setDocs(p => [...p, ...pending]);
    try {
      const result = await uploadDocuments(sessionId, files);
      const matched = matchUploadedDocuments(pending, result.documents);
      setDocs(p => {
        const byLocal = Object.fromEntries(matched.map(m => [m.localId, m]));
        return p.map(d => byLocal[d.localId] || d);
      });
      if (result.errors?.length) setError(result.errors.join(' · '));
    } catch (err) {
      setError(err.message || 'Upload failed');
      setDocs(p => p.map(d => pending.some(x => x.localId === d.localId) ? { ...d, status: 'error' } : d));
    }
  };

  const dropZone = (
    <Box
      onDragOver={e => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={e => { e.preventDefault(); setDragging(false); handleFiles(e.dataTransfer.files); }}
      onClick={() => inputRef.current?.click()}
      sx={{
        border: `1.5px dashed ${dragging ? P.accent : P.borderStrong}`,
        borderRadius: '8px', cursor: 'pointer',
        height: docs.length > 0 ? 42 : (isPanel ? 64 : 56),
        display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px',
        bgcolor: dragging ? P.accentHover : '#fff',
        '&:hover': { borderColor: P.accent, bgcolor: P.accentHover },
        transition: 'all .12s',
      }}
    >
      {docs.length > 0 ? <AddIcon sx={{ fontSize: 17, color: P.text4 }} /> : <CloudUploadIcon sx={{ fontSize: 18, color: P.text4 }} />}
      <Box sx={{ fontFamily: SANS, fontSize: 12, fontWeight: docs.length > 0 ? 600 : 400, color: docs.length > 0 ? P.text3 : P.text3 }}>
        {docs.length > 0 ? 'Add more files' : 'Drop files or click to browse'}
      </Box>
      <input ref={inputRef} type="file" multiple accept={ALLOWED_EXTS} style={{ display: 'none' }}
        onChange={e => { handleFiles(e.target.files); e.target.value = ''; }} />
    </Box>
  );

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
      {docs.length === 0 && dropZone}

      {error && <Box sx={{ fontFamily: SANS, fontSize: 11, color: P.danger, px: '4px' }}>{error}</Box>}

      {/* file rows */}
      {docs.length > 0 && (
        <Box sx={{ border: `1px solid ${P.border}`, borderRadius: '9px', overflow: 'hidden', bgcolor: '#fff' }}>
          {docs.map(d => {
            const { Icon, tint } = fileVisual(d.name);
            const isUp = d.status === 'uploading' || d.status === 'processing';
            const sp = statusPill(d.status);
            const selectablePdf = !!d.is_pdf && !!d.preview_url && d.status === 'ready';
            return (
              <Box key={d.localId} sx={{ display: 'flex', alignItems: 'center', gap: '11px', height: 48, px: '12px', borderBottom: `1px solid ${P.border}` }}>
                <Box sx={{ width: 28, height: 28, borderRadius: '7px', bgcolor: `${tint}18`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Icon sx={{ fontSize: 16, color: tint }} />
                </Box>
                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Box sx={{ fontFamily: SANS, fontSize: 12.5, fontWeight: 600, color: P.text1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d.name}</Box>
                  <Box sx={{ fontFamily: MONO, fontSize: 10, color: P.text4, mt: '1px' }}>{fmtSize(d.size_bytes)}</Box>
                </Box>
                {selectablePdf && (
                  <Box component="button" onClick={() => setSelectedPreviewId(d.localId)}
                    sx={{ all: 'unset', cursor: 'pointer', fontFamily: SANS, fontSize: 11, fontWeight: 600, color: P.accent, px: '9px', py: '4px', borderRadius: '5px', '&:hover': { bgcolor: P.accentHover } }}>
                    Preview
                  </Box>
                )}
                {isUp
                  ? <CircularProgress size={12} thickness={4} sx={{ color: P.text4 }} />
                  : <Box sx={{ fontFamily: SANS, fontSize: 10, fontWeight: 600, color: sp.color, bgcolor: sp.bg, px: '8px', py: '3px', borderRadius: '10px', whiteSpace: 'nowrap' }}>{sp.label}</Box>}
                <IconButton size="small" onClick={() => removeDoc(d.localId)} sx={{ width: 26, height: 26, borderRadius: '5px', color: P.text4, '&:hover': { color: P.danger, bgcolor: P.dangerMuted } }}>
                  <CloseIcon sx={{ fontSize: 16 }} />
                </IconButton>
              </Box>
            );
          })}
          {/* add-more row inside the list */}
          <Box onClick={() => inputRef.current?.click()} sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px', height: 42, cursor: 'pointer', color: P.text3, '&:hover': { bgcolor: P.surface } }}>
            <AddIcon sx={{ fontSize: 17, color: P.text4 }} />
            <Box sx={{ fontFamily: SANS, fontSize: 12, fontWeight: 600 }}>Add more files</Box>
            <input ref={inputRef} type="file" multiple accept={ALLOWED_EXTS} style={{ display: 'none' }}
              onChange={e => { handleFiles(e.target.files); e.target.value = ''; }} />
          </Box>
        </Box>
      )}

      {/* PDF preview pane (panel layout) */}
      {isPanel && docs.length > 0 && (
        <>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mt: '10px' }}>
            <Box sx={{ fontFamily: SANS, fontSize: 11, fontWeight: 700, color: P.text4, letterSpacing: '.04em' }}>PREVIEW</Box>
            {selectedPdfDoc && <Box sx={{ fontFamily: MONO, fontSize: 10, color: P.text4 }}>{selectedPdfDoc.name}</Box>}
          </Box>
          <Box sx={{ height: 260, bgcolor: '#eceef1', border: `1px solid ${P.border}`, borderRadius: '9px', overflow: 'hidden', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            {selectedPdfDoc?.preview_url ? (
              <iframe
                title="requirements-pdf-preview"
                src={`${selectedPdfDoc.preview_url}#toolbar=0&navpanes=0&scrollbar=1&view=FitH`}
                style={{ width: '100%', height: '100%', border: 'none', display: 'block' }}
              />
            ) : (
              <Box sx={{ textAlign: 'center', p: 3 }}>
                <ArticleIcon sx={{ fontSize: 36, color: P.text4, mb: 1 }} />
                <Box sx={{ fontFamily: SANS, fontSize: 12, color: P.text3 }}>
                  {docs.some(d => d.is_pdf) ? 'Select a ready PDF to preview' : 'Preview available for PDF files after upload'}
                </Box>
              </Box>
            )}
          </Box>
        </>
      )}

      {/* compact-layout generate footer */}
      {docs.length > 0 && !hideGenerateFooter && (
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Box sx={{ fontFamily: SANS, fontSize: 11, color: P.text4 }}>{docs.length} document{docs.length !== 1 ? 's' : ''}</Box>
          <Box component="button" disabled={!ready}
            onClick={() => ready && onGenerate(docs.filter(d => d.status === 'ready' && d.id))}
            sx={{
              all: 'unset', boxSizing: 'border-box', cursor: ready ? 'pointer' : 'not-allowed',
              display: 'inline-flex', alignItems: 'center', gap: '6px',
              height: 30, px: '12px', borderRadius: '6px',
              bgcolor: ready ? P.accent : '#e0e0e0', color: ready ? '#fff' : '#aaa',
              fontFamily: SANS, fontSize: 11, fontWeight: 600,
              '&:hover': ready ? { bgcolor: P.accentDark } : {},
            }}>
            {anyUp ? <CircularProgress size={10} color="inherit" /> : <RocketLaunchIcon sx={{ fontSize: 13 }} />}
            Generate
          </Box>
        </Box>
      )}
    </Box>
  );
}
