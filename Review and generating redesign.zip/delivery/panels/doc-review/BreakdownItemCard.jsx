import { useContext, useState, memo } from 'react';
import { Box, Typography, Collapse } from '@mui/material';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import TaskAltIcon from '@mui/icons-material/TaskAlt';
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import EventIcon from '@mui/icons-material/Event';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import AutoAwesomeIcon from '@mui/icons-material/AutoAwesome';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import { P, SANS, MONO } from './constants';
import { TypePill, StatusBadge, Avatar } from './microComponents';
import {
  JiraUrlContext,
  assigneeDisplayName,
  effectiveAssignment,
  displayDueDateForCard,
  formatDateV1,
  displayStoryPoints,
  priorityLabelV1,
} from './treeHelpers';

const priColor = (pri) =>
  pri === 'Critical' ? P.danger :
  pri === 'High' ? P.warn :
  pri === 'Low' ? P.accent : P.text3;

// Provenance label (which source doc a node came from). Falls back to source_refs.
function sourceLabel(node) {
  const r = Array.isArray(node.source_refs) ? node.source_refs[0] : null;
  if (r && r.document_name) return r.page ? `${r.document_name} · p${r.page}` : r.document_name;
  return '';
}

/**
 * One node in the review tree. Renders three visually-distinct variants:
 *  - epic  → tinted card header with rollup progress
 *  - story → white row with criteria + meta
 *  - task  → compact grey row
 * Click toggles selection (onToggleSelect); the toolbar's bulk bar applies actions.
 * Per-node onApprove/onReject/onDeleteNode remain available (e.g. detail dialog).
 */
const BreakdownItemCard = memo(function BreakdownItemCard({
  node,
  parentStory,
  taskIndex,
  selectedId,            // kept for contract; selection is driven by `checked`
  onSelect,
  onToggleSelect,
  checked,
  onCheck,
  showCheckboxes,        // kept for contract
  memberById,
  onDeleteNode,
  onApprove,
  onReject,
  isHighlighted,
  onOpenDetail,
  disableDestructive,
  // layout props supplied by WorkspaceView's grouped render:
  variant = 'story',     // 'epic' | 'story' | 'task'
  epicApproved,          // { a, t } rollup for epics
  epicRollupSP,
}) {
  const jiraUrl = useContext(JiraUrlContext);
  const [open, setOpen] = useState(false);

  const isImport = node.status === 'imported';
  const isSel = checked?.has?.(node.id);
  const assigneeLabel = assigneeDisplayName(effectiveAssignment(node, parentStory), memberById);
  const hasAssignee = assigneeLabel && assigneeLabel !== 'Unassigned';
  const pri = priorityLabelV1(node);
  const sp = displayStoryPoints(node);
  const due = formatDateV1(displayDueDateForCard(node));
  const hasDue = due && due !== '—';
  const acList = Array.isArray(node.acceptance_criteria) ? node.acceptance_criteria.filter(Boolean) : [];
  const src = sourceLabel(node);

  const toggleSel = (e) => { e.stopPropagation(); onToggleSelect?.(node.id) ?? onCheck?.(node.id); };
  const toggleDetails = (e) => { e.stopPropagation(); setOpen(o => !o); };

  // ---- EPIC: tinted header card ----
  if (variant === 'epic') {
    const a = epicApproved?.a ?? 0;
    const t = epicApproved?.t ?? 0;
    const pct = t ? (a / t) * 100 : 0;
    return (
      <Box
        onClick={toggleSel}
        sx={{
          p: '12px 14px', cursor: 'pointer',
          bgcolor: isSel ? '#def0d8' : '#f6f8fb',
          borderBottom: `1px solid ${P.border}`,
          boxShadow: isSel ? 'inset 3px 0 0 ' + P.accent : 'none',
        }}
      >
        <Box sx={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
          <TypePill type="epic" />
          <Typography sx={{ flex: 1, minWidth: 0, fontFamily: SANS, fontSize: 14.5, fontWeight: 700, color: P.text1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {node.title}
          </Typography>
          {node.conflict && <WarningAmberIcon sx={{ fontSize: 15, color: P.danger, flexShrink: 0 }} />}
          <StatusBadge status={node.status} />
        </Box>
        {node.description ? (
          <Typography sx={{ mt: '5px', fontFamily: SANS, fontSize: 12, color: P.text2, lineHeight: 1.45, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
            {node.description}
          </Typography>
        ) : null}
        <Box sx={{ mt: '10px', display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
          <Box sx={{ width: 130, height: 6, borderRadius: '3px', bgcolor: '#d3ddf0', overflow: 'hidden' }}>
            <Box sx={{ width: `${pct}%`, height: '100%', bgcolor: P.accent, transition: 'width .25s' }} />
          </Box>
          <Box sx={{ fontFamily: SANS, fontSize: 11, fontWeight: 600, color: P.accent }}>{a} of {t} approved</Box>
          <Box sx={{ display: 'inline-flex', alignItems: 'center', bgcolor: '#fff', border: `1px solid ${P.border}`, borderRadius: '5px', px: '7px', py: '2px', fontFamily: MONO, fontSize: 10, fontWeight: 600, color: P.text2 }}>
            {sp} SP
          </Box>
        </Box>
      </Box>
    );
  }

  // ---- STORY / TASK rows ----
  const isTask = variant === 'task';
  return (
    <Box
      onClick={toggleSel}
      sx={{
        cursor: 'pointer',
        pl: isTask ? '30px' : '14px', pr: '14px', py: isTask ? '10px' : '11px',
        bgcolor: isSel ? '#def0d8' : (isTask ? '#f1f3f6' : '#fff'),
        opacity: isImport ? 0.5 : 1,
        borderBottom: '1px solid rgba(0,0,0,0.045)',
        boxShadow: isSel ? 'inset 3px 0 0 ' + P.accent : 'none',
        outline: (isHighlighted && !isSel) ? `2px solid rgba(38,137,13,0.4)` : 'none',
        outlineOffset: '-2px',
        '&:hover': { filter: 'brightness(0.975)' },
      }}
    >
      <Box sx={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
        <TypePill type={variant} />
        <Typography sx={{ flex: 1, minWidth: 0, fontFamily: SANS, fontSize: isTask ? 12.5 : 13, fontWeight: isTask ? 500 : 600, color: P.text1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {node.title}
        </Typography>
        {node.conflict && <WarningAmberIcon sx={{ fontSize: 15, color: P.danger, flexShrink: 0 }} />}
        {node.jira_key && jiraUrl ? (
          <Box component="a" href={`${jiraUrl}/browse/${node.jira_key}`} target="_blank" rel="noopener noreferrer"
            onClick={e => e.stopPropagation()}
            sx={{ fontFamily: MONO, fontSize: 10, fontWeight: 600, color: P.blue, textDecoration: 'none', flexShrink: 0, '&:hover': { textDecoration: 'underline' } }}>
            {node.jira_key}
          </Box>
        ) : null}
        <StatusBadge status={node.status} compact />
      </Box>

      {node.description ? (
        <Typography sx={{ mt: '5px', fontFamily: SANS, fontSize: 12, color: P.text3, lineHeight: 1.45, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>
          {node.description}
        </Typography>
      ) : null}

      {/* Acceptance-criteria summary + expand toggle */}
      {acList.length > 0 ? (
        <Box onClick={toggleDetails} sx={{ mt: '7px', display: 'flex', alignItems: 'center', gap: '7px', cursor: 'pointer', '&:hover': { opacity: 0.8 } }}>
          <TaskAltIcon sx={{ fontSize: 15, color: P.accent, flexShrink: 0 }} />
          <Typography sx={{ flex: 1, minWidth: 0, fontFamily: SANS, fontSize: 12, color: P.text2, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {acList[0]}
          </Typography>
          <Box sx={{ display: 'inline-flex', alignItems: 'center', gap: '2px', fontFamily: SANS, fontSize: 11, fontWeight: 600, color: P.blue, flexShrink: 0 }}>
            {open ? 'Hide details' : (acList.length > 1 ? `View all ${acList.length} criteria & details` : 'View details')}
            {open ? <ExpandLessIcon sx={{ fontSize: 15 }} /> : <ExpandMoreIcon sx={{ fontSize: 15 }} />}
          </Box>
        </Box>
      ) : null}

      {/* Expanded detail panel */}
      {acList.length > 0 ? (
        <Collapse in={open} unmountOnExit>
          <Box onClick={e => e.stopPropagation()} sx={{ mt: '9px', p: '12px 13px', bgcolor: '#fbfcfd', border: `1px solid ${P.border}`, borderRadius: '8px' }}>
            {node.description ? (
              <>
                <Box sx={{ fontFamily: SANS, fontSize: 10, fontWeight: 700, color: P.text4, letterSpacing: '.04em', mb: '4px' }}>DESCRIPTION</Box>
                <Typography sx={{ fontFamily: SANS, fontSize: 12.5, color: P.text2, lineHeight: 1.5, mb: '13px' }}>{node.description}</Typography>
              </>
            ) : null}
            <Box sx={{ fontFamily: SANS, fontSize: 10, fontWeight: 700, color: P.text4, letterSpacing: '.04em', mb: '7px' }}>
              {acList.length} acceptance criteria
            </Box>
            <Box sx={{ display: 'flex', flexDirection: 'column', gap: '7px' }}>
              {acList.map((c, i) => (
                <Box key={i} sx={{ display: 'flex', alignItems: 'flex-start', gap: '8px' }}>
                  <CheckCircleIcon sx={{ fontSize: 16, color: P.accent, flexShrink: 0, mt: '1px' }} />
                  <Typography sx={{ flex: 1, fontFamily: SANS, fontSize: 12.5, color: '#3a3d44', lineHeight: 1.45 }}>{c}</Typography>
                </Box>
              ))}
            </Box>
            {src ? (
              <Box sx={{ mt: '13px', pt: '11px', borderTop: `1px solid rgba(0,0,0,0.06)`, display: 'flex', alignItems: 'center', gap: '6px' }}>
                <AutoAwesomeIcon sx={{ fontSize: 14, color: P.blue }} />
                <Box sx={{ fontFamily: SANS, fontSize: 11, color: P.text3 }}>Extracted from</Box>
                <Box sx={{ fontFamily: MONO, fontSize: 11, fontWeight: 600, color: P.blue }}>{src}</Box>
              </Box>
            ) : null}
          </Box>
        </Collapse>
      ) : null}

      {/* Meta line: assignee · points · priority · due · source */}
      <Box sx={{ mt: '9px', display: 'flex', alignItems: 'center', gap: '14px', flexWrap: 'wrap' }}>
        <Box sx={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
          <Avatar name={hasAssignee ? assigneeLabel : ''} />
          <Box sx={{ fontFamily: SANS, fontSize: 12, color: hasAssignee ? P.text1 : P.text4 }}>{assigneeLabel || 'Unassigned'}</Box>
        </Box>
        <Box sx={{ display: 'inline-flex', alignItems: 'center', bgcolor: '#eef0f2', borderRadius: '5px', px: '8px', py: '3px', fontFamily: MONO, fontSize: 11, fontWeight: 600, color: P.text2 }}>{sp} SP</Box>
        <Box sx={{ display: 'inline-flex', alignItems: 'center', gap: '5px', fontFamily: SANS, fontSize: 11.5, fontWeight: 600, color: priColor(pri) }}>
          <Box sx={{ width: 6, height: 6, borderRadius: '50%', bgcolor: priColor(pri) }} />{pri}
        </Box>
        {hasDue ? (
          <Box sx={{ display: 'inline-flex', alignItems: 'center', gap: '4px', fontFamily: SANS, fontSize: 11.5, color: P.text3 }}>
            <EventIcon sx={{ fontSize: 14, color: P.text4 }} />{due}
          </Box>
        ) : null}
        {src ? (
          <Box sx={{ display: 'inline-flex', alignItems: 'center', gap: '4px', fontFamily: SANS, fontSize: 11, color: P.text4 }}>
            <DescriptionOutlinedIcon sx={{ fontSize: 14, color: '#c9ccd1' }} />{src}
          </Box>
        ) : null}
      </Box>
    </Box>
  );
}, (a, b) =>
  a.node === b.node && a.selectedId === b.selectedId && a.checked === b.checked &&
  a.showCheckboxes === b.showCheckboxes && a.taskIndex === b.taskIndex &&
  a.parentStory === b.parentStory && a.memberById === b.memberById &&
  a.onDeleteNode === b.onDeleteNode && a.onApprove === b.onApprove && a.onReject === b.onReject &&
  a.onToggleSelect === b.onToggleSelect && a.isHighlighted === b.isHighlighted &&
  a.onOpenDetail === b.onOpenDetail && a.disableDestructive === b.disableDestructive &&
  a.variant === b.variant && a.epicApproved === b.epicApproved
);

export default BreakdownItemCard;
